// ============================================================
// DEAD BY PIXEL - Enhanced Edition v2.1
// FNAF-Style Menu + DBD Lobby + Animations + Mobile Crossplay
// ============================================================

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

// ---- CONSTANTS ----
const TILE = 28;
const MAP_W = 36;
const MAP_H = 24;
const VIEW_W = MAP_W * TILE;
const VIEW_H = MAP_H * TILE;
canvas.width = VIEW_W;
canvas.height = VIEW_H;

const GAME_STATES = { MENU: 0, LOBBY: 1, PLAYING: 2, ENDED: 3 };
let gameState = GAME_STATES.MENU;
let gameMode = 'local'; // 'local' or 'online'
let gameTimer = 0;
let exitGates = [];
let pallets = [];
let lockers = [];
let hooks = [];
let generators = [];
let gensCompleted = 0;
const GENS_TO_POWER = 3; // need 3 of 5 gens to open gates
let gatesOpen = false;
let gameMessage = '';
let gameMsgTimer = 0;
const MATCH_TIME = 18000;
let matchTimeRemaining = MATCH_TIME;
let particles = [];
let scratchMarks = [];
let bloodPools = [];
let fogParticles = [];

// Mobile detection
const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) 
    || (navigator.maxTouchPoints > 0 && window.innerWidth < 1024);

// Online state
let onlineMode = false;
let myPlayerId = null;
let roomCode = '';
let isHost = false;
let peer = null;
let peerConnections = [];

// Lobby state
let lobbyPlayers = [];
let myReady = false;
let selectedPerks = { killer: [], survivor: [] };
let selectedMap = 'random';

// ---- PERKS SYSTEM ----
// KILLER_PERKS and SURVIVOR_PERKS are defined in progression.js (with rarity)

// ---- CHARACTER DEFINITIONS ----
const KILLERS = {
    trapper: { name: 'Trapper', desc: 'Armadilhas de urso', speed: 1.2, attackRange: 35, attackCooldown: 75, attackDuration: 15, ability: 'trap', abilityCD: 180, abilityDur: 1, terrorRadius: 200, color: '#5a4a30', secondaryColor: '#3a3020', weaponColor: '#999999', glowColor: '#ffaa00' },
    huntress: { name: 'Huntress', desc: 'Arremesso de machado', speed: 1.15, attackRange: 35, attackCooldown: 70, attackDuration: 16, ability: 'hatchet', abilityCD: 90, abilityDur: 1, terrorRadius: 200, color: '#4a6a4a', secondaryColor: '#2a4a2a', weaponColor: '#888888', glowColor: '#88cc44' },
    ghostface: { name: 'Pânico', desc: 'Perseguição furtiva', speed: 1.22, attackRange: 35, attackCooldown: 68, attackDuration: 15, ability: 'stealth', abilityCD: 210, abilityDur: 150, terrorRadius: 170, color: '#e8e8e8', secondaryColor: '#050505', weaponColor: '#cccccc', glowColor: '#ffffff' }
};

const SURVIVORS = {
    meg: { name: 'Meg Thomas', desc: 'Sprint Burst', speed: 1.1, ability: 'sprint', abilityCD: 360, abilityDur: 60, color: '#553322', secondaryColor: '#661122', shirtColor: '#cc4455', glowColor: '#ff6688' },
    claudette: { name: 'Claudette', desc: 'Autocuidado', speed: 1.0, ability: 'selfheal', abilityCD: 480, abilityDur: 90, color: '#221111', secondaryColor: '#2a3a2a', shirtColor: '#4a7a4a', glowColor: '#44ff66' },
    dwight: { name: 'Dwight', desc: 'Resgate rápido', speed: 1.0, ability: 'fastunhook', abilityCD: 0, abilityDur: 0, color: '#1a1a1a', secondaryColor: '#333333', shirtColor: '#eeeeee', glowColor: '#ffcc00' }
};

// ---- SKINS ----
const SKINS = {
    killer: {
        default: { name: 'Padrão', icon: '🎭' },
        prestige: { name: 'Prestige III', icon: '🩸', color: '#2a0000', secondaryColor: '#1a0000', weaponColor: '#cc0000', glowColor: '#ff0000' }
    },
    survivor: {
        default: { name: 'Padrão', icon: '🎭' },
        prestige: { name: 'Prestige III', icon: '🩸', shirtColor: '#4a0000', color: '#220000', secondaryColor: '#3a0000' }
    }
};

// ---- MAPS ----
const MAPS = {
    asylum: { name: 'Asilo Abandonado', wallColor: '#2a2a3a', floorColor: '#12121a', accentColor: '#3a3a4a', ambientColor: '#1a1a2e', fogColor: 'rgba(20,20,40,0.3)' },
    forest: { name: 'Floresta Sombria', wallColor: '#1a3318', floorColor: '#0a140a', accentColor: '#2a4422', ambientColor: '#0a1a0a', fogColor: 'rgba(10,30,10,0.35)' },
    factory: { name: 'Fábrica Decadente', wallColor: '#3a2a1a', floorColor: '#14100a', accentColor: '#4a3a2a', ambientColor: '#1a1408', fogColor: 'rgba(30,20,10,0.25)' },
    catacombs: { name: 'Catacumbas', wallColor: '#2a2a2a', floorColor: '#0e0e0e', accentColor: '#3a3a3a', ambientColor: '#111111', fogColor: 'rgba(15,15,15,0.4)' },
    hospital: { name: 'Hospital Maldito', wallColor: '#1a2a2a', floorColor: '#0a1212', accentColor: '#2a3a3a', ambientColor: '#0a1818', fogColor: 'rgba(10,25,25,0.3)' }
};

// ---- CONTROLS ----
const CONTROL_SCHEMES = [
    { name: 'WASD+E+Q', up: 'KeyW', down: 'KeyS', left: 'KeyA', right: 'KeyD', action: 'KeyE', ability: 'KeyQ' },
    { name: 'Arrows', up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight', action: 'Numpad0', ability: 'NumpadDecimal' },
    { name: 'IJKL', up: 'KeyI', down: 'KeyK', left: 'KeyJ', right: 'KeyL', action: 'KeyO', ability: 'KeyP' },
    { name: 'Numpad', up: 'Numpad8', down: 'Numpad5', left: 'Numpad4', right: 'Numpad6', action: 'Numpad1', ability: 'Numpad2' },
    { name: 'TFGH', up: 'KeyT', down: 'KeyG', left: 'KeyF', right: 'KeyH', action: 'KeyY', ability: 'KeyR' }
];

// ============================================================
// MENU BACKGROUND ANIMATION (FNAF Style)
// ============================================================
let menuAnimFrame = 0;
let menuParticles = [];

function initMenuBackground() {
    const bgCanvas = document.getElementById('menu-bg-canvas');
    if (!bgCanvas) return;
    // Render at half resolution for crispier pixel art, CSS scales it up
    bgCanvas.width = Math.floor(window.innerWidth / 2);
    bgCanvas.height = Math.floor(window.innerHeight / 2);
    
    menuParticles = [];
    for (let i = 0; i < 50; i++) {
        menuParticles.push({
            x: Math.random() * bgCanvas.width * 0.5 + bgCanvas.width * 0.2,
            y: Math.random() * bgCanvas.height,
            size: 2, // pixel size at half resolution
            speed: 0.3 + Math.random() * 0.5,
            alpha: 0.3 + Math.random() * 0.5,
            drift: Math.random() * Math.PI * 2
        });
    }
    animateMenu();
}

function animateMenu() {
    if (gameState !== GAME_STATES.MENU) return;
    const bgCanvas = document.getElementById('menu-bg-canvas');
    if (!bgCanvas) return;
    const c = bgCanvas.getContext('2d');
    const W = bgCanvas.width, H = bgCanvas.height;
    menuAnimFrame++;
    
    // Pixel grid size for retro feel
    const PX = 2; // base pixel block size (canvas is half resolution)
    
    // === DARK PIXEL ART FOREST BACKGROUND ===
    c.fillStyle = '#020408'; c.fillRect(0, 0, W, H);
    
    // Night sky (pixel art bands)
    c.fillStyle = '#030810'; c.fillRect(0, 0, W, H * 0.15);
    c.fillStyle = '#051018'; c.fillRect(0, H * 0.15, W, H * 0.1);
    c.fillStyle = '#071420'; c.fillRect(0, H * 0.25, W, H * 0.1);
    c.fillStyle = '#0a1a28'; c.fillRect(0, H * 0.35, W, H * 0.15);
    
    // Pixel art stars (small twinkling dots)
    let starSeed = 42;
    for (let i = 0; i < 25; i++) {
        starSeed = (starSeed * 1103515245 + 12345) & 0x7fffffff;
        let sx = (starSeed % Math.floor(W * 0.9)) + W * 0.05;
        starSeed = (starSeed * 1103515245 + 12345) & 0x7fffffff;
        let sy = (starSeed % Math.floor(H * 0.35));
        let twinkle = Math.sin(menuAnimFrame * 0.03 + i * 2.7) * 0.4 + 0.6;
        c.fillStyle = `rgba(200,220,255,${twinkle * 0.5})`;
        c.fillRect(Math.floor(sx / PX) * PX, Math.floor(sy / PX) * PX, PX, PX);
    }
    
    // Pixel art moon (square pixel moon)
    let moonX = Math.floor(W * 0.65 / PX) * PX, moonY = Math.floor(H * 0.08 / PX) * PX;
    // Moon glow (pixel blocks)
    c.fillStyle = '#aaccff08'; c.fillRect(moonX - PX*5, moonY - PX*5, PX*12, PX*12);
    c.fillStyle = '#bbddff10'; c.fillRect(moonX - PX*3, moonY - PX*3, PX*8, PX*8);
    // Moon body (pixel circle approximation)
    c.fillStyle = '#ccddee'; c.fillRect(moonX, moonY, PX*3, PX*4);
    c.fillRect(moonX - PX, moonY + PX, PX*5, PX*2);
    c.fillStyle = '#ddeeff'; c.fillRect(moonX, moonY + PX, PX*3, PX*2);
    // Moon craters (darker pixels)
    c.fillStyle = '#aabbcc'; c.fillRect(moonX + PX, moonY + PX*2, PX, PX);
    c.fillStyle = '#99aabb'; c.fillRect(moonX - PX, moonY + PX*2, PX, PX);
    
    // Pixel art dead trees (blocky silhouettes)
    c.fillStyle = '#0a1218';
    for (let i = 0; i < 10; i++) {
        let tx = Math.floor((W * (0.15 + i * 0.085) + Math.sin(i * 4) * 20) / PX) * PX;
        let tBase = Math.floor(H * 0.65 / PX) * PX;
        let tTop = Math.floor(H * (0.08 + (i % 3) * 0.04) / PX) * PX;
        let tW = PX * (2 + i % 2);
        // Trunk
        c.fillRect(tx, tTop, tW, tBase - tTop);
        // Branches (pixel art)
        c.fillStyle = '#081015';
        let bh = tTop + (tBase - tTop) * 0.2;
        c.fillRect(tx - PX*3, Math.floor(bh / PX) * PX, PX*4, PX);
        c.fillRect(tx - PX*4, Math.floor(bh / PX) * PX - PX, PX*2, PX);
        c.fillRect(tx + tW, Math.floor((bh + PX*4) / PX) * PX, PX*3, PX);
        c.fillRect(tx + tW + PX*2, Math.floor((bh + PX*3) / PX) * PX, PX*2, PX);
        // Second branch
        let bh2 = tTop + (tBase - tTop) * 0.5;
        c.fillRect(tx - PX*2, Math.floor(bh2 / PX) * PX, PX*3, PX);
        c.fillRect(tx + tW, Math.floor((bh2 - PX*2) / PX) * PX, PX*4, PX);
        c.fillRect(tx + tW + PX*3, Math.floor((bh2 - PX*3) / PX) * PX, PX*2, PX);
        c.fillStyle = '#0a1218';
    }
    
    // Tree canopy (pixel block clusters)
    c.fillStyle = '#060e14';
    for (let i = 0; i < Math.floor(W / (PX*4)); i++) {
        let cx = i * PX * 4;
        let cy = Math.floor(H * 0.06 / PX) * PX;
        let ch = PX * (3 + (i * 7) % 4);
        if (cx > W * 0.12 && cx < W * 0.88) {
            c.fillRect(cx, cy, PX*4, ch);
        }
    }
    c.fillStyle = '#081018';
    for (let i = 0; i < Math.floor(W / (PX*3)); i++) {
        let cx = i * PX * 3 + PX;
        let cy = Math.floor(H * 0.12 / PX) * PX;
        let ch = PX * (2 + (i * 11) % 3);
        if (cx > W * 0.1 && cx < W * 0.9) {
            c.fillRect(cx, cy, PX*3, ch);
        }
    }
    
    // Ground (pixel art layered)
    let groundY = Math.floor(H * 0.68 / PX) * PX;
    c.fillStyle = '#1a1a10'; c.fillRect(0, groundY, W, PX*2);
    c.fillStyle = '#141408'; c.fillRect(0, groundY + PX*2, W, H - groundY - PX*2);
    c.fillStyle = '#0f0f06'; c.fillRect(0, groundY + PX*6, W, H - groundY - PX*6);
    // Ground texture (scattered pixel debris)
    c.fillStyle = '#222218';
    for (let i = 0; i < 30; i++) {
        let gx = Math.floor(((i * 137 + 31) % W) / PX) * PX;
        let gy = groundY + PX * (2 + (i * 53) % 8);
        c.fillRect(gx, gy, PX, PX);
    }
    // Dirt path (lighter pixel blocks)
    c.fillStyle = '#2a2a1a08';
    for (let i = 0; i < 20; i++) {
        let px2 = Math.floor((W * 0.35 + i * W * 0.015) / PX) * PX;
        let py2 = groundY + PX * (3 + (i * 7) % 5);
        c.fillRect(px2, py2, PX * 2, PX);
    }
    
    // === PIXEL ART CAMPFIRE (center) ===
    let fireX = Math.floor(W * 0.45 / PX) * PX, fireY = Math.floor(H * 0.72 / PX) * PX;
    let flicker = Math.floor(Math.sin(menuAnimFrame * 0.12) * 2);
    let flicker2 = Math.floor(Math.cos(menuAnimFrame * 0.15) * 1);
    
    // Fire glow on ground (pixel blocks)
    c.fillStyle = `rgba(255,100,20,${0.06 + Math.sin(menuAnimFrame * 0.08) * 0.02})`;
    c.fillRect(fireX - PX*12, fireY - PX*6, PX*24, PX*14);
    c.fillStyle = `rgba(255,80,10,${0.03})`;
    c.fillRect(fireX - PX*18, fireY - PX*10, PX*36, PX*22);
    
    // Pixel art logs
    c.fillStyle = '#3a2008'; c.fillRect(fireX - PX*6, fireY + PX*2, PX*4, PX*2);
    c.fillRect(fireX + PX*3, fireY + PX*2, PX*4, PX*2);
    c.fillStyle = '#2a1505'; c.fillRect(fireX - PX*2, fireY + PX*3, PX*5, PX*2);
    // Log detail (bark texture)
    c.fillStyle = '#4a3010'; c.fillRect(fireX - PX*6, fireY + PX*2, PX, PX);
    c.fillRect(fireX + PX*6, fireY + PX*2, PX, PX);
    // Log end circles
    c.fillStyle = '#5a4020'; c.fillRect(fireX - PX*6, fireY + PX*2, PX, PX*2);
    c.fillRect(fireX + PX*6, fireY + PX*2, PX, PX*2);
    
    // Pixel art fire flames (layered blocks)
    // Outer flame (dark red)
    c.fillStyle = '#aa2200';
    c.fillRect(fireX - PX*3, fireY - PX*2 + flicker*PX, PX*7, PX*4);
    c.fillRect(fireX - PX*2, fireY - PX*4 + flicker*PX, PX*5, PX*2);
    c.fillRect(fireX - PX, fireY - PX*5 + flicker*PX, PX*3, PX);
    // Mid flame (orange)
    c.fillStyle = '#ff6600';
    c.fillRect(fireX - PX*2, fireY - PX*2 + flicker*PX, PX*5, PX*3);
    c.fillRect(fireX - PX, fireY - PX*4 + flicker*PX, PX*3, PX*2);
    c.fillRect(fireX + flicker2*PX, fireY - PX*5 + flicker*PX, PX*2, PX);
    // Inner flame (yellow)
    c.fillStyle = '#ffaa00';
    c.fillRect(fireX - PX, fireY - PX*2 + flicker*PX, PX*3, PX*3);
    c.fillRect(fireX, fireY - PX*3 + flicker*PX, PX*2, PX);
    // Hot core (white/yellow)
    c.fillStyle = '#ffdd44';
    c.fillRect(fireX, fireY - PX + flicker*PX, PX*2, PX*2);
    c.fillStyle = '#ffffff';
    c.fillRect(fireX, fireY + flicker*PX, PX, PX);
    // Fire tip sparks
    c.fillStyle = '#ff4400';
    c.fillRect(fireX - PX + flicker2*PX, fireY - PX*6 + flicker*PX, PX, PX);
    c.fillRect(fireX + PX*2 - flicker2*PX, fireY - PX*7 + flicker*PX, PX, PX);
    
    // === PIXEL ART SURVIVORS sitting around fire ===
    let survColors = ['#cc3344', '#4a7a4a', '#eeeeee', '#556677'];
    let survHair = ['#553322', '#0a0a00', '#1a1a1a', '#6644aa'];
    let survSkin = ['#ddb088', '#8a6644', '#ddb088', '#eeccaa'];
    for (let i = 0; i < 4; i++) {
        let angle = (i / 4) * Math.PI * 0.8 + Math.PI * 0.6;
        let dist = 44 + i * 10;
        let sx = Math.floor((fireX + Math.cos(angle) * dist) / PX) * PX;
        let sy = Math.floor((fireY + Math.sin(angle) * dist * 0.4 + 5) / PX) * PX;
        let bob = Math.floor(Math.sin(menuAnimFrame * 0.02 + i * 2) * 0.8) * PX;
        
        // Shadow under survivor
        c.fillStyle = '#00000033'; c.fillRect(sx - PX*2, sy + PX*2, PX*5, PX);
        // Shoes
        c.fillStyle = '#111'; c.fillRect(sx - PX*2, sy + PX + bob, PX*2, PX); c.fillRect(sx + PX, sy + PX + bob, PX*2, PX);
        // Legs (sitting, bent)
        c.fillStyle = '#222244'; c.fillRect(sx - PX*2, sy + bob, PX*2, PX*2); c.fillRect(sx + PX, sy + bob, PX*2, PX*2);
        // Body/shirt
        c.fillStyle = survColors[i]; c.fillRect(sx - PX*2, sy - PX*3 + bob, PX*5, PX*3);
        // Shirt detail (collar/seam)
        c.fillStyle = survColors[i] + '88'; c.fillRect(sx, sy - PX*3 + bob, PX, PX*3);
        // Arms (reaching to fire)
        c.fillStyle = survSkin[i]; c.fillRect(sx - PX*3, sy - PX*2 + bob, PX, PX*2); c.fillRect(sx + PX*3, sy - PX*2 + bob, PX, PX*2);
        // Hands (toward fire)
        c.fillStyle = survSkin[i]; c.fillRect(sx - PX*3, sy - PX + bob, PX, PX); c.fillRect(sx + PX*3, sy - PX + bob, PX, PX);
        // Head
        c.fillStyle = survSkin[i]; c.fillRect(sx - PX, sy - PX*6 + bob, PX*3, PX*3);
        // Hair (different styles per survivor)
        c.fillStyle = survHair[i];
        c.fillRect(sx - PX, sy - PX*7 + bob, PX*3, PX*2);
        c.fillRect(sx - PX*2, sy - PX*6 + bob, PX, PX*2);
        c.fillRect(sx + PX*2, sy - PX*6 + bob, PX, PX*2);
        // Eyes (looking at fire - lit by firelight)
        c.fillStyle = '#ffcc8866'; c.fillRect(sx - PX, sy - PX*5 + bob, PX, PX); c.fillRect(sx + PX, sy - PX*5 + bob, PX, PX);
        // Pupils
        c.fillStyle = '#111'; c.fillRect(sx - PX, sy - PX*5 + bob, PX, PX); c.fillRect(sx + PX, sy - PX*5 + bob, PX, PX);
        // Fire reflection on face
        let fireGlowInt = Math.sin(menuAnimFrame * 0.1 + i) * 0.15 + 0.2;
        c.fillStyle = `rgba(255,120,40,${fireGlowInt})`; c.fillRect(sx - PX, sy - PX*5 + bob, PX*3, PX*2);
    }
    
    // === PIXEL ART KILLER (right side, LARGE, menacing) ===
    let kx = Math.floor(W * 0.78 / PX) * PX, ky = Math.floor(H * 0.15 / PX) * PX;
    let kBreathe = Math.floor(Math.sin(menuAnimFrame * 0.025) * 0.5) * PX;
    let kS = Math.max(Math.floor(Math.min(W, H) * 0.003 / PX) * PX, PX); // pixel-snapped scale
    
    // Killer body (large blocky pixel art silhouette)
    c.fillStyle = '#080808';
    // Torso (massive)
    c.fillRect(kx - kS*8, ky + kS*6 + kBreathe, kS*16, kS*22);
    c.fillStyle = '#0c0c0c';
    c.fillRect(kx - kS*7, ky + kS*7 + kBreathe, kS*14, kS*20);
    // Shoulders (broad, angular)
    c.fillStyle = '#0a0a0a';
    c.fillRect(kx - kS*10, ky + kS*5 + kBreathe, kS*20, kS*4);
    c.fillRect(kx - kS*11, ky + kS*6 + kBreathe, kS*22, kS*3);
    // Shoulder pads / armor detail
    c.fillStyle = '#111';
    c.fillRect(kx - kS*11, ky + kS*5 + kBreathe, kS*3, kS*4);
    c.fillRect(kx + kS*9, ky + kS*5 + kBreathe, kS*3, kS*4);
    
    // Head (blocky, sinister)
    c.fillStyle = '#070707';
    c.fillRect(kx - kS*4, ky - kS*5 + kBreathe, kS*8, kS*10);
    c.fillStyle = '#050505';
    c.fillRect(kx - kS*3, ky - kS*4 + kBreathe, kS*6, kS*8);
    // Head details (mask-like features)
    c.fillStyle = '#0a0a0a';
    c.fillRect(kx - kS*3, ky - kS*2 + kBreathe, kS*6, kS); // mask line
    c.fillRect(kx - kS*3, ky + kS*2 + kBreathe, kS*6, kS); // jaw line
    
    // GLOWING RED EYES (pixel perfect, intimidating)
    let eyePulse = Math.sin(menuAnimFrame * 0.05) * 0.3 + 0.7;
    // Eye sockets (dark)
    c.fillStyle = '#000'; c.fillRect(kx - kS*3, ky + kBreathe, kS*2, kS*2); c.fillRect(kx + kS*2, ky + kBreathe, kS*2, kS*2);
    // Eyes (red glow)
    c.fillStyle = `rgba(255,0,0,${eyePulse})`; 
    c.fillRect(kx - kS*2, ky + kBreathe, kS, kS); c.fillRect(kx + kS*2, ky + kBreathe, kS, kS);
    // Eye highlight
    c.fillStyle = `rgba(255,80,0,${eyePulse * 0.8})`;
    c.fillRect(kx - kS*3, ky + kBreathe, kS, kS); c.fillRect(kx + kS*3, ky + kBreathe, kS, kS);
    // Eye glow bleed
    c.fillStyle = `rgba(255,0,0,${eyePulse * 0.15})`;
    c.fillRect(kx - kS*4, ky - kS + kBreathe, kS*9, kS*3);
    
    // Arms (angular, blocky)
    c.fillStyle = '#080808';
    c.fillRect(kx - kS*11, ky + kS*9 + kBreathe, kS*2, kS*16); // left arm
    c.fillRect(kx + kS*10, ky + kS*9 + kBreathe, kS*2, kS*14); // right arm
    // Arm details (wrappings/armor)
    c.fillStyle = '#111';
    c.fillRect(kx - kS*11, ky + kS*12 + kBreathe, kS*2, kS); c.fillRect(kx - kS*11, ky + kS*18 + kBreathe, kS*2, kS);
    c.fillRect(kx + kS*10, ky + kS*11 + kBreathe, kS*2, kS); c.fillRect(kx + kS*10, ky + kS*16 + kBreathe, kS*2, kS);
    
    // Weapon (massive pixel art blade hanging from right hand)
    c.fillStyle = '#333';
    c.fillRect(kx + kS*10, ky + kS*22 + kBreathe, kS*2, kS*18); // blade shaft
    c.fillStyle = '#444';
    c.fillRect(kx + kS*10, ky + kS*22 + kBreathe, kS, kS*18); // blade highlight
    c.fillStyle = '#222';
    c.fillRect(kx + kS*11, ky + kS*22 + kBreathe, kS, kS*18); // blade shadow
    // Handle/guard
    c.fillStyle = '#555'; c.fillRect(kx + kS*9, ky + kS*21 + kBreathe, kS*4, kS*2);
    c.fillStyle = '#666'; c.fillRect(kx + kS*9, ky + kS*21 + kBreathe, kS*4, kS);
    // Blade tip
    c.fillStyle = '#555'; c.fillRect(kx + kS*10, ky + kS*39 + kBreathe, kS, kS*2);
    // Blade gleam (animated pixel)
    let gleamY = (menuAnimFrame * 0.5) % (kS*18);
    c.fillStyle = '#ffffff22'; c.fillRect(kx + kS*10, ky + kS*22 + kBreathe + gleamY, kS, kS*2);
    
    // Legs
    c.fillStyle = '#080808';
    c.fillRect(kx - kS*5, ky + kS*27 + kBreathe, kS*4, kS*14);
    c.fillRect(kx + kS*2, ky + kS*27 + kBreathe, kS*4, kS*14);
    // Boots
    c.fillStyle = '#0a0a0a';
    c.fillRect(kx - kS*6, ky + kS*39 + kBreathe, kS*5, kS*3);
    c.fillRect(kx + kS*2, ky + kS*39 + kBreathe, kS*5, kS*3);
    
    // Red aura (pixel blocks)
    c.fillStyle = `rgba(255,0,0,${0.04 * eyePulse})`;
    for (let i = 0; i < 8; i++) {
        let ax = kx + Math.floor(Math.sin(menuAnimFrame * 0.01 + i * 0.8) * kS * 14);
        let ay = ky + kS * (i * 5);
        c.fillRect(ax, ay + kBreathe, kS, kS*2);
    }
    
    // === PIXEL ART EMBERS / SPARKS ===
    for (let p of menuParticles) {
        p.y -= p.speed;
        p.x += Math.sin(menuAnimFrame * 0.008 + p.drift) * 0.3;
        if (p.y < -10) { p.y = fireY + Math.random() * 20; p.x = fireX + (Math.random() - 0.5) * 40; }
        
        let flick = Math.sin(menuAnimFrame * 0.06 + p.drift) * 0.15;
        // Embers as pixel squares (not circles)
        c.fillStyle = `rgba(255,${100 + Math.floor((p.drift * 30) % 100)},0,${p.alpha + flick})`;
        let epx = Math.floor(p.x / PX) * PX;
        let epy = Math.floor(p.y / PX) * PX;
        c.fillRect(epx, epy, PX, PX);
    }
    
    // === PIXEL ART FOG (horizontal bands of pixel blocks) ===
    c.fillStyle = `rgba(20,30,40,${0.12 + Math.sin(menuAnimFrame * 0.005) * 0.04})`;
    let fogOff = (menuAnimFrame * 0.3) % (PX*8);
    for (let i = 0; i < Math.floor(W / (PX*8)) + 2; i++) {
        let fx = i * PX * 8 - fogOff;
        let fy = Math.floor(H * 0.6 / PX) * PX + ((i * 3) % 4) * PX;
        c.fillRect(fx, fy, PX*6, PX*2);
    }
    c.fillStyle = `rgba(15,20,30,${0.08 + Math.cos(menuAnimFrame * 0.007) * 0.03})`;
    let fogOff2 = (menuAnimFrame * 0.2) % (PX*6);
    for (let i = 0; i < Math.floor(W / (PX*6)) + 2; i++) {
        let fx = i * PX * 6 + fogOff2;
        let fy = Math.floor(H * 0.55 / PX) * PX + ((i * 5) % 3) * PX;
        c.fillRect(fx, fy, PX*4, PX);
    }
    
    // === PIXEL VIGNETTE (stepped opacity blocks at edges) ===
    // Top
    c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(0, 0, W, H * 0.04);
    c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(0, H * 0.04, W, H * 0.04);
    // Bottom
    c.fillStyle = 'rgba(0,0,0,0.5)'; c.fillRect(0, H * 0.92, W, H * 0.08);
    c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(0, H * 0.88, W, H * 0.04);
    // Left
    c.fillStyle = 'rgba(0,0,0,0.5)'; c.fillRect(0, 0, W * 0.03, H);
    c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(W * 0.03, 0, W * 0.03, H);
    // Right
    c.fillStyle = 'rgba(0,0,0,0.5)'; c.fillRect(W * 0.97, 0, W * 0.03, H);
    c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(W * 0.94, 0, W * 0.03, H);
    
    // === SCANLINE EFFECT (retro CRT feel) ===
    c.fillStyle = 'rgba(0,0,0,0.04)';
    for (let sy = 0; sy < H; sy += PX * 2) {
        c.fillRect(0, sy, W, PX);
    }
    
    requestAnimationFrame(animateMenu);
}

// ============================================================
// LOBBY BACKGROUND + CHARACTER SPRITES
// ============================================================
let lobbyAnimFrame = 0;

function initLobbyBackground() {
    const bgCanvas = document.getElementById('lobby-bg-canvas');
    if (!bgCanvas) return;
    // Render at half resolution for crispier pixel art, CSS scales it up
    bgCanvas.width = Math.floor(window.innerWidth / 2);
    bgCanvas.height = Math.floor(window.innerHeight / 2);
    animateLobby();
}

function animateLobby() {
    if (gameState !== GAME_STATES.LOBBY) return;
    const bgCanvas = document.getElementById('lobby-bg-canvas');
    if (!bgCanvas) return;
    const c = bgCanvas.getContext('2d');
    const W = bgCanvas.width, H = bgCanvas.height;
    lobbyAnimFrame++;
    
    // Pixel art grid size
    const PX = 2;
    
    // === PIXEL ART DARK FOGGY SWAMP BACKGROUND ===
    // Sky bands (no gradients - pure pixel art)
    c.fillStyle = '#1a0a00'; c.fillRect(0, 0, W, H * 0.2);
    c.fillStyle = '#1f0e04'; c.fillRect(0, H * 0.2, W, H * 0.15);
    c.fillStyle = '#241208'; c.fillRect(0, H * 0.35, W, H * 0.15);
    c.fillStyle = '#1a0a04'; c.fillRect(0, H * 0.5, W, H * 0.15);
    c.fillStyle = '#120602'; c.fillRect(0, H * 0.65, W, H * 0.35);
    
    // Pixel art fog layers (horizontal pixel blocks)
    c.fillStyle = `rgba(50,30,12,${0.15 + Math.sin(lobbyAnimFrame * 0.004) * 0.04})`;
    let fogOffset = (lobbyAnimFrame * 0.4) % (PX * 10);
    for (let i = 0; i < Math.floor(W / (PX*10)) + 2; i++) {
        let fx = i * PX * 10 - fogOffset;
        let fy = Math.floor(H * 0.35 / PX) * PX + ((i * 7) % 5) * PX;
        c.fillRect(fx, fy, PX*8, PX*2);
    }
    c.fillStyle = `rgba(35,18,6,${0.12 + Math.cos(lobbyAnimFrame * 0.006) * 0.03})`;
    let fogOffset2 = (lobbyAnimFrame * 0.25) % (PX * 8);
    for (let i = 0; i < Math.floor(W / (PX*8)) + 2; i++) {
        let fx = i * PX * 8 + fogOffset2;
        let fy = Math.floor(H * 0.5 / PX) * PX + ((i * 3) % 4) * PX;
        c.fillRect(fx, fy, PX*6, PX);
    }
    
    // Pixel art dead trees (blocky, angular silhouettes)
    c.fillStyle = '#0a0502';
    for (let i = 0; i < 14; i++) {
        let tx = Math.floor((W * (0.2 + i * 0.05) + Math.sin(i * 5) * 12) / PX) * PX;
        let tWidth = PX * (1 + i % 2);
        let tTop = Math.floor(H * (0.1 + (i * 3) % 15 * 0.01) / PX) * PX;
        let tBottom = Math.floor(H * 0.68 / PX) * PX;
        c.fillRect(tx, tTop, tWidth, tBottom - tTop);
        // Branches (pixel art L-shapes)
        if (i % 2 === 0) {
            c.fillRect(tx - PX*2, tTop + (tBottom - tTop) * 0.3, PX*3, PX);
            c.fillRect(tx - PX*2, tTop + (tBottom - tTop) * 0.3 - PX, PX, PX*2);
        }
        if (i % 3 === 0) {
            c.fillRect(tx + tWidth, tTop + (tBottom - tTop) * 0.5, PX*3, PX);
            c.fillRect(tx + tWidth + PX*2, tTop + (tBottom - tTop) * 0.5 - PX, PX, PX*2);
        }
        // Knots on trunk (pixel detail)
        if (i % 4 === 0) {
            c.fillStyle = '#120804';
            c.fillRect(tx, tTop + (tBottom - tTop) * 0.4, tWidth, PX);
            c.fillStyle = '#0a0502';
        }
    }
    
    // Ground (layered pixel bands)
    let groundY = Math.floor(H * 0.68 / PX) * PX;
    c.fillStyle = '#0f0804'; c.fillRect(0, groundY, W, PX*2);
    c.fillStyle = '#0a0502'; c.fillRect(0, groundY + PX*2, W, H - groundY - PX*2);
    // Ground detail (scattered pixel debris and roots)
    c.fillStyle = '#14090488';
    for (let i = 0; i < 40; i++) {
        let gx = Math.floor(((i * 151 + 47) % W) / PX) * PX;
        let gy = groundY + PX * (1 + (i * 41) % 10);
        c.fillRect(gx, gy, PX * (1 + i % 2), PX);
    }
    // Roots emerging from trees
    c.fillStyle = '#0d0703';
    for (let i = 0; i < 6; i++) {
        let rx = Math.floor((W * (0.22 + i * 0.12)) / PX) * PX;
        c.fillRect(rx, groundY, PX*3, PX); c.fillRect(rx + PX, groundY + PX, PX*4, PX);
    }
    
    // === PIXEL ART CAMPFIRE (left side, large) ===
    let fireX = Math.floor(W * 0.12 / PX) * PX, fireY = Math.floor(H * 0.58 / PX) * PX;
    let fl1 = Math.floor(Math.sin(lobbyAnimFrame * 0.12) * 2);
    let fl2 = Math.floor(Math.cos(lobbyAnimFrame * 0.15) * 1);
    
    // Fire glow (pixel blocks radiating outward)
    c.fillStyle = `rgba(255,100,20,${0.08 + Math.sin(lobbyAnimFrame * 0.07) * 0.03})`;
    c.fillRect(fireX - PX*15, fireY - PX*12, PX*30, PX*20);
    c.fillStyle = `rgba(200,60,0,${0.04})`;
    c.fillRect(fireX - PX*22, fireY - PX*16, PX*44, PX*28);
    
    // Pixel art logs (detailed with bark texture)
    c.fillStyle = '#2a1505'; c.fillRect(fireX - PX*6, fireY + PX*3, PX*5, PX*2);
    c.fillRect(fireX + PX*2, fireY + PX*3, PX*5, PX*2);
    c.fillStyle = '#1a0a02'; c.fillRect(fireX - PX*3, fireY + PX*4, PX*7, PX*2);
    // Log bark detail
    c.fillStyle = '#3a2008'; c.fillRect(fireX - PX*6, fireY + PX*3, PX, PX); c.fillRect(fireX + PX*6, fireY + PX*3, PX, PX);
    // Log end faces
    c.fillStyle = '#4a3010'; c.fillRect(fireX - PX*6, fireY + PX*3, PX, PX*2); c.fillRect(fireX + PX*6, fireY + PX*3, PX, PX*2);
    // Ring pattern on log end
    c.fillStyle = '#5a4020'; c.fillRect(fireX - PX*6, fireY + PX*4, PX, PX);
    
    // Pixel art fire (layered rectangular flames)
    // Outer flame (dark red/maroon)
    c.fillStyle = '#881800';
    c.fillRect(fireX - PX*4, fireY - PX*3 + fl1*PX, PX*9, PX*6);
    c.fillRect(fireX - PX*3, fireY - PX*6 + fl1*PX, PX*7, PX*3);
    c.fillRect(fireX - PX*2, fireY - PX*8 + fl1*PX, PX*5, PX*2);
    c.fillRect(fireX - PX, fireY - PX*9 + fl1*PX, PX*3, PX);
    // Mid flame (bright orange)
    c.fillStyle = '#cc4400';
    c.fillRect(fireX - PX*3, fireY - PX*2 + fl1*PX, PX*7, PX*5);
    c.fillRect(fireX - PX*2, fireY - PX*5 + fl1*PX, PX*5, PX*3);
    c.fillRect(fireX - PX, fireY - PX*7 + fl1*PX, PX*3, PX*2);
    // Inner flame (orange-yellow)
    c.fillStyle = '#ff7700';
    c.fillRect(fireX - PX*2, fireY - PX*2 + fl1*PX, PX*5, PX*4);
    c.fillRect(fireX - PX, fireY - PX*5 + fl1*PX, PX*3, PX*3);
    c.fillRect(fireX + fl2*PX, fireY - PX*6 + fl1*PX, PX*2, PX);
    // Hot center (yellow)
    c.fillStyle = '#ffaa00';
    c.fillRect(fireX - PX, fireY - PX + fl1*PX, PX*3, PX*3);
    c.fillRect(fireX, fireY - PX*3 + fl1*PX, PX*2, PX*2);
    // White hot core
    c.fillStyle = '#ffdd44';
    c.fillRect(fireX, fireY + fl1*PX, PX*2, PX*2);
    c.fillStyle = '#fff';
    c.fillRect(fireX, fireY + PX + fl1*PX, PX, PX);
    // Flame tips (flying pixels)
    c.fillStyle = '#ff4400';
    c.fillRect(fireX - PX*2 + fl2*PX, fireY - PX*10 + fl1*PX, PX, PX);
    c.fillRect(fireX + PX*3 - fl2*PX, fireY - PX*11 + fl1*PX, PX, PX);
    c.fillStyle = '#ff8800';
    c.fillRect(fireX + fl2*PX, fireY - PX*12 + fl1*PX, PX, PX);
    
    // Pixel embers rising from fire
    for (let i = 0; i < 10; i++) {
        let ex = Math.floor((fireX + Math.sin(lobbyAnimFrame * 0.02 + i * 1.5) * (12 + i * 3)) / PX) * PX;
        let ey = Math.floor((fireY - PX*8 - (lobbyAnimFrame * 0.4 + i * 25) % 100) / PX) * PX;
        let ea = 1 - ((lobbyAnimFrame * 0.4 + i * 25) % 100) / 100;
        c.fillStyle = `rgba(255,${80 + i * 15},0,${ea * 0.7})`;
        c.fillRect(ex, ey, PX, PX);
    }
    
    // === PIXEL ART RED GLOWING DOTS ON GROUND (entity influence) ===
    for (let i = 0; i < 18; i++) {
        let rx = Math.floor((W * (0.28 + (i % 6) * 0.11) + Math.sin(i * 3) * 8) / PX) * PX;
        let ry = Math.floor((H * (0.72 + Math.floor(i / 6) * 0.07) + Math.cos(i * 2) * 4) / PX) * PX;
        let pulse = Math.sin(lobbyAnimFrame * 0.03 + i) * 0.3 + 0.7;
        // Core pixel
        c.fillStyle = `rgba(255,20,0,${0.4 * pulse})`;
        c.fillRect(rx, ry, PX, PX);
        // Glow around (1px border)
        c.fillStyle = `rgba(255,40,0,${0.12 * pulse})`;
        c.fillRect(rx - PX, ry, PX, PX); c.fillRect(rx + PX, ry, PX, PX);
        c.fillRect(rx, ry - PX, PX, PX); c.fillRect(rx, ry + PX, PX, PX);
    }
    
    // === PIXEL ART PLAYER SLOT MARKERS ===
    let slotCount = 4;
    for (let i = 0; i < slotCount; i++) {
        let sx = Math.floor(W * (0.3 + i * 0.12) / PX) * PX;
        let sy = Math.floor(H * 0.55 / PX) * PX;
        if (i >= lobbyPlayers.length - 1) {
            // Pixel cross (+) marker
            c.fillStyle = '#ffffff18';
            c.fillRect(sx, sy - PX*3, PX, PX*7); // vertical
            c.fillRect(sx - PX*3, sy, PX*7, PX); // horizontal
            // Corner dots (decorative)
            c.fillStyle = '#ffffff0c';
            c.fillRect(sx - PX*2, sy - PX*2, PX, PX); c.fillRect(sx + PX*2, sy - PX*2, PX, PX);
            c.fillRect(sx - PX*2, sy + PX*2, PX, PX); c.fillRect(sx + PX*2, sy + PX*2, PX, PX);
        }
    }
    
    // === PIXEL ART PLAYER CHARACTERS (large, detailed pixel art sprites) ===
    let survPlayers = lobbyPlayers.filter(p => p.role === 'survivor');
    let totalSlots = 4;
    for (let i = 0; i < totalSlots; i++) {
        let sx = Math.floor(W * (0.35 + i * 0.14) / PX) * PX;
        let sy = Math.floor(H * 0.42 / PX) * PX;
        let scale = Math.max(Math.floor(H * 0.004 / PX), 1) * PX;
        let s = scale; // shorthand
        
        if (i < survPlayers.length) {
            let sp = survPlayers[i];
            let charData = SURVIVORS[sp.char];
            if (!charData) continue;
            let idle = Math.sin(lobbyAnimFrame * 0.03 + i * 1.5);
            let bob = Math.floor(idle * 0.5) * PX;
            let shirtCol = charData.shirtColor || '#888888';
            let hairCol = charData.color || '#332211';
            let skinTone = sp.char === 'claudette' ? '#8a6644' : (sp.char === 'feng' ? '#eeccaa' : '#ddb088');
            
            // Shadow (pixel art)
            c.fillStyle = '#00000044'; c.fillRect(sx - s*3, sy + s*15 + bob, s*7, s);
            
            // Shoes
            c.fillStyle = '#1a1a1a'; c.fillRect(sx - s*2, sy + s*14 + bob, s*2, s); c.fillRect(sx + s*1, sy + s*14 + bob, s*2, s);
            
            // Legs (jeans pixel art)
            c.fillStyle = '#222244'; c.fillRect(sx - s*2, sy + s*9 + bob, s*2, s*5); c.fillRect(sx + s*1, sy + s*9 + bob, s*2, s*5);
            // Knee highlight
            c.fillStyle = '#2a2a55'; c.fillRect(sx - s*2, sy + s*11 + bob, s*2, s); c.fillRect(sx + s*1, sy + s*11 + bob, s*2, s);
            
            // Body (shirt)
            c.fillStyle = charData.secondaryColor || '#333'; c.fillRect(sx - s*3, sy + s*2 + bob, s*7, s*8);
            c.fillStyle = shirtCol; c.fillRect(sx - s*2, sy + s*3 + bob, s*5, s*6);
            // Shirt detail (collar)
            c.fillStyle = shirtCol; c.fillRect(sx - s, sy + s*2 + bob, s*3, s);
            // Belt pixel
            c.fillStyle = '#333'; c.fillRect(sx - s*2, sy + s*8 + bob, s*5, s);
            c.fillStyle = '#666'; c.fillRect(sx, sy + s*8 + bob, s, s); // buckle
            
            // Arms (pixel art with elbow detail)
            c.fillStyle = shirtCol; c.fillRect(sx - s*4, sy + s*3 + bob, s, s*3); c.fillRect(sx + s*4, sy + s*3 + bob, s, s*3);
            c.fillStyle = skinTone; c.fillRect(sx - s*4, sy + s*6 + bob + Math.floor(idle)*PX, s, s*3);
            c.fillRect(sx + s*4, sy + s*6 + bob - Math.floor(idle)*PX, s, s*3);
            
            // Head (pixel art face)
            c.fillStyle = skinTone; c.fillRect(sx - s*2, sy - s*5 + bob, s*5, s*6);
            // Ears
            c.fillStyle = skinTone; c.fillRect(sx - s*3, sy - s*3 + bob, s, s*2); c.fillRect(sx + s*3, sy - s*3 + bob, s, s*2);
            
            // Hair (detailed pixel art - different per character)
            c.fillStyle = hairCol;
            c.fillRect(sx - s*2, sy - s*7 + bob, s*5, s*3); // top
            c.fillRect(sx - s*3, sy - s*6 + bob, s, s*4); // side left
            c.fillRect(sx + s*3, sy - s*6 + bob, s, s*4); // side right
            // Hair highlight
            c.fillStyle = hairCol + 'cc'; c.fillRect(sx - s, sy - s*7 + bob, s*2, s);
            
            // Eyes (pixel art with detail)
            c.fillStyle = '#fff'; c.fillRect(sx - s*2, sy - s*3 + bob, s*2, s*2); c.fillRect(sx + s, sy - s*3 + bob, s*2, s*2);
            c.fillStyle = '#222'; c.fillRect(sx - s, sy - s*3 + bob, s, s*2); c.fillRect(sx + s*2, sy - s*3 + bob, s, s*2);
            // Eye shine
            c.fillStyle = '#fff'; c.fillRect(sx - s*2, sy - s*3 + bob, s, s); c.fillRect(sx + s, sy - s*3 + bob, s, s);
            
            // Mouth
            c.fillStyle = '#aa7766'; c.fillRect(sx - s, sy - s + bob, s*3, s);
            
            // Fire reflection on character (warm glow on left side)
            let fireRef = Math.sin(lobbyAnimFrame * 0.1 + i) * 0.08 + 0.1;
            c.fillStyle = `rgba(255,100,30,${fireRef})`;
            c.fillRect(sx - s*3, sy - s*5 + bob, s*2, s*18);
            
            // Name above (pixel font feel)
            c.fillStyle = '#ffffffbb'; c.font = `bold ${Math.max(s*2, 10)}px monospace`; c.textAlign = 'center';
            c.fillText(charData.name, sx + s, sy - s*9 + bob);
        } else {
            // Empty slot: pixel art cross marker
            c.fillStyle = '#ffffff1a';
            c.fillRect(sx, sy - s*3, PX, PX*7); // vertical
            c.fillRect(sx - PX*3, sy, PX*7, PX); // horizontal
            // Dashed border (pixel dots)
            c.fillStyle = '#ffffff0a';
            for (let d = 0; d < 8; d++) {
                c.fillRect(sx - PX*4 + d * PX, sy - PX*5, PX, PX);
                c.fillRect(sx - PX*4 + d * PX, sy + PX*5, PX, PX);
                c.fillRect(sx - PX*4, sy - PX*5 + d * PX + PX, PX, PX);
                c.fillRect(sx + PX*4, sy - PX*5 + d * PX + PX, PX, PX);
            }
        }
    }
    
    // === PIXEL VIGNETTE (stepped bands) ===
    c.fillStyle = 'rgba(0,0,0,0.4)'; c.fillRect(0, 0, W, H * 0.03);
    c.fillStyle = 'rgba(0,0,0,0.2)'; c.fillRect(0, H * 0.03, W, H * 0.03);
    c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(0, H * 0.94, W, H * 0.06);
    c.fillStyle = 'rgba(0,0,0,0.15)'; c.fillRect(0, H * 0.91, W, H * 0.03);
    c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(0, 0, W * 0.02, H);
    c.fillStyle = 'rgba(0,0,0,0.15)'; c.fillRect(W * 0.02, 0, W * 0.02, H);
    c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(W * 0.98, 0, W * 0.02, H);
    c.fillStyle = 'rgba(0,0,0,0.15)'; c.fillRect(W * 0.96, 0, W * 0.02, H);
    
    // === SCANLINE EFFECT (retro CRT) ===
    c.fillStyle = 'rgba(0,0,0,0.03)';
    for (let sy2 = 0; sy2 < H; sy2 += PX * 2) {
        c.fillRect(0, sy2, W, PX);
    }
    
    requestAnimationFrame(animateLobby);
}

// Draw animated character sprite for lobby
function drawLobbyCharSprite(slotCanvas, role, charKey, skinKey, animFrame) {
    const sCtx = slotCanvas.getContext('2d');
    slotCanvas.width = 60;
    slotCanvas.height = 80;
    sCtx.clearRect(0, 0, 60, 80);
    
    const charData = role === 'killer' ? KILLERS[charKey] : SURVIVORS[charKey];
    const skinData = SKINS[role]?.[skinKey] || null;
    if (!charData) return;
    
    // Apply cosmetic colors if available
    let cosmeticColors = { head: null, body: null, weapon: null };
    if (typeof getEquippedCosmetics === 'function' && typeof CHAR_COSMETICS !== 'undefined' && CHAR_COSMETICS[charKey]) {
        let eq = getEquippedCosmetics(charKey);
        let cosmData = CHAR_COSMETICS[charKey];
        if (cosmData.head) { let h = cosmData.head.find(c => c.key === eq.head); if (h && h.key !== 'default') cosmeticColors.head = h.color; }
        if (cosmData.body) { let b = cosmData.body.find(c => c.key === eq.body); if (b && b.key !== 'default') cosmeticColors.body = b.color; }
        if (cosmData.weapon) { let w = cosmData.weapon.find(c => c.key === eq.weapon); if (w && w.key !== 'default') cosmeticColors.weapon = w.color; }
    }
    
    const x = 30, y = 55;
    const bobY = Math.sin(animFrame * 0.04) * 2;
    const breathe = Math.sin(animFrame * 0.02) * 0.5;
    
    // Shadow
    sCtx.fillStyle = 'rgba(0,0,0,0.4)';
    sCtx.beginPath();
    sCtx.ellipse(x, y + 18, 12, 5, 0, 0, Math.PI * 2);
    sCtx.fill();
    
    if (role === 'killer') {
        let mainColor = cosmeticColors.body || skinData?.color || charData.color;
        let secColor = skinData?.secondaryColor || charData.secondaryColor;
        let weapColor = cosmeticColors.weapon || skinData?.weaponColor || charData.weaponColor;
        let glowCol = skinData?.glowColor || charData.glowColor;
        let headCol = cosmeticColors.head || mainColor;
        
        // Glow under
        sCtx.fillStyle = glowCol + '22';
        sCtx.beginPath();
        sCtx.arc(x, y + 14, 18, 0, Math.PI * 2);
        sCtx.fill();
        
        // Body
        sCtx.fillStyle = secColor;
        sCtx.fillRect(x - 10, y - 5 + bobY, 20, 18);
        sCtx.fillStyle = mainColor;
        sCtx.fillRect(x - 9, y - 3 + bobY, 18, 14);
        
        // Head
        sCtx.fillStyle = headCol;
        sCtx.fillRect(x - 7, y - 16 + bobY, 14, 12);
        sCtx.fillStyle = '#00000066';
        sCtx.fillRect(x - 6, y - 14 + bobY, 12, 8);
        
        // Eyes (glowing)
        sCtx.fillStyle = '#ff0000';
        sCtx.shadowColor = '#ff0000';
        sCtx.shadowBlur = 6;
        sCtx.fillRect(x - 4, y - 12 + bobY, 3, 3);
        sCtx.fillRect(x + 2, y - 12 + bobY, 3, 3);
        sCtx.shadowBlur = 0;
        
        // Weapon
        sCtx.fillStyle = weapColor;
        sCtx.fillRect(x + 10, y - 10 + bobY, 3, 16 + breathe);
        sCtx.fillStyle = '#ffffff44';
        sCtx.fillRect(x + 10, y - 10 + bobY, 3, 2);
        
        // Legs
        sCtx.fillStyle = '#111111';
        let legAnim = Math.sin(animFrame * 0.03) * 1;
        sCtx.fillRect(x - 5, y + 12 + bobY, 4, 8 + legAnim);
        sCtx.fillRect(x + 2, y + 12 + bobY, 4, 8 - legAnim);
    } else {
        let shirtCol = cosmeticColors.body || skinData?.shirtColor || charData.shirtColor;
        let secCol = skinData?.secondaryColor || charData.secondaryColor;
        let hairCol = cosmeticColors.head || skinData?.color || charData.color;
        
        // Body
        sCtx.fillStyle = secCol;
        sCtx.fillRect(x - 7, y - 3 + bobY, 14, 15);
        sCtx.fillStyle = shirtCol;
        sCtx.fillRect(x - 6, y - 1 + bobY, 12, 11);
        
        // Arms
        sCtx.fillStyle = '#ddb088';
        sCtx.fillRect(x - 8, y - 1 + bobY, 2, 9);
        sCtx.fillRect(x + 7, y - 1 + bobY, 2, 9);
        
        // Head
        sCtx.fillStyle = '#ddb088';
        sCtx.fillRect(x - 5, y - 14 + bobY, 10, 11);
        
        // Hair
        sCtx.fillStyle = hairCol;
        sCtx.fillRect(x - 6, y - 16 + bobY, 12, 5);
        sCtx.fillRect(x - 5, y - 14 + bobY, 2, 3);
        sCtx.fillRect(x + 4, y - 14 + bobY, 2, 3);
        
        // Eyes
        sCtx.fillStyle = '#222222';
        sCtx.fillRect(x - 3, y - 9 + bobY, 2, 2);
        sCtx.fillRect(x + 2, y - 9 + bobY, 2, 2);
        
        // Legs
        sCtx.fillStyle = '#222244';
        let legAnim = Math.sin(animFrame * 0.03) * 1;
        sCtx.fillRect(x - 4, y + 11 + bobY, 3, 8 + legAnim);
        sCtx.fillRect(x + 2, y + 11 + bobY, 3, 8 - legAnim);
        
        // Shoes
        sCtx.fillStyle = '#1a1a1a';
        sCtx.fillRect(x - 5, y + 18 + bobY + legAnim, 4, 2);
        sCtx.fillRect(x + 2, y + 18 + bobY - legAnim, 4, 2);
    }
}

// ============================================================
// MENU NAVIGATION
// ============================================================
function openLobby(mode) {
    gameMode = mode;
    onlineMode = (mode === 'online' || mode === 'matchmaking');
    gameState = GAME_STATES.LOBBY;
    
    document.getElementById('main-menu').style.display = 'none';
    document.getElementById('lobby-screen').style.display = 'block';
    
    // Show/hide online elements
    document.getElementById('online-connect-area').style.display = (mode === 'online') ? 'block' : 'none';
    document.getElementById('lobby-room-code').style.display = 'none';
    
    // Show/hide find match button
    let findBtn = document.getElementById('find-match-btn');
    if (findBtn) findBtn.style.display = (mode === 'matchmaking') ? 'inline-block' : 'none';
    
    // Populate map select
    const mapSelect = document.getElementById('map-select');
    mapSelect.innerHTML = '<option value="random">🎲 Aleatório</option>';
    Object.entries(MAPS).forEach(([key, m]) => {
        mapSelect.innerHTML += `<option value="${key}">${m.name}</option>`;
    });
    
    // Initialize local lobby
    if (!onlineMode) {
        myPlayerId = 0;
        isHost = true;
        initLocalLobby();
    } else {
        myPlayerId = null;
        lobbyPlayers = [];
        // If matchmaking mode, auto-start the find match process
        if (mode === 'matchmaking') {
            setTimeout(() => findMatch(), 500);
        }
    }
    
    populateCharSelects();
    initLobbyBackground();
    updateLobbyDisplay();
    startLobbyCharAnimation();
}

function backToMenu() {
    gameState = GAME_STATES.MENU;
    document.getElementById('lobby-screen').style.display = 'none';
    document.getElementById('main-menu').style.display = 'flex';
    
    // Disconnect if online
    if (peer && !peer.destroyed) { peer.destroy(); peer = null; }
    peerConnections = [];
    
    initMenuBackground();
    if (typeof updateProfileUI === 'function') updateProfileUI();
}

function openSettings() {
    document.getElementById('settings-panel').style.display = 'flex';
    renderSettings();
}

function openShop() {
    document.getElementById('settings-panel').style.display = 'flex';
    renderShopPanel();
}

function updateProfileUI() {
    let bpEl = document.getElementById('menu-bp');
    let lvEl = document.getElementById('menu-level');
    let pEl = document.getElementById('menu-prestige');
    if (bpEl) bpEl.textContent = playerProfile.bloodpoints;
    if (lvEl) lvEl.textContent = playerProfile.level;
    if (pEl) pEl.textContent = playerProfile.prestige;
}

function closeSettings() {
    document.getElementById('settings-panel').style.display = 'none';
}

function renderSettings() {
    const content = document.getElementById('settings-content');
    
    content.innerHTML = `
        <div class="settings-section">
            <h3>🔓 Modo Administrador</h3>
            <p style="color:#888;font-size:0.8em;margin-bottom:8px;">Desbloqueia todos os personagens, skins e dá BP infinito.</p>
            <button onclick="toggleAdminMode()" style="padding:10px 20px;background:${typeof adminMode!=='undefined'&&adminMode?'#004400':'#440000'};border:1px solid ${typeof adminMode!=='undefined'&&adminMode?'#00aa00':'#880000'};color:${typeof adminMode!=='undefined'&&adminMode?'#44ff44':'#ff6666'};cursor:pointer;font-family:inherit;border-radius:4px;">${typeof adminMode!=='undefined'&&adminMode?'✓ ADMIN ATIVO':'ATIVAR ADMIN'}</button>
        </div>
        <div class="settings-section">
            <h3>📱 Controles</h3>
            <p style="color:#888;font-size:0.8em;">
                <strong>Survivor:</strong> WASD/Setas = mover | E/Space = ação | Q = habilidade/item<br>
                <strong>Killer:</strong> WASD = mover | E = atacar/pegar | Q = habilidade<br>
                <strong>Mobile:</strong> Joystick esquerdo + botões direita<br>
                <strong>Pallet:</strong> E perto = pular (caída) ou derrubar (em pé)
            </p>
        </div>
        <div class="settings-section">
            <h3>📊 Estatísticas</h3>
            <p style="color:#888;font-size:0.8em;">
                Partidas: ${playerProfile?.totalMatches||0} | Kills: ${playerProfile?.totalKills||0} | Escapes: ${playerProfile?.totalEscapes||0}
            </p>
        </div>
        <div class="settings-section">
            <h3>🗑️ Resetar Progresso</h3>
            <button onclick="if(confirm('Tem certeza? Isso apaga TUDO.')){localStorage.removeItem('dbp_profile');location.reload();}" style="padding:8px 16px;background:#330000;border:1px solid #660000;color:#ff4444;cursor:pointer;font-family:inherit;border-radius:4px;">RESETAR TUDO</button>
        </div>
    `;
}

function togglePerk(perkKey, role) {
    if (selectedPerks[role].includes(perkKey)) {
        selectedPerks[role] = selectedPerks[role].filter(p => p !== perkKey);
    } else {
        if (selectedPerks[role].length >= 2) selectedPerks[role].shift();
        selectedPerks[role].push(perkKey);
    }
    renderSettings();
}

// ============================================================
// LOBBY SYSTEM
// ============================================================
function initLocalLobby() {
    const count = parseInt(document.getElementById('player-count-select')?.value || '3');
    lobbyPlayers = [];
    
    // Player 0 is always the player configuring
    lobbyPlayers.push({
        id: 0, role: 'killer', char: 'trapper', skin: 'default',
        confirmed: false, controls: 0, name: 'J1'
    });
    
    const survChars = Object.keys(SURVIVORS);
    for (let i = 1; i < count; i++) {
        lobbyPlayers.push({
            id: i, role: 'survivor', char: survChars[(i - 1) % survChars.length],
            skin: 'default', confirmed: true, controls: i, name: `J${i + 1}`
        });
    }
}

function populateCharSelects() {
    const roleSelect = document.getElementById('my-role-select');
    const charSelect = document.getElementById('my-char-select');
    const skinSelect = document.getElementById('my-skin-select');
    
    onRoleChange();
}

function onRoleChange() {
    const role = document.getElementById('my-role-select').value;
    const charSelect = document.getElementById('my-char-select');
    const skinSelect = document.getElementById('my-skin-select');
    
    const chars = role === 'killer' ? KILLERS : SURVIVORS;
    let unlocked = role === 'killer' 
        ? (typeof playerProfile !== 'undefined' ? playerProfile.unlockedKillers : Object.keys(chars))
        : (typeof playerProfile !== 'undefined' ? playerProfile.unlockedSurvivors : Object.keys(chars));
    
    charSelect.innerHTML = Object.entries(chars)
        .filter(([k]) => unlocked.includes(k))
        .map(([k, v]) => `<option value="${k}">${v.name} — ${v.desc}</option>`).join('');
    
    // Filter skins by unlocked
    const skins = SKINS[role];
    let unlockedSkins = typeof playerProfile !== 'undefined' ? playerProfile.unlockedSkins[role] : ['default'];
    skinSelect.innerHTML = Object.entries(skins)
        .filter(([k]) => unlockedSkins.includes(k))
        .map(([k, v]) => `<option value="${k}">${v.icon} ${v.name}</option>`).join('');
    
    renderCharGrid(role);
    renderPerkList(role);
    onCharChange();
}

function selectRole(role) {
    document.getElementById('my-role-select').value = role;
    // Highlight button
    document.getElementById('role-killer-btn').style.borderColor = role === 'killer' ? '#ff4444' : '#660000';
    document.getElementById('role-killer-btn').style.opacity = role === 'killer' ? '1' : '0.5';
    document.getElementById('role-surv-btn').style.borderColor = role === 'survivor' ? '#44ff44' : '#004400';
    document.getElementById('role-surv-btn').style.opacity = role === 'survivor' ? '1' : '0.5';
    onRoleChange();
}

function renderCharGrid(role) {
    const grid = document.getElementById('char-grid');
    if (!grid) return;
    const chars = role === 'killer' ? KILLERS : SURVIVORS;
    let unlocked = role === 'killer'
        ? (typeof playerProfile !== 'undefined' ? playerProfile.unlockedKillers : Object.keys(chars))
        : (typeof playerProfile !== 'undefined' ? playerProfile.unlockedSurvivors : Object.keys(chars));
    
    let currentChar = document.getElementById('my-char-select').value;
    let html = '';
    for (let [key, data] of Object.entries(chars)) {
        let isUnlocked = unlocked.includes(key);
        let isSelected = key === currentChar;
        let borderCol = isSelected ? (role === 'killer' ? '#ff4444' : '#44ff44') : (isUnlocked ? '#333' : '#1a1a1a');
        let bg = isSelected ? (role === 'killer' ? '#2a0808' : '#082a08') : '#0a0a14';
        html += `<div onclick="${isUnlocked ? `selectChar('${key}')` : ''}" style="padding:6px;background:${bg};border:2px solid ${borderCol};border-radius:4px;cursor:${isUnlocked ? 'pointer' : 'default'};opacity:${isUnlocked ? '1' : '0.35'};text-align:center;transition:all 0.2s;">
            <div style="font-size:0.7em;color:${isSelected ? '#fff' : '#aaa'};">${data.name}</div>
            ${!isUnlocked ? '<div style="font-size:0.6em;color:#666;">🔒</div>' : ''}
        </div>`;
    }
    grid.innerHTML = html;
}

function selectChar(key) {
    const charSelect = document.getElementById('my-char-select');
    charSelect.value = key;
    onCharChange();
}

function prevChar() {
    const charSelect = document.getElementById('my-char-select');
    let idx = charSelect.selectedIndex - 1;
    if (idx < 0) idx = charSelect.options.length - 1;
    charSelect.selectedIndex = idx;
    onCharChange();
}

function nextChar() {
    const charSelect = document.getElementById('my-char-select');
    let idx = charSelect.selectedIndex + 1;
    if (idx >= charSelect.options.length) idx = 0;
    charSelect.selectedIndex = idx;
    onCharChange();
}

function renderPerkList(role) {
    const perks = role === 'killer' ? KILLER_PERKS : SURVIVOR_PERKS;
    const listEl = document.getElementById('perk-list');
    const equippedEl = document.getElementById('equipped-perks');
    if (!listEl || !equippedEl) return;
    
    // Show equipped
    let equipped = selectedPerks[role] || [];
    let eqHtml = '';
    for (let i = 0; i < 2; i++) {
        if (equipped[i]) {
            let p = perks[equipped[i]];
            eqHtml += `<div onclick="unequipPerk('${equipped[i]}','${role}')" style="width:36px;height:36px;background:#1a1500;border:2px solid #ffaa00;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:1.2em;cursor:pointer;" title="${p.name}: ${p.desc}">${p.icon}</div>`;
        } else {
            eqHtml += `<div style="width:36px;height:36px;background:#0a0a14;border:2px dashed #333;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:0.7em;color:#444;">+</div>`;
        }
    }
    equippedEl.innerHTML = eqHtml;
    
    // Show all perks
    let html = '';
    for (let [key, p] of Object.entries(perks)) {
        let isEquipped = equipped.includes(key);
        html += `<div onclick="equipPerk('${key}','${role}')" style="padding:4px;background:${isEquipped ? '#1a1500' : '#0a0a14'};border:1px solid ${isEquipped ? '#ffaa00' : '#222'};border-radius:3px;cursor:pointer;text-align:center;font-size:0.65em;color:${isEquipped ? '#ffcc00' : '#888'};transition:all 0.15s;" title="${p.desc}">
            <span style="font-size:1.4em;">${p.icon}</span><br>${p.name}
        </div>`;
    }
    listEl.innerHTML = html;
}

function equipPerk(key, role) {
    if (selectedPerks[role].includes(key)) return;
    if (selectedPerks[role].length >= 2) selectedPerks[role].shift();
    selectedPerks[role].push(key);
    renderPerkList(role);
}

function unequipPerk(key, role) {
    selectedPerks[role] = selectedPerks[role].filter(p => p !== key);
    renderPerkList(role);
}

function updateCharPreview() {
    const previewCanvas = document.getElementById('char-preview-canvas');
    if (!previewCanvas) return;
    const role = document.getElementById('my-role-select').value;
    const charKey = document.getElementById('my-char-select').value;
    const skinKey = document.getElementById('my-skin-select')?.value || 'default';
    
    // Draw sprite in preview
    if (typeof drawLobbyCharSprite === 'function') {
        drawLobbyCharSprite(previewCanvas, role, charKey, skinKey, lobbyCharFrame);
    }
    
    // Update info panel
    const chars = role === 'killer' ? KILLERS : SURVIVORS;
    const charData = chars[charKey];
    if (charData) {
        let abilEl = document.getElementById('char-info-ability');
        if (abilEl) abilEl.innerHTML = `⚡ ${charData.ability?.toUpperCase() || 'PASSIVE'} <span style="color:#666;">(CD: ${Math.round((charData.abilityCD||0)/60)}s)</span>`;
        // Update lobby right-side labels
        let lobbyName = document.getElementById('lobby-char-name');
        if (lobbyName) lobbyName.textContent = charData.name;
    }
    // Update lobby BP/level displays
    if (typeof playerProfile !== 'undefined') {
        let lbp = document.getElementById('lobby-bp');
        let lbp2 = document.getElementById('lobby-bp2');
        let llv = document.getElementById('lobby-level');
        if (lbp) lbp.textContent = playerProfile.bloodpoints;
        if (lbp2) lbp2.textContent = playerProfile.bloodpoints;
        if (llv) llv.textContent = playerProfile.level;
    }
}

function onCharChange() {
    if (lobbyPlayers.length > 0 && myPlayerId !== null) {
        const role = document.getElementById('my-role-select').value;
        const char = document.getElementById('my-char-select').value;
        const skin = document.getElementById('my-skin-select').value;
        
        let myEntry = lobbyPlayers.find(p => p.id === (myPlayerId || 0));
        if (myEntry) {
            myEntry.role = role;
            myEntry.char = char;
            myEntry.skin = skin;
        }
        updateLobbyDisplay();
        renderCharGrid(role);
        updateCharPreview();
        
        if (onlineMode) broadcastToPeers({ type: 'roleSelect', id: myPlayerId, role, char, skin, confirmed: myReady });
    }
}

function onSkinChange() { onCharChange(); }

function toggleReady() {
    myReady = !myReady;
    const btn = document.getElementById('ready-btn');
    btn.textContent = myReady ? '✗ CANCELAR' : '✓ PRONTO';
    btn.style.background = myReady ? 'linear-gradient(180deg,#884400,#663300)' : '';
    btn.style.borderColor = myReady ? '#ff6600' : '';
    
    let myEntry = lobbyPlayers.find(p => p.id === (myPlayerId || 0));
    if (myEntry) myEntry.confirmed = myReady;
    
    updateLobbyDisplay();
    
    if (onlineMode) {
        const role = document.getElementById('my-role-select').value;
        const char = document.getElementById('my-char-select').value;
        const skin = document.getElementById('my-skin-select').value;
        broadcastToPeers({ type: 'roleSelect', id: myPlayerId, role, char, skin, confirmed: myReady });
    }
}

// Lobby char animation
let lobbyCharAnimInterval = null;
let lobbyCharFrame = 0;

function startLobbyCharAnimation() {
    if (lobbyCharAnimInterval) clearInterval(lobbyCharAnimInterval);
    lobbyCharAnimInterval = setInterval(() => {
        lobbyCharFrame++;
        renderLobbyChars();
    }, 60);
}

function renderLobbyChars() {
    const lineup = document.getElementById('character-lineup');
    if (!lineup) return;
    
    const canvases = lineup.querySelectorAll('.char-sprite-container canvas');
    canvases.forEach((c, i) => {
        if (i < lobbyPlayers.length) {
            const p = lobbyPlayers[i];
            drawLobbyCharSprite(c, p.role, p.char, p.skin, lobbyCharFrame + i * 20);
        }
    });
}

function updateLobbyDisplay() {
    const lineup = document.getElementById('character-lineup');
    if (!lineup) return;
    
    let html = '';
    
    for (let p of lobbyPlayers) {
        const charData = p.role === 'killer' ? KILLERS[p.char] : SURVIVORS[p.char];
        const charName = charData ? charData.name : p.char;
        const isMe = p.id === (myPlayerId || 0);
        const readyClass = p.confirmed ? 'ready' : '';
        const roleClass = p.role === 'killer' ? 'killer-slot' : 'survivor-slot';
        
        html += `
            <div class="char-slot ${roleClass} ${readyClass}">
                <div class="char-sprite-container"><canvas></canvas></div>
                <div class="char-slot-name">${charName}${isMe ? ' (Você)' : ''}</div>
                <span class="char-slot-role ${p.role}">${p.role === 'killer' ? '🔪 KILLER' : '🏃 SURV'}</span>
                <div class="char-slot-status">${p.confirmed ? '✅ Pronto' : '⏳ Aguardando'}</div>
            </div>
        `;
    }
    
    // Empty slots
    const maxPlayers = 5;
    for (let i = lobbyPlayers.length; i < maxPlayers; i++) {
        html += `<div class="char-slot empty-slot"><div class="char-sprite-container" style="opacity:0.3;">—</div><div class="char-slot-name">Vazio</div></div>`;
    }
    
    lineup.innerHTML = html;
    
    // Immediately draw the sprites
    setTimeout(() => renderLobbyChars(), 10);
}

// Update player count for local mode
document.addEventListener('DOMContentLoaded', () => {
    const countSelect = document.getElementById('player-count-select');
    if (countSelect) {
        countSelect.addEventListener('change', () => {
            if (!onlineMode) {
                initLocalLobby();
                updateLobbyDisplay();
            }
        });
    }
});

// ============================================================
// ONLINE MULTIPLAYER (PeerJS P2P)
// ============================================================
function loadPeerJS(callback) {
    if (window.Peer) { callback(); return; }
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js';
    script.onload = callback;
    script.onerror = () => {
        document.getElementById('online-status').textContent = 'Erro ao carregar PeerJS. Verifique internet.';
        document.getElementById('online-status').style.color = '#ff4444';
    };
    document.head.appendChild(script);
}

function createRoom() {
    const statusEl = document.getElementById('online-status');
    statusEl.textContent = 'Criando sala...';
    statusEl.style.color = '#ffaa00';
    
    // Use a matchmaking pool slot so "Find Match" players can discover this room
    let slotId = Math.floor(Math.random() * MATCHMAKING_POOL_SIZE);
    roomCode = 'MATCH-' + slotId;
    document.getElementById('room-code-input').value = roomCode;
    
    loadPeerJS(() => {
        peer = new Peer('dbp-match-' + slotId);
        
        peer.on('open', () => {
            isHost = true;
            myPlayerId = 0;
            statusEl.textContent = `✅ Sala criada! Código: ${roomCode}`;
            statusEl.style.color = '#44ff44';
            document.getElementById('lobby-room-code').textContent = roomCode;
            document.getElementById('lobby-room-code').style.display = 'block';
            document.getElementById('connection-status').textContent = '● Host';
            document.getElementById('connection-status').className = 'connected';
            
            lobbyPlayers = [{ id: 0, role: document.getElementById('my-role-select')?.value || 'killer', char: document.getElementById('my-char-select')?.value || 'trapper', skin: 'default', confirmed: false, name: 'Você' }];
            updateLobbyDisplay();
        });
        
        peer.on('connection', (conn) => {
            peerConnections.push(conn);
            let playerId = peerConnections.length;
            
            conn.on('open', () => {
                statusEl.textContent = `✅ Sala: ${roomCode} — ${peerConnections.length + 1} jogadores`;
                conn.send(JSON.stringify({ type: 'assignId', id: playerId, playerCount: peerConnections.length + 1 }));
                
                lobbyPlayers.push({ id: playerId, role: 'survivor', char: 'meg', skin: 'default', confirmed: false, name: `J${playerId + 1}` });
                updateLobbyDisplay();
                broadcastToPeers({ type: 'lobbyUpdate', players: lobbyPlayers });
            });
            
            conn.on('data', (data) => {
                try { handlePeerMessage(typeof data === 'string' ? JSON.parse(data) : data, conn); } catch (e) { }
            });
            
            conn.on('close', () => {
                peerConnections = peerConnections.filter(c => c !== conn);
                lobbyPlayers = lobbyPlayers.filter(p => p.id <= peerConnections.length);
                updateLobbyDisplay();
                statusEl.textContent = `Sala: ${roomCode} — ${peerConnections.length + 1} jogadores`;
            });
        });
        
        peer.on('error', (err) => {
            if (err.type === 'unavailable-id') {
                // Slot taken, try next one
                slotId = (slotId + 1) % MATCHMAKING_POOL_SIZE;
                roomCode = 'MATCH-' + slotId;
                document.getElementById('room-code-input').value = roomCode;
                if (peer && !peer.destroyed) peer.destroy();
                statusEl.textContent = 'Tentando outro slot...';
                setTimeout(createRoom, 500);
            } else {
                statusEl.textContent = `Erro: ${err.message}`;
                statusEl.style.color = '#ff4444';
            }
        });
    });
}

let matchmakingActive = false;
let matchmakingTimer = null;
const MATCHMAKING_POOL_SIZE = 10; // try 10 possible room IDs

function findMatch() {
    let statusEl = document.getElementById('lobby-match-status');
    let findBtn = document.getElementById('find-match-btn');
    
    if (matchmakingActive) {
        // Cancel matchmaking
        matchmakingActive = false;
        if (matchmakingTimer) { clearInterval(matchmakingTimer); matchmakingTimer = null; }
        if (peer && !peer.destroyed) { peer.destroy(); peer = null; }
        peerConnections = [];
        statusEl.textContent = 'Busca cancelada.';
        statusEl.style.color = '#888';
        if (findBtn) { findBtn.textContent = '🔍 ENCONTRAR PARTIDA'; findBtn.style.borderColor = '#4488aa'; }
        return;
    }
    
    matchmakingActive = true;
    if (findBtn) { findBtn.textContent = '✕ CANCELAR BUSCA'; findBtn.style.borderColor = '#cc4444'; }
    statusEl.textContent = '🔍 Procurando partida...';
    statusEl.style.color = '#ffaa00';
    
    let searchDots = 0;
    let searchTime = 0;
    let foundGame = false;
    
    // Animation timer
    matchmakingTimer = setInterval(() => {
        if (!matchmakingActive) { clearInterval(matchmakingTimer); return; }
        searchTime++;
        searchDots = (searchDots + 1) % 4;
        statusEl.textContent = `🔍 Procurando partida${'.'.repeat(searchDots)} (${searchTime}s)`;
        
        // After 15s without finding anyone, just keep waiting (no bot fallback)
        if (searchTime >= 60 && !foundGame) {
            // After 60s, just reset the counter display
            searchTime = 0;
        }
    }, 1000);
    
    // Strategy: Try to JOIN existing matchmaking rooms first.
    // If no room is found, CREATE one and wait for others.
    loadPeerJS(() => {
        peer = new Peer();
        peer.on('open', () => {
            // Try to connect to existing matchmaking rooms
            let attemptIndex = 0;
            let triedAll = false;
            
            function tryNextRoom() {
                if (!matchmakingActive || foundGame) return;
                if (attemptIndex >= MATCHMAKING_POOL_SIZE) {
                    // No rooms found - become host
                    triedAll = true;
                    becomeMatchmakingHost();
                    return;
                }
                
                let targetId = 'dbp-match-' + attemptIndex;
                attemptIndex++;
                
                let conn = peer.connect(targetId, { reliable: true });
                let timeout = setTimeout(() => {
                    // Connection timeout - try next
                    conn.close();
                    tryNextRoom();
                }, 2000);
                
                conn.on('open', () => {
                    clearTimeout(timeout);
                    if (!matchmakingActive) { conn.close(); return; }
                    // Successfully connected to a host!
                    foundGame = true;
                    matchmakingActive = false;
                    if (matchmakingTimer) { clearInterval(matchmakingTimer); matchmakingTimer = null; }
                    if (findBtn) { findBtn.textContent = '🔍 ENCONTRAR PARTIDA'; findBtn.style.borderColor = '#4488aa'; }
                    
                    onlineMode = true;
                    isHost = false;
                    peerConnections = [conn];
                    roomCode = targetId.replace('dbp-', '').toUpperCase();
                    
                    statusEl.textContent = `✅ Partida encontrada! Conectando...`;
                    statusEl.style.color = '#44ff44';
                    
                    document.getElementById('lobby-room-code').textContent = roomCode;
                    document.getElementById('lobby-room-code').style.display = 'block';
                    
                    conn.on('data', (data) => {
                        try { handlePeerMessage(typeof data === 'string' ? JSON.parse(data) : data, conn); } catch(e){}
                    });
                    conn.on('close', () => {
                        statusEl.textContent = 'Desconectado.';
                        statusEl.style.color = '#ff4444';
                    });
                });
                
                conn.on('error', () => {
                    clearTimeout(timeout);
                    // Room doesn't exist, try next
                    tryNextRoom();
                });
            }
            
            tryNextRoom();
        });
        
        peer.on('error', (err) => {
            // If PeerJS itself errors, fallback to bot match
        });
    });
}

function becomeMatchmakingHost() {
    if (!matchmakingActive) return;
    let statusEl = document.getElementById('lobby-match-status');
    let findBtn = document.getElementById('find-match-btn');
    
    // Destroy old peer and create new one as host with matchmaking ID
    if (peer && !peer.destroyed) { peer.destroy(); peer = null; }
    
    // Pick a random slot in the matchmaking pool
    let slotId = Math.floor(Math.random() * MATCHMAKING_POOL_SIZE);
    roomCode = 'MATCH-' + slotId;
    let peerId = 'dbp-match-' + slotId;
    
    loadPeerJS(() => {
        peer = new Peer(peerId);
        
        peer.on('open', () => {
            isHost = true;
            myPlayerId = 0;
            onlineMode = true;
            lobbyPlayers = [{ id: 0, role: document.getElementById('my-role-select')?.value || 'killer', char: document.getElementById('my-char-select')?.value || 'trapper', skin: 'default', confirmed: true, name: 'Você' }];
            document.getElementById('lobby-room-code').textContent = roomCode;
            document.getElementById('lobby-room-code').style.display = 'block';
            statusEl.textContent = `🔍 Aguardando jogadores... (Sala: ${roomCode})`;
            updateLobbyDisplay();
        });
        
        peer.on('connection', (conn) => {
            // Player found!
            if (matchmakingTimer) { clearInterval(matchmakingTimer); matchmakingTimer = null; }
            matchmakingActive = false;
            if (findBtn) { findBtn.textContent = '🔍 ENCONTRAR PARTIDA'; findBtn.style.borderColor = '#4488aa'; }
            
            peerConnections.push(conn);
            let playerId = peerConnections.length;
            
            conn.on('open', () => {
                statusEl.textContent = `✅ Jogador encontrado! (${peerConnections.length + 1} jogadores)`;
                statusEl.style.color = '#44ff44';
                conn.send(JSON.stringify({ type: 'assignId', id: playerId, playerCount: peerConnections.length + 1 }));
                lobbyPlayers.push({ id: playerId, role: 'survivor', char: 'meg', skin: 'default', confirmed: false, name: `J${playerId + 1}` });
                updateLobbyDisplay();
                broadcastToPeers({ type: 'lobbyUpdate', players: lobbyPlayers });
            });
            
            conn.on('data', (data) => { try { handlePeerMessage(typeof data === 'string' ? JSON.parse(data) : data, conn); } catch(e){} });
            conn.on('close', () => {
                peerConnections = peerConnections.filter(c => c !== conn);
                lobbyPlayers = lobbyPlayers.filter(p => p.id <= peerConnections.length);
                updateLobbyDisplay();
                statusEl.textContent = `Sala: ${roomCode} — ${peerConnections.length + 1} jogadores`;
            });
        });
        
        peer.on('error', (err) => {
            // Slot taken, try another
            if (err.type === 'unavailable-id' && matchmakingActive) {
                slotId = (slotId + 1) % MATCHMAKING_POOL_SIZE;
                roomCode = 'MATCH-' + slotId;
                if (peer && !peer.destroyed) peer.destroy();
                peer = new Peer('dbp-match-' + slotId);
                // Re-attach handlers (simplified - just retry)
                setTimeout(becomeMatchmakingHost, 500);
            }
        });
    });
}

function joinRoom() {
    const statusEl = document.getElementById('online-status');
    roomCode = document.getElementById('room-code-input').value.toUpperCase().trim();
    if (!roomCode) { alert('Digite o código!'); return; }
    
    statusEl.textContent = 'Conectando...';
    statusEl.style.color = '#ffaa00';
    
    // Resolve the peer ID from the room code
    let peerId;
    if (roomCode.startsWith('MATCH-')) {
        // Matchmaking pool room
        peerId = 'dbp-match-' + roomCode.replace('MATCH-', '');
    } else {
        // Legacy random code
        peerId = 'dbp-' + roomCode.toLowerCase();
    }
    
    loadPeerJS(() => {
        peer = new Peer();
        peer.on('open', () => {
            const conn = peer.connect(peerId, { reliable: true });
            peerConnections = [conn];
            
            conn.on('open', () => {
                statusEl.textContent = `✅ Conectado à sala ${roomCode}!`;
                statusEl.style.color = '#44ff44';
                document.getElementById('lobby-room-code').textContent = roomCode;
                document.getElementById('lobby-room-code').style.display = 'block';
                document.getElementById('connection-status').textContent = '● Conectado';
                document.getElementById('connection-status').className = 'connected';
                isHost = false;
            });
            
            conn.on('data', (data) => {
                try { handlePeerMessage(typeof data === 'string' ? JSON.parse(data) : data, conn); } catch (e) { }
            });
            
            conn.on('close', () => {
                statusEl.textContent = 'Desconectado.';
                statusEl.style.color = '#ff4444';
            });
        });
        
        peer.on('error', (err) => {
            statusEl.textContent = `Erro: Sala não encontrada (${err.type})`;
            statusEl.style.color = '#ff4444';
        });
    });
}

function handlePeerMessage(data, fromConn) {
    switch (data.type) {
        case 'assignId':
            myPlayerId = data.id;
            document.getElementById('online-status').textContent = `✅ Você é J${data.id + 1}. Sala: ${roomCode}`;
            break;
        case 'lobbyUpdate':
            lobbyPlayers = data.players;
            updateLobbyDisplay();
            break;
        case 'roleSelect':
            let existing = lobbyPlayers.find(p => p.id === data.id);
            if (existing) { existing.role = data.role; existing.char = data.char; existing.skin = data.skin; existing.confirmed = data.confirmed; }
            updateLobbyDisplay();
            if (isHost) broadcastToPeers(data);
            break;
        case 'gameStart':
            startOnlineGame(data);
            break;
        case 'gameState':
            updateFromServer(data.state);
            break;
        case 's':
            // Compact state - data itself contains p, g, t
            updateFromServer(data);
            break;
        case 'input':
            applyRemoteInput(data);
            break;
        case 'playerInput':
            applyRemoteInput(data);
            break;
        case 'returnToLobby':
            gameState = GAME_STATES.ENDED;
            if (data.message) showGameMessage(data.message, 999);
            setTimeout(() => returnToLobby(), 4000);
            break;
        case 'msg':
            // Game message from host
            if (data.text) showGameMessage(data.text, data.dur || 90);
            break;
        case 'fx':
            // Particle/effect from host
            if (data.px !== undefined && typeof spawnParticle === 'function') {
                spawnParticle(data.px, data.py, data.c || '#fff', data.l || 15, data.dx || 0, data.dy || 0, data.s || 3);
            }
            if (data.blood && typeof spawnBlood === 'function') spawnBlood(data.bx, data.by, data.bn || 5);
            break;
    }
}

function broadcastToPeers(data) {
    const msg = JSON.stringify(data);
    for (let conn of peerConnections) { if (conn.open) conn.send(msg); }
}

// ============================================================
// MOBILE TOUCH CONTROLS
// ============================================================
let touchJoystick = { active: false, startX: 0, startY: 0, dx: 0, dy: 0 };
let touchAction = false;
let touchAbility = false;
let _prevTouchAction = false;
let _prevTouchAbility = false;

function initMobileControls() {
    if (!isMobile) return;
    
    // Don't show controls yet - they appear when game starts
    const joystick = document.getElementById('joystick');
    const thumb = document.getElementById('joystick-thumb');
    const actionBtn = document.getElementById('touch-action');
    const abilityBtn = document.getElementById('touch-ability');
    
    // Joystick touch
    joystick.addEventListener('touchstart', (e) => {
        e.preventDefault();
        const rect = joystick.getBoundingClientRect();
        touchJoystick.active = true;
        touchJoystick.startX = rect.left + rect.width / 2;
        touchJoystick.startY = rect.top + rect.height / 2;
    }, { passive: false });
    
    joystick.addEventListener('touchmove', (e) => {
        e.preventDefault();
        if (!touchJoystick.active) return;
        const touch = e.touches[0];
        let dx = touch.clientX - touchJoystick.startX;
        let dy = touch.clientY - touchJoystick.startY;
        let dist = Math.hypot(dx, dy);
        const maxDist = 45;
        if (dist > maxDist) { dx = dx / dist * maxDist; dy = dy / dist * maxDist; }
        touchJoystick.dx = dx / maxDist;
        touchJoystick.dy = dy / maxDist;
        thumb.style.transform = `translate(${dx - 20}px, ${dy - 20}px)`;
    }, { passive: false });
    
    joystick.addEventListener('touchend', (e) => {
        e.preventDefault();
        touchJoystick.active = false;
        touchJoystick.dx = 0;
        touchJoystick.dy = 0;
        thumb.style.transform = 'translate(-50%, -50%)';
    }, { passive: false });
    
    joystick.addEventListener('touchcancel', (e) => {
        touchJoystick.active = false;
        touchJoystick.dx = 0;
        touchJoystick.dy = 0;
        thumb.style.transform = 'translate(-50%, -50%)';
    }, { passive: false });
    
    // Action button
    actionBtn.addEventListener('touchstart', (e) => { e.preventDefault(); touchAction = true; }, { passive: false });
    actionBtn.addEventListener('touchend', (e) => { e.preventDefault(); touchAction = false; }, { passive: false });
    actionBtn.addEventListener('touchcancel', () => { touchAction = false; });
    
    // Ability button
    abilityBtn.addEventListener('touchstart', (e) => { e.preventDefault(); touchAbility = true; }, { passive: false });
    abilityBtn.addEventListener('touchend', (e) => { e.preventDefault(); touchAbility = false; }, { passive: false });
    abilityBtn.addEventListener('touchcancel', () => { touchAbility = false; });
}

// ============================================================
// INPUT SYSTEM
// ============================================================
const keys = {};
const keysJustPressed = {};

window.addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') return;
    if (!keys[e.code]) keysJustPressed[e.code] = true;
    keys[e.code] = true;
    e.preventDefault();
});
window.addEventListener('keyup', e => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') return;
    keys[e.code] = false;
});

// ============================================================
// PARTICLES
// ============================================================
function spawnParticle(x, y, color, life, vx, vy, size) {
    if (particles.length > 150) return;
    particles.push({ x, y, color, life, maxLife: life, vx: vx || 0, vy: vy || 0, size: size || 2 });
}
function spawnBlood(x, y, count) {
    for (let i = 0; i < count; i++) {
        let angle = Math.random() * Math.PI * 2;
        let speed = 0.5 + Math.random() * 2;
        spawnParticle(x, y, '#cc0000', 40 + Math.random() * 40, Math.cos(angle) * speed, Math.sin(angle) * speed, 1 + Math.random() * 2);
    }
    bloodPools.push({ x, y, size: 3 + Math.random() * 4, life: 600, maxLife: 600 });
}
function spawnScratchMark(x, y, player) {
    let fadeTime = (player && player.hasPerk && player.hasPerk('lightweight')) ? 60 : 180;
    scratchMarks.push({ x: x + (Math.random() - 0.5) * 8, y: y + (Math.random() - 0.5) * 8, life: fadeTime, maxLife: fadeTime });
}
function spawnDust(x, y) {
    for (let i = 0; i < 3; i++) {
        spawnParticle(x + (Math.random() - 0.5) * 10, y + (Math.random() - 0.5) * 10, '#88776644', 20 + Math.random() * 20, (Math.random() - 0.5) * 0.5, -0.3 - Math.random() * 0.5, 2 + Math.random() * 2);
    }
}
function updateParticles() {
    for (let i = particles.length - 1; i >= 0; i--) {
        let p = particles[i]; p.x += p.vx; p.y += p.vy; p.vy += 0.02; p.life--;
        if (p.life <= 0) particles.splice(i, 1);
    }
    for (let i = scratchMarks.length - 1; i >= 0; i--) { scratchMarks[i].life--; if (scratchMarks[i].life <= 0) scratchMarks.splice(i, 1); }
    for (let i = bloodPools.length - 1; i >= 0; i--) { bloodPools[i].life--; if (bloodPools[i].life <= 0) bloodPools.splice(i, 1); }
}

// ============================================================
// FOG
// ============================================================
function initFog() {
    fogParticles = [];
    for (let i = 0; i < 50; i++) {
        fogParticles.push({ x: Math.random() * currentMap.width * TILE, y: Math.random() * currentMap.height * TILE, size: 40 + Math.random() * 80, speed: 0.1 + Math.random() * 0.2, alpha: 0.05 + Math.random() * 0.1, offset: Math.random() * Math.PI * 2 });
    }
}
function updateFog() {
    for (let f of fogParticles) {
        f.x += Math.sin(gameTimer * 0.005 + f.offset) * f.speed;
        f.y += Math.cos(gameTimer * 0.003 + f.offset) * f.speed * 0.5;
        if (f.x > currentMap.width * TILE + 100) f.x = -100;
        if (f.x < -100) f.x = currentMap.width * TILE + 100;
    }
}

// ============================================================
// MAP GENERATION (same as before)
// ============================================================

function generateMap(mapKey) {
    const W = 36, H = 24;
    let grid = [];
    for (let y = 0; y < H; y++) { grid[y] = []; for (let x = 0; x < W; x++) grid[y][x] = 1; }
    switch (mapKey) {
        case 'asylum': generateAsylum(grid, W, H); break;
        case 'forest': generateForest(grid, W, H); break;
        case 'factory': generateFactory(grid, W, H); break;
        case 'catacombs': generateCatacombs(grid, W, H); break;
        case 'hospital': generateHospital(grid, W, H); break;
    }
    for (let y = 0; y < H; y++) { grid[y][0] = 1; grid[y][W - 1] = 1; }
    for (let x = 0; x < W; x++) { grid[0][x] = 1; grid[H - 1][x] = 1; }
    placeExitGates(grid, W, H);
    placePalletsLogical(grid, W, H, 10); // pallets in logical spots
    placeObjects(grid, W, H, 5, 8);  // lockers
    placeObjects(grid, W, H, 6, 8);  // hooks
    placeObjects(grid, W, H, 7, 4);  // chests
    placeDoors(grid, W, H);           // doors
    return { grid, width: W, height: H };
}

// Place doors at room entrances (where corridor meets room edge)
function placeDoors(grid, W, H) {
    let doorCount = 0;
    for (let y = 2; y < H - 2; y++) {
        for (let x = 2; x < W - 2; x++) {
            if (grid[y][x] !== 0) continue;
            if (doorCount >= 12) return; // max doors per map
            // A door spot: floor tile with walls on 2 opposite sides (doorway)
            let wallLeft = (x > 0 && grid[y][x-1] === 1);
            let wallRight = (x < W-1 && grid[y][x+1] === 1);
            let wallUp = (y > 0 && grid[y-1][x] === 1);
            let wallDown = (y < H-1 && grid[y+1][x] === 1);
            let floorLeft = (x > 0 && grid[y][x-1] === 0);
            let floorRight = (x < W-1 && grid[y][x+1] === 0);
            let floorUp = (y > 0 && grid[y-1][x] === 0);
            let floorDown = (y < H-1 && grid[y+1][x] === 0);
            
            let isDoorway = false;
            let orient = 'h'; // horizontal or vertical
            // Horizontal doorway: walls above and below, floor left and right
            if (wallUp && wallDown && floorLeft && floorRight) { isDoorway = true; orient = 'h'; }
            // Vertical doorway: walls left and right, floor above and below
            if (wallLeft && wallRight && floorUp && floorDown) { isDoorway = true; orient = 'v'; }
            
            if (isDoorway && Math.random() < 0.35) {
                grid[y][x] = 8; // door tile
                doorCount++;
            }
        }
    }
}

function carveRoom(grid, x, y, w, h) { for (let ry = y; ry < y + h; ry++) for (let rx = x; rx < x + w; rx++) if (ry >= 0 && ry < grid.length && rx >= 0 && rx < grid[0].length) grid[ry][rx] = 0; }
function carveCorridor(grid, x1, y1, x2, y2) { let x = x1, y = y1; while (x !== x2) { if (y >= 0 && y < grid.length && x >= 0 && x < grid[0].length) grid[y][x] = 0; x += x < x2 ? 1 : -1; } while (y !== y2) { if (y >= 0 && y < grid.length && x >= 0 && x < grid[0].length) grid[y][x] = 0; y += y < y2 ? 1 : -1; } }
function carveWideCorridor(grid, x1, y1, x2, y2) { carveCorridor(grid, x1, y1, x2, y2); carveCorridor(grid, x1, y1 + 1, x2, y2 + 1); carveCorridor(grid, x1 + 1, y1, x2 + 1, y2); }
function carveL(grid, x1, y1, x2, y2) { if (Math.random() > 0.5) { carveCorridor(grid, x1, y1, x2, y1); carveCorridor(grid, x2, y1, x2, y2); } else { carveCorridor(grid, x1, y1, x1, y2); carveCorridor(grid, x1, y2, x2, y2); } }
function addLoopHoles(grid, W, H) { for (let i = 0; i < 15; i++) { let x = 2 + Math.floor(Math.random() * (W - 4)); let y = 2 + Math.floor(Math.random() * (H - 4)); if (grid[y][x] === 1) { let n = 0; if (y > 0 && grid[y - 1][x] === 0) n++; if (y < H - 1 && grid[y + 1][x] === 0) n++; if (x > 0 && grid[y][x - 1] === 0) n++; if (x < W - 1 && grid[y][x + 1] === 0) n++; if (n >= 2) grid[y][x] = 0; } } }

// Create sealed rooms with only 1 door entrance + decorations inside
function addSpecialRooms(grid, W, H, count) {
    let roomTypes = ['storage', 'office', 'bathroom', 'generator', 'basement'];
    let placed = 0;
    let attempts = 0;
    
    while (placed < count && attempts < 100) {
        attempts++;
        // Random room size 4x3 to 5x4
        let rw = 4 + Math.floor(Math.random() * 2);
        let rh = 3 + Math.floor(Math.random() * 2);
        let rx = 3 + Math.floor(Math.random() * (W - rw - 6));
        let ry = 3 + Math.floor(Math.random() * (H - rh - 6));
        
        // Check if area is all walls (we're carving into solid)
        let allWall = true;
        for (let dy = -1; dy <= rh; dy++) for (let dx = -1; dx <= rw; dx++) {
            let cy = ry + dy, cx = rx + dx;
            if (cy < 0 || cy >= H || cx < 0 || cx >= W) { allWall = false; break; }
            if (grid[cy][cx] !== 1) { allWall = false; break; }
        }
        if (!allWall) continue;
        
        // Check that at least one side is adjacent to an existing corridor/open area
        let doorOptions = [];
        // Check top wall
        for (let dx = 0; dx < rw; dx++) { if (ry - 2 >= 0 && grid[ry - 2][rx + dx] === 0) doorOptions.push({ x: rx + dx, y: ry - 1, side: 'top' }); }
        // Check bottom wall
        for (let dx = 0; dx < rw; dx++) { if (ry + rh + 1 < H && grid[ry + rh + 1][rx + dx] === 0) doorOptions.push({ x: rx + dx, y: ry + rh, side: 'bottom' }); }
        // Check left wall
        for (let dy = 0; dy < rh; dy++) { if (rx - 2 >= 0 && grid[ry + dy][rx - 2] === 0) doorOptions.push({ x: rx - 1, y: ry + dy, side: 'left' }); }
        // Check right wall
        for (let dy = 0; dy < rh; dy++) { if (rx + rw + 1 < W && grid[ry + dy][rx + rw + 1] === 0) doorOptions.push({ x: rx + rw, y: ry + dy, side: 'right' }); }
        
        if (doorOptions.length === 0) continue;
        
        // Carve the room interior
        for (let dy = 0; dy < rh; dy++) for (let dx = 0; dx < rw; dx++) {
            grid[ry + dy][rx + dx] = 0;
        }
        
        // Place exactly 1 door (connecting to existing corridor)
        let door = doorOptions[Math.floor(Math.random() * doorOptions.length)];
        grid[door.y][door.x] = 0; // carve doorway tile
        // Also carve connection to corridor
        if (door.side === 'top' && door.y - 1 >= 0) grid[door.y - 1][door.x] = 0;
        if (door.side === 'bottom' && door.y + 1 < H) grid[door.y + 1][door.x] = 0;
        if (door.side === 'left' && door.x - 1 >= 0) grid[door.y][door.x - 1] = 0;
        if (door.side === 'right' && door.x + 1 < W) grid[door.y][door.x + 1] = 0;
        
        // Decorate the room interior based on type
        let type = roomTypes[placed % roomTypes.length];
        decorateRoom(grid, rx, ry, rw, rh, type);
        
        placed++;
    }
}

function decorateRoom(grid, rx, ry, rw, rh, type) {
    // Place objects inside the room
    let cx = rx + Math.floor(rw / 2);
    let cy = ry + Math.floor(rh / 2);
    
    if (type === 'storage') {
        // Chest inside + locker
        grid[ry + 1][rx + 1] = 7; // chest
        if (rw > 3) grid[ry + 1][rx + rw - 2] = 5; // locker
    } else if (type === 'office') {
        // Locker + pallet near the door for mind games
        grid[cy][cx] = 5; // locker in center
    } else if (type === 'bathroom') {
        // Just a chest (hidden item)
        grid[ry + rh - 2][rx + rw - 2] = 7; // chest in corner
    } else if (type === 'generator') {
        // Generator in center of room
        grid[cy][cx] = 9; // generator
    } else if (type === 'basement') {
        // Hook + chest (high risk high reward)
        grid[ry + 1][rx + 1] = 6; // hook
        if (rw > 3 && rh > 3) grid[ry + rh - 2][rx + rw - 2] = 7; // chest far from hook
    }
}

function generateAsylum(grid, W, H) {
    for (let x = 2; x < W - 2; x++) { grid[4][x] = 0; grid[5][x] = 0; grid[11][x] = 0; grid[12][x] = 0; grid[18][x] = 0; grid[19][x] = 0; }
    for (let y = 2; y < H - 2; y++) { grid[y][5] = 0; grid[y][6] = 0; grid[y][12] = 0; grid[y][13] = 0; grid[y][20] = 0; grid[y][21] = 0; grid[y][28] = 0; grid[y][29] = 0; }
    carveRoom(grid, 2, 2, 3, 2); carveRoom(grid, 8, 2, 3, 2); carveRoom(grid, 15, 2, 4, 2); carveRoom(grid, 23, 2, 4, 2); carveRoom(grid, 30, 2, 4, 2);
    carveRoom(grid, 2, 6, 3, 4); carveRoom(grid, 8, 7, 4, 3); carveRoom(grid, 15, 6, 3, 4); carveRoom(grid, 23, 7, 5, 3); carveRoom(grid, 30, 6, 4, 4);
    carveRoom(grid, 2, 13, 4, 4); carveRoom(grid, 8, 13, 3, 3); carveRoom(grid, 15, 13, 4, 4); carveRoom(grid, 23, 13, 3, 3); carveRoom(grid, 30, 13, 4, 3);
    carveRoom(grid, 2, 20, 3, 2); carveRoom(grid, 8, 20, 4, 2); carveRoom(grid, 15, 20, 3, 2); carveRoom(grid, 23, 20, 5, 2); carveRoom(grid, 30, 20, 4, 2);
    carveRoom(grid, 14, 8, 6, 5); grid[10][16] = 1; grid[10][18] = 1; grid[11][17] = 1;
    addLoopHoles(grid, W, H);
    addSpecialRooms(grid, W, H, 3);
}

function generateForest(grid, W, H) {
    let paths = [[[2, 3], [5, 5], [9, 3], [13, 6], [17, 4], [21, 7], [25, 4], [29, 3], [33, 5]], [[2, 11], [4, 9], [8, 12], [12, 10], [16, 13], [20, 11], [24, 13], [28, 10], [33, 12]], [[3, 19], [7, 17], [11, 20], [15, 18], [19, 21], [23, 18], [27, 20], [31, 18], [34, 20]], [[5, 3], [5, 7], [5, 12], [5, 17], [5, 21]], [[12, 2], [12, 6], [12, 11], [12, 16], [12, 21]], [[20, 3], [20, 8], [20, 13], [20, 18], [20, 22]], [[28, 2], [28, 7], [28, 12], [28, 17], [28, 21]]];
    for (let path of paths) for (let i = 0; i < path.length - 1; i++) carveCorridor(grid, path[i][0], path[i][1], path[i + 1][0], path[i + 1][1]);
    carveRoom(grid, 4, 4, 3, 3); carveRoom(grid, 14, 8, 3, 3); carveRoom(grid, 24, 5, 3, 3);
    carveRoom(grid, 8, 15, 3, 2); carveRoom(grid, 19, 16, 4, 3); carveRoom(grid, 30, 14, 3, 3);
    for (let i = 0; i < 20; i++) { let tx = 3 + Math.floor(Math.random() * (W - 6)), ty = 3 + Math.floor(Math.random() * (H - 6)); if (grid[ty][tx] === 0 && Math.random() < 0.4) grid[ty][tx] = 1; }
    addLoopHoles(grid, W, H);
    addSpecialRooms(grid, W, H, 3);
}

function generateFactory(grid, W, H) {
    for (let y = 2; y < H - 2; y += 5) for (let x = 2; x < W - 2; x++) { grid[y][x] = 0; grid[y + 1][x] = 0; }
    for (let x = 2; x < W - 2; x += 6) for (let y = 2; y < H - 2; y++) { grid[y][x] = 0; grid[y][x + 1] = 0; }
    for (let ry = 4; ry < H - 4; ry += 5) for (let rx = 4; rx < W - 4; rx += 6) { if (Math.random() > 0.3) { let bw = 2 + Math.floor(Math.random() * 2), bh = 1 + Math.floor(Math.random() * 2); for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) { if (ry + by < H && rx + bx < W) grid[ry + by][rx + bx] = 1; } } }
    carveWideCorridor(grid, 2, H - 4, W - 3, H - 4); carveWideCorridor(grid, 2, 3, W - 3, 3);
    carveRoom(grid, 2, 5, 3, 3); carveRoom(grid, W - 6, 5, 4, 3); carveRoom(grid, 15, 9, 4, 3);
    addLoopHoles(grid, W, H);
    addSpecialRooms(grid, W, H, 3);
}

function generateCatacombs(grid, W, H) {
    let visited = []; for (let y = 0; y < H; y++) { visited[y] = []; for (let x = 0; x < W; x++) visited[y][x] = false; }
    function carve(cx, cy) { visited[cy][cx] = true; grid[cy][cx] = 0; let dirs = [[0, -2], [0, 2], [-2, 0], [2, 0]].sort(() => Math.random() - 0.5); for (let [dx, dy] of dirs) { let nx = cx + dx, ny = cy + dy; if (nx > 0 && nx < W - 1 && ny > 0 && ny < H - 1 && !visited[ny][nx]) { grid[cy + dy / 2][cx + dx / 2] = 0; carve(nx, ny); } } }
    carve(2, 2);
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { if (grid[y][x] === 0 && Math.random() < 0.4) { let d = [[0, 1], [1, 0], [0, -1], [-1, 0]][Math.floor(Math.random() * 4)]; let ny = y + d[1], nx = x + d[0]; if (ny > 0 && ny < H - 1 && nx > 0 && nx < W - 1) grid[ny][nx] = 0; } }
    carveRoom(grid, 4, 4, 4, 3); carveRoom(grid, W - 8, 4, 4, 3); carveRoom(grid, W / 2 - 2 | 0, H / 2 - 2 | 0, 5, 4);
    carveL(grid, 6, 6, W / 2 | 0, H / 2 | 0); carveL(grid, W - 6, 6, W / 2 | 0, H / 2 | 0);
    addLoopHoles(grid, W, H);
    addSpecialRooms(grid, W, H, 3);
}

function generateHospital(grid, W, H) {
    for (let x = 2; x < W - 2; x++) { grid[4][x] = 0; grid[10][x] = 0; grid[16][x] = 0; }
    for (let y = 2; y < H - 2; y++) { grid[y][8] = 0; grid[y][15] = 0; grid[y][22] = 0; }
    let rooms = [[2, 2, 3, 2], [2, 6, 3, 2], [2, 12, 3, 2], [10, 2, 3, 2], [10, 6, 3, 2], [10, 12, 3, 2], [17, 2, 4, 2], [17, 6, 3, 2], [17, 12, 3, 2], [24, 2, 3, 2], [24, 6, 3, 2], [24, 12, 3, 2]];
    for (let [rx, ry, rw, rh] of rooms) carveRoom(grid, rx, ry, rw, rh);
    for (let y = 5; y < 10; y++) { grid[y][4] = 0; grid[y][20] = 0; }
    for (let y = 11; y < 16; y++) { grid[y][4] = 0; grid[y][20] = 0; }
    addLoopHoles(grid, W, H);
    addSpecialRooms(grid, W, H, 3);
}

function placeObjects(grid, W, H, type, count) {
    let placed = 0, attempts = 0;
    while (placed < count && attempts < 500) {
        let x = 2 + Math.floor(Math.random() * (W - 4)), y = 2 + Math.floor(Math.random() * (H - 4));
        if (grid[y][x] === 0) { let tooClose = false; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) { let ny = y + dy, nx = x + dx; if (ny >= 0 && ny < H && nx >= 0 && nx < W && grid[ny][nx] >= 2) tooClose = true; } if (!tooClose) { grid[y][x] = type; placed++; } }
        attempts++;
    }
}

// Place pallets in logical positions: narrow corridors, doorways, between walls (loop spots)
function placePalletsLogical(grid, W, H, count) {
    let candidates = [];
    
    for (let y = 2; y < H - 2; y++) {
        for (let x = 2; x < W - 2; x++) {
            if (grid[y][x] !== 0) continue;
            
            // Check if this is a good pallet spot:
            // A) Narrow corridor: walls on 2 opposite sides, open on other 2
            let wallUp = (y > 0 && grid[y-1][x] === 1);
            let wallDown = (y < H-1 && grid[y+1][x] === 1);
            let wallLeft = (x > 0 && grid[y][x-1] === 1);
            let wallRight = (x < W-1 && grid[y][x+1] === 1);
            let openUp = (y > 0 && grid[y-1][x] === 0);
            let openDown = (y < H-1 && grid[y+1][x] === 0);
            let openLeft = (x > 0 && grid[y][x-1] === 0);
            let openRight = (x < W-1 && grid[y][x+1] === 0);
            
            let score = 0;
            
            // Horizontal corridor (walls above & below, open left & right) - great pallet spot
            if (wallUp && wallDown && openLeft && openRight) score += 10;
            // Vertical corridor (walls left & right, open up & down)
            if (wallLeft && wallRight && openUp && openDown) score += 10;
            
            // Near a corner/L-shape (wall on one side + wall on adjacent side)
            if ((wallUp && wallLeft && openDown && openRight) || (wallUp && wallRight && openDown && openLeft) ||
                (wallDown && wallLeft && openUp && openRight) || (wallDown && wallRight && openUp && openLeft)) score += 6;
            
            // Between two open areas with a wall nearby (loop pallet)
            let nearbyWalls = (wallUp?1:0) + (wallDown?1:0) + (wallLeft?1:0) + (wallRight?1:0);
            let nearbyOpen = (openUp?1:0) + (openDown?1:0) + (openLeft?1:0) + (openRight?1:0);
            if (nearbyWalls === 1 && nearbyOpen === 3) score += 4;
            
            // Wider junction (3+ open sides with at least 1 wall nearby diagonally)
            if (nearbyOpen >= 3) {
                let diagWalls = 0;
                if (y>0&&x>0&&grid[y-1][x-1]===1) diagWalls++;
                if (y>0&&x<W-1&&grid[y-1][x+1]===1) diagWalls++;
                if (y<H-1&&x>0&&grid[y+1][x-1]===1) diagWalls++;
                if (y<H-1&&x<W-1&&grid[y+1][x+1]===1) diagWalls++;
                if (diagWalls >= 1) score += 3;
            }
            
            if (score > 0) candidates.push({ x, y, score });
        }
    }
    
    // Sort by score (best spots first) and add randomness
    candidates.sort((a, b) => (b.score + Math.random() * 4) - (a.score + Math.random() * 4));
    
    let placed = 0;
    for (let c of candidates) {
        if (placed >= count) break;
        // Check not too close to other pallets
        let tooClose = false;
        for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
            let ny = c.y + dy, nx = c.x + dx;
            if (ny >= 0 && ny < H && nx >= 0 && nx < W && grid[ny][nx] === 4) tooClose = true;
        }
        if (!tooClose) { grid[c.y][c.x] = 4; placed++; }
    }
    
    // If we couldn't find enough logical spots, fill remaining randomly
    if (placed < count) placeObjects(grid, W, H, 4, count - placed);
}

function placeExitGates(grid, W, H) {
    let positions = [];
    for (let x = 3; x < W - 3; x++) { if (grid[1][x] === 0) positions.push([x, 1]); if (grid[H - 2][x] === 0) positions.push([x, H - 2]); }
    for (let y = 3; y < H - 3; y++) { if (grid[y][1] === 0) positions.push([1, y]); if (grid[y][W - 2] === 0) positions.push([W - 2, y]); }
    if (positions.length < 2) { grid[1][2] = 3; grid[H - 2][W - 3] = 3; }
    else {
        let p1 = positions[Math.floor(Math.random() * positions.length)]; grid[p1[1]][p1[0]] = 3;
        let best = null, bestDist = 0;
        for (let p of positions) { let d = Math.abs(p[0] - p1[0]) + Math.abs(p[1] - p1[1]); if (d > bestDist) { bestDist = d; best = p; } }
        if (best) grid[best[1]][best[0]] = 3; else grid[H - 2][W - 3] = 3;
    }
}


// ============================================================
// PLAYER CLASS
// ============================================================
let players = [];
let currentMap = null;
let currentMapKey = '';
let traps = [];
let chests = [];
let doors = [];

class Player {
    constructor(id, role, charKey, controls, perks = [], skin = 'default') {
        this.id = id; this.role = role; this.charKey = charKey; this.controls = controls; this.perks = perks;
        this.x = 0; this.y = 0; this.vx = 0; this.vy = 0;
        this.health = role === 'killer' ? 999 : 2; this.maxHealth = role === 'killer' ? 999 : 2;
        this.alive = true; this.escaped = false; this.stunned = 0;
        this.attackCooldown = 0; this.attacking = false; this.attackTimer = 0;
        this.abilityCooldown = 0; this.abilityActive = 0;
        this.inLocker = false; this.injured = false; this.dying = false; this.dyingTimer = 0;
        this.carried = false; this.carrying = null; this.facing = 0;
        this.animFrame = 0; this.animTimer = 0;
        this.stealthActive = false; this.speedBoost = 0; this.trapCount = 3;
        this.revealKiller = false; this.hookState = 0; this.hookTimer = 0;
        this.hookedOn = null; this.hookCount = 0; this.unhookCooldown = 0;
        this.wiggleProgress = 0; this._wiggleKeyHeld = false; this._unhookProgress = 0;
        this.borrowedTimeActive = 0; this.passiveHealTimer = 0;
        this.lastRunning = false; this.sprintBurstUsed = false;
        this.deadHardCooldown = 0; this.deadHardActive = 0; this.isRunning = false;
        this.heldItem = null; this.itemUses = 0; this._bloodhoundSlow = 0;
        this._sprintResetTimer = 0; this._searchProgress = 0; this._interactAnim = 0;
        this._vaulting = 0; this._vaultCooldown = 0; this._reviveProgress = 0;
        
        const charData = role === 'killer' ? KILLERS[charKey] : SURVIVORS[charKey];
        this.baseSpeed = charData.speed;
        this.charData = { ...charData }; // copy so we can override colors
        this.skin = skin;
        this.skinData = SKINS[role]?.[skin] || null;
        
        // Apply skin overrides
        if (this.skinData) {
            if (this.skinData.color) this.charData.color = this.skinData.color;
            if (this.skinData.secondaryColor) this.charData.secondaryColor = this.skinData.secondaryColor;
            if (this.skinData.weaponColor) this.charData.weaponColor = this.skinData.weaponColor;
            if (this.skinData.glowColor) this.charData.glowColor = this.skinData.glowColor;
            if (this.skinData.shirtColor) this.charData.shirtColor = this.skinData.shirtColor;
        }
        
        // Apply cosmetic overrides (from progression system)
        if (typeof getEquippedCosmetics === 'function' && typeof CHAR_COSMETICS !== 'undefined' && CHAR_COSMETICS[charKey]) {
            let eq = getEquippedCosmetics(charKey);
            let cosmData = CHAR_COSMETICS[charKey];
            if (cosmData.body) {
                let b = cosmData.body.find(c => c.key === eq.body);
                if (b && b.key !== 'default') {
                    if (role === 'killer') {
                        this.charData.secondaryColor = b.color;
                    } else {
                        this.charData.shirtColor = b.color;
                    }
                }
            }
            if (cosmData.head) {
                let h = cosmData.head.find(c => c.key === eq.head);
                if (h && h.key !== 'default') {
                    this.charData.color = h.color; // mask color (killer) or hair color (survivor)
                }
            }
            if (cosmData.weapon && role === 'killer') {
                let w = cosmData.weapon.find(c => c.key === eq.weapon);
                if (w && w.key !== 'default') {
                    this.charData.weaponColor = w.color;
                }
            }
        }
    }
    hasPerk(perkKey) { return this.perks.includes(perkKey); }
    get speed() {
        let s = this.baseSpeed;
        if (this.role === 'survivor' && this.injured) { s *= 0.9; if (this.hasPerk('resilience')) s *= 1.22; if (this._bloodhoundSlow > 0) s *= 0.8; }
        if (this.role === 'survivor' && this.dying) s = 0;
        if (this.speedBoost > 0) s *= 1.5;
        if (this.carrying) { s *= 0.85; if (this.hasPerk('agitation')) s *= 1.2; }
        if (this.stunned > 0) s = 0;
        if (this.attacking) s *= 0.3;
        if (this.abilityActive > 0 && this.role === 'killer' && this.charData.ability === 'charge') s *= 1.8;
        if (this.abilityActive > 0 && this.role === 'killer' && this.charData.ability === 'chainsaw') s *= 2.0;
        if (this.abilityActive > 0 && this.role === 'killer' && this.charData.ability === 'shred') s *= 1.8;
        if (this.abilityActive > 0 && this.role === 'killer' && this.charData.ability === 'tailstrike') s *= 1.6;
        if (this.abilityActive > 0 && this.role === 'killer' && this.charData.ability === 'frenzy') s *= 1.3;
        if (this._chuckyHiding) s *= 1.2;
        if (this._frenzyMode) s *= 1.5; // Legion frenzy = fast sprint
        if (this.abilityActive > 0 && this.role === 'survivor' && this.charData.ability === 'sprint') s *= 1.5;
        if (this.abilityActive > 0 && this.role === 'killer' && (this.charData.ability === 'stealth' || this.charData.ability === 'uncloak')) s *= 1.1;
        if (this.role === 'killer' && this.hasPerk('noed') && gatesOpen) s *= 1.15;
        if (this.deadHardActive > 0) s *= 2.5;
        return s;
    }
}

// ============================================================
// GAME START
// ============================================================
function startGame(fromOnline = false) {
    // If coming from online, use the host's map and seed first
    if (fromOnline && window._onlineSeed) {
        selectedMap = window._onlineMapKey || 'asylum';
        currentMapKey = selectedMap;
    } else {
        selectedMap = document.getElementById('map-select')?.value || 'random';
        if (selectedMap === 'random') {
            const mapKeys = Object.keys(MAPS);
            selectedMap = mapKeys[Math.floor(Math.random() * mapKeys.length)];
        }
        currentMapKey = selectedMap;
    }
    
    players = []; traps = []; exitGates = []; pallets = []; lockers = []; hooks = []; chests = []; doors = []; generators = [];
    particles = []; scratchMarks = []; bloodPools = []; gatesOpen = false; gameTimer = 0; gensCompleted = 0;
    matchTimeRemaining = MATCH_TIME;
    
    let mapSeed;
    if (fromOnline && window._onlineSeed) {
        mapSeed = window._onlineSeed;
    } else {
        mapSeed = Math.floor(Math.random() * 999999);
    }
    
    if (onlineMode && isHost && !fromOnline) {
        let lobbyInfo = lobbyPlayers.filter(p => p.confirmed);
        if (lobbyInfo.length < 2) { alert('Precisa de pelo menos 2 jogadores prontos!'); return; }
        // Map will be sent after generation (below)
    }
    
    let savedRandom = Math.random;
    let seedVal = mapSeed;
    Math.random = function () { seedVal = (seedVal * 16807 + 0) % 2147483647; return (seedVal - 1) / 2147483646; };
    
    let mapData;
    if (fromOnline && window._onlineMapGrid) {
        // Client: use the map grid received from host (exact copy)
        mapData = { width: 36, height: 24, grid: window._onlineMapGrid };
        window._onlineMapGrid = null;
    } else {
        // Host/Local: generate map normally
        mapData = generateMap(selectedMap);
        // Place extra generators to guarantee 5
        let genCount = 0;
        for (let y2 = 0; y2 < mapData.height; y2++) for (let x2 = 0; x2 < mapData.width; x2++) { if (mapData.grid[y2][x2] === 9) genCount++; }
        while (genCount < 5) {
            let gx = 3 + Math.floor(Math.random() * (mapData.width - 6));
            let gy = 3 + Math.floor(Math.random() * (mapData.height - 6));
            if (mapData.grid[gy][gx] === 0) {
                mapData.grid[gy][gx] = 9;
                genCount++;
            }
        }
    }
    currentMap = mapData;
    
    Math.random = savedRandom;
    
    // Send map grid to peers AFTER generation (so they get the exact same map)
    if (onlineMode && isHost && !fromOnline) {
        let lobbyInfo = lobbyPlayers.filter(p => p.confirmed);
        // Flatten grid to a compact string for transfer
        let flatGrid = [];
        for (let y2 = 0; y2 < mapData.height; y2++) flatGrid.push(mapData.grid[y2].join(','));
        broadcastToPeers({ type: 'gameStart', mapKey: selectedMap, seed: mapSeed, mapGrid: flatGrid, playerCount: lobbyInfo.length, lobby: lobbyInfo, killerPerks: selectedPerks.killer, survivorPerks: selectedPerks.survivor });
    }
    
    Math.random = savedRandom;
    
    for (let y = 0; y < mapData.height; y++) for (let x = 0; x < mapData.width; x++) {
        switch (mapData.grid[y][x]) {
            case 3: exitGates.push({ x: x * TILE, y: y * TILE, open: false }); break;
            case 4: pallets.push({ x: x * TILE, y: y * TILE, dropped: false, broken: false }); break;
            case 5: lockers.push({ x: x * TILE, y: y * TILE, occupied: null }); break;
            case 6: hooks.push({ x: x * TILE, y: y * TILE, occupied: null, broken: false }); break;
            case 7: chests.push({ x: x * TILE, y: y * TILE, opened: false, item: null }); break;
            case 8: doors.push({ x: x * TILE, y: y * TILE, closed: true, broken: false, closeAnim: 0, breakAnim: 0 }); break;
            case 9: generators.push({ x: x * TILE, y: y * TILE, progress: 0, completed: false, sparking: false }); break;
        }
    }
    
    // Create players
    if (onlineMode) {
        let lobby = window._onlineLobby || lobbyPlayers.filter(p => p.confirmed);
        let kPerks = window._onlineKillerPerks || selectedPerks.killer;
        let sPerks = window._onlineSurvivorPerks || selectedPerks.survivor;
        let pCount = window._onlinePlayerCount || lobby.length;
        if (pCount < 2) pCount = 2; if (pCount > 5) pCount = 5;
        let defaultSurvivors = ['meg', 'claudette', 'dwight'];
        for (let i = 0; i < pCount; i++) {
            let lobbyEntry = lobby.find(p => p.id === i);
            let role = 'survivor', charKey, perks, controls = CONTROL_SCHEMES[i] || CONTROL_SCHEMES[0];
            if (lobbyEntry) { role = lobbyEntry.role; charKey = lobbyEntry.char; }
            else { if (i === 0) { role = 'killer'; charKey = 'trapper'; } else charKey = defaultSurvivors[(i - 1) % 4]; }
            perks = role === 'killer' ? kPerks : sPerks;
            players.push(new Player(i, role, charKey, controls, perks, lobbyEntry?.skin || 'default'));
        }
    } else {
        // Local mode: use lobby config
        for (let i = 0; i < lobbyPlayers.length; i++) {
            let lp = lobbyPlayers[i];
            let perks = lp.role === 'killer' ? selectedPerks.killer : selectedPerks.survivor;
            players.push(new Player(i, lp.role, lp.char, CONTROL_SCHEMES[i], perks, lp.skin));
        }
    }
    
    // Mobile: show touch controls during game (sendInput reads touch keys directly)
    if (isMobile && players.length > 0 && !onlineMode) {
        // Local mode: player 0 uses touch controls
        players[0].controls = { name: 'Touch', up: '_touchUp', down: '_touchDown', left: '_touchLeft', right: '_touchRight', action: '_touchAction', ability: '_touchAbility' };
    }
    
    let extraPlayers = players.length - 2;
    if (extraPlayers > 0) matchTimeRemaining = MATCH_TIME + (extraPlayers * 3000);
    
    seedVal = mapSeed + 1;
    Math.random = function () { seedVal = (seedVal * 16807 + 0) % 2147483647; return (seedVal - 1) / 2147483646; };
    spawnPlayers();
    Math.random = savedRandom;
    
    initFog();
    
    // Switch to game view - show loading screen first
    document.getElementById('lobby-screen').style.display = 'none';
    document.getElementById('main-menu').style.display = 'none';
    document.getElementById('settings-panel').style.display = 'none';
    let csScreen = document.getElementById('char-select-screen'); if (csScreen) csScreen.style.display = 'none';
    
    // Show loading screen with killer info and tips
    showLoadingScreen(function() {
        canvas.style.display = 'block';
        document.getElementById('hud').style.display = 'flex';
        document.getElementById('timer-display').style.display = 'block';
        if (isMobile) document.getElementById('mobile-controls').style.display = 'block';
        gameState = GAME_STATES.PLAYING;
        showGameMessage('A caçada começa!', 120);
    });
}

function startOnlineGame(data) {
    window._onlineSeed = data.seed;
    window._onlineMapKey = data.mapKey || 'asylum';
    window._onlinePlayerCount = data.playerCount || 2;
    window._onlineKillerPerks = data.killerPerks || [];
    window._onlineSurvivorPerks = data.survivorPerks || [];
    window._onlineLobby = data.lobby || [];
    // Receive the exact map grid from host
    if (data.mapGrid) {
        window._onlineMapGrid = data.mapGrid.map(row => row.split(',').map(Number));
    } else {
        window._onlineMapGrid = null;
    }
    if (data.mapKey) { selectedMap = data.mapKey; const ms = document.getElementById('map-select'); if (ms) ms.value = data.mapKey; }
    startGame(true);
}

function spawnPlayers() {
    let openTiles = [];
    for (let y = 0; y < currentMap.height; y++) for (let x = 0; x < currentMap.width; x++) if (currentMap.grid[y][x] === 0) openTiles.push({ x: x * TILE + TILE / 2, y: y * TILE + TILE / 2 });
    let centerTiles = openTiles.filter(t => Math.abs(t.x - (currentMap.width * TILE / 2)) < 5 * TILE && Math.abs(t.y - (currentMap.height * TILE / 2)) < 5 * TILE);
    if (centerTiles.length === 0) centerTiles = openTiles;
    let killerSpawn = centerTiles[Math.floor(Math.random() * centerTiles.length)];
    let killerIdx = players.findIndex(p => p.role === 'killer');
    if (killerIdx >= 0) { players[killerIdx].x = killerSpawn.x; players[killerIdx].y = killerSpawn.y; }
    let farTiles = openTiles.filter(t => Math.hypot(t.x - killerSpawn.x, t.y - killerSpawn.y) > 8 * TILE);
    if (farTiles.length < 3) farTiles = openTiles;
    for (let i = 0; i < players.length; i++) {
        if (players[i].role === 'killer') continue;
        let idx = Math.floor(Math.random() * farTiles.length);
        players[i].x = farTiles[idx].x; players[i].y = farTiles[idx].y;
        farTiles.splice(idx, 1);
        if (farTiles.length === 0) farTiles = openTiles;
    }
}

// ============================================================
// GAME UPDATE
// ============================================================
function update() {
    if (gameState !== GAME_STATES.PLAYING) return;
    gameTimer++;
    
    // Mobile input mapping
    if (isMobile) {
        keys['_touchUp'] = touchJoystick.dy < -0.3;
        keys['_touchDown'] = touchJoystick.dy > 0.3;
        keys['_touchLeft'] = touchJoystick.dx < -0.3;
        keys['_touchRight'] = touchJoystick.dx > 0.3;
        keys['_touchAction'] = touchAction;
        keys['_touchAbility'] = touchAbility;
        // Detect just-pressed for action/ability
        if (touchAction && !_prevTouchAction) keysJustPressed['_touchAction'] = true;
        if (touchAbility && !_prevTouchAbility) keysJustPressed['_touchAbility'] = true;
        _prevTouchAction = touchAction;
        _prevTouchAbility = touchAbility;
    }
    
    // Online peer: send input and interpolate
    if (onlineMode && !isHost) {
        sendInput(); matchTimeRemaining--;
        // Smooth interpolation for remote players
        for (let p of players) {
            if (p._targetX !== undefined && p._targetY !== undefined) {
                let dx = p._targetX - p.x;
                let dy = p._targetY - p.y;
                if (Math.abs(dx) > TILE * 4 || Math.abs(dy) > TILE * 4) {
                    p.x = p._targetX; p.y = p._targetY;
                } else {
                    let nx = p.x + dx * 0.3;
                    let ny = p.y + dy * 0.3;
                    // Don't interpolate into walls
                    if (currentMap && isWalkable(nx, ny)) { p.x = nx; p.y = ny; }
                    else { p.x = p._targetX; p.y = p._targetY; } // snap if path is blocked
                }
            }
            // Animation is driven by isRunning flag from host - animFrame comes from host too
            // But we keep animTimer locally for smoother visual
            if (p.isRunning) {
                p.animTimer++;
                if (p.animTimer > 8) { p.animTimer = 0; p.animFrame = (p.animFrame + 1) % 4; }
            }
        }
        updateTimerDisplay(); updateTerrorRadius();
        if (gameMsgTimer > 0) { gameMsgTimer--; if (gameMsgTimer === 0) document.getElementById('game-msg').style.opacity = '0'; }
        updateParticles(); updateFog(); updateHUD();
        for (let k in keysJustPressed) if (!k.includes('_prev')) delete keysJustPressed[k];
        return;
    }
    
    matchTimeRemaining--;
    if (matchTimeRemaining <= 0 && !gatesOpen) {
        // Timer backup: if generators not done in time, gates open anyway
        gatesOpen = true; for (let g of exitGates) g.open = true;
        showGameMessage('⏰ TEMPO ESGOTADO — PORTÕES ABERTOS!', 150);
        for (let p of players) { if (p.role === 'survivor' && p.alive && p.hasPerk('adrenaline') && p.injured) { p.health = Math.min(p.health + 1, p.maxHealth); if (p.health >= p.maxHealth) p.injured = false; } }
    }
    
    updateTimerDisplay(); updateTerrorRadius();
    if (gameMsgTimer > 0) { gameMsgTimer--; if (gameMsgTimer === 0) document.getElementById('game-msg').style.opacity = '0'; }
    
    for (let p of players) {
        if (!p.alive && !p.dying) continue;
        if (p.escaped) continue;
        if (p.inLocker) { handleLockerExit(p); continue; }
        if (p.carried) { handleWiggle(p); continue; }
        if (p.hookState > 0 && p.role === 'survivor') { continue; }
        updatePlayerInput(p); updatePlayerPhysics(p); updatePlayerTimers(p); updatePerks(p);
        if (p.role === 'killer') updateKiller(p); else updateSurvivor(p);
        if (p.role === 'survivor' && p.isRunning && !p.inLocker && !p.dying && p.alive) { if (!(p.hasPerk('ironwill') && p.injured)) { if (gameTimer % 4 === 0) spawnScratchMark(p.x, p.y, p); } }
    }
    
    updateTraps(); updateHooks(); updateParticles(); updateFog(); checkWinCondition(); updateHUD();
    if (onlineMode && isHost && gameTimer % 3 === 0) broadcastGameState();
    for (let k in keysJustPressed) if (!k.includes('_prev')) delete keysJustPressed[k];
}

function updateTimerDisplay() {
    const timerEl = document.getElementById('timer-bar-fill');
    const timerText = document.getElementById('timer-bar-text');
    let max = MATCH_TIME + Math.max(0, (players.length - 2)) * 3000;
    let ratio = Math.max(0, matchTimeRemaining / max);
    timerEl.style.width = (ratio * 100) + '%';
    let secs = Math.max(0, Math.ceil(matchTimeRemaining / 60));
    let m = Math.floor(secs / 60), s = secs % 60;
    timerText.textContent = `${m}:${s.toString().padStart(2, '0')}`;
    if (ratio < 0.25) timerEl.style.background = 'linear-gradient(90deg, #ff0000, #ff4400)';
    else timerEl.style.background = 'linear-gradient(90deg, #ff4400, #ffaa00)';
}

function updateTerrorRadius() {
    const overlay = document.getElementById('terror-overlay');
    let killer = players.find(p => p.role === 'killer');
    if (!killer) { overlay.style.opacity = '0'; return; }
    let terrorRange = killer.charData.terrorRadius || 200;
    if (killer.stealthActive) terrorRange = 0;
    let maxTerror = 0;
    for (let p of players) { if (p.role !== 'survivor' || !p.alive || p.escaped) continue; let d = Math.hypot(p.x - killer.x, p.y - killer.y); if (d < terrorRange) { maxTerror = Math.max(maxTerror, 1 - d / terrorRange); } }
    let pulse = Math.sin(gameTimer * 0.08) * 0.15 + 0.85;
    overlay.style.opacity = (maxTerror * 0.55 * pulse).toString();
}

function handleLockerExit(p) { const c = p.controls; if (keysJustPressed[c.action] || keysJustPressed[c.ability]) { for (let locker of lockers) { if (locker.occupied === p) { p.inLocker = false; locker.occupied = null; break; } } } }

function handleWiggle(p) {
    const c = p.controls;
    if (keys[c.action] && !p._wiggleKeyHeld) { p.wiggleProgress += 5; p._wiggleKeyHeld = true; }
    if (!keys[c.action]) p._wiggleKeyHeld = false;
    if (p.wiggleProgress > 0) p.wiggleProgress -= 0.15;
    if (p.wiggleProgress >= 100) {
        p.carried = false; p.dying = false; p.injured = true; p.health = 1; p.wiggleProgress = 0; p.speedBoost = 45; p.unhookCooldown = 90;
        for (let k of players) { if (k.role === 'killer' && k.carrying === p) { k.carrying = null; k.stunned = 60; break; } }
        showGameMessage(`${p.charData.name} escapou!`, 90); spawnDust(p.x, p.y);
    }
}

function updatePlayerInput(p) {
    const c = p.controls; p.vx = 0; p.vy = 0;
    if (p.stunned > 0 || p.dying) return;
    if (keys[c.up]) { p.vy = -1; p.facing = 1; }
    if (keys[c.down]) { p.vy = 1; p.facing = 0; }
    if (keys[c.left]) { p.vx = -1; p.facing = 2; }
    if (keys[c.right]) { p.vx = 1; p.facing = 3; }
    if (p.vx !== 0 && p.vy !== 0) { p.vx *= 0.707; p.vy *= 0.707; }
    p.isRunning = (p.vx !== 0 || p.vy !== 0);
    if (p.isRunning) { p.animTimer++; if (p.animTimer > 8) { p.animTimer = 0; p.animFrame = (p.animFrame + 1) % 4; }
        if (p.role === 'survivor' && p.hasPerk('sprintburst') && !p.sprintBurstUsed && !p.lastRunning) { p.speedBoost = Math.max(p.speedBoost, 30); p.sprintBurstUsed = true; spawnDust(p.x, p.y); }
    } else { p.animFrame = 0; if (p.role === 'survivor' && p.hasPerk('sprintburst') && p.sprintBurstUsed) { p._sprintResetTimer++; if (p._sprintResetTimer > 300) { p.sprintBurstUsed = false; p._sprintResetTimer = 0; } } else p._sprintResetTimer = 0; }
    p.lastRunning = p.isRunning;
}

function updatePlayerPhysics(p) {
    let nx = p.x + p.vx * p.speed, ny = p.y + p.vy * p.speed; const size = 10;
    if (!isWalkable(nx - size, p.y - size) || !isWalkable(nx + size, p.y - size) || !isWalkable(nx - size, p.y + size) || !isWalkable(nx + size, p.y + size)) nx = p.x;
    if (!isWalkable(p.x - size, ny - size) || !isWalkable(p.x + size, ny - size) || !isWalkable(p.x - size, ny + size) || !isWalkable(p.x + size, ny + size)) ny = p.y;
    // Dropped pallets block EVERYONE (vault needed to cross)
    for (let pal of pallets) { 
        if (pal.dropped && !pal.broken) { 
            let dx = nx - (pal.x + TILE / 2), dy = ny - (pal.y + TILE / 2); 
            if (Math.abs(dx) < TILE * 0.6 && Math.abs(dy) < TILE * 0.6) {
                // Block unless player is vaulting
                if (!p._vaulting) { nx = p.x; ny = p.y; }
            }
        } 
    }
    // Closed doors block killer only (survivors pass through open doors)
    for (let door of doors) { if (door.closed && !door.broken) { let dx = nx - (door.x + TILE / 2), dy = ny - (door.y + TILE / 2); if (Math.abs(dx) < TILE * 0.6 && Math.abs(dy) < TILE * 0.6 && p.role === 'killer') { nx = p.x; ny = p.y; } } }
    p.x = nx; p.y = ny;
}

function isWalkable(px, py) { let tx = Math.floor(px / TILE), ty = Math.floor(py / TILE); if (tx < 0 || tx >= currentMap.width || ty < 0 || ty >= currentMap.height) return false; return currentMap.grid[ty][tx] !== 1; }

function updatePlayerTimers(p) {
    if (p.stunned > 0) { let r = p.role === 'killer' && p.hasPerk('enduring') ? 1.5 : 1; p.stunned -= r; }
    if (p.attackCooldown > 0) { let r = p.role === 'killer' && p.hasPerk('brutal') ? 1.4 : 1; p.attackCooldown -= r; }
    if (p.abilityCooldown > 0) p.abilityCooldown--;
    if (p.abilityActive > 0) { 
        p.abilityActive--; 
        if (p.abilityActive === 0) { 
            // Ability ended naturally
            if (p._chainsawActive) { p._chainsawActive = false; }
            if (p._chuckyHiding) { p._chuckyHiding = false; p.stealthActive = false; p.abilityCooldown = 180; }
            if (p._crawlerMode) { p._crawlerMode = false; p.abilityCooldown = 120; }
            if (p._frenzyMode) { p._frenzyMode = false; p.stunned = 50; /* big fatigue after frenzy */ }
            p.stealthActive = false; 
        }
        // Hillbilly chainsaw: check wall collision during run
        if (p._chainsawActive) {
            for (let s of players) { if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&!s.carried&&s.hookState===0) {
                if (Math.hypot(p.x-s.x, p.y-s.y) < TILE*0.8) { hitSurvivor(s, p); p._chainsawActive = false; p.abilityActive = 0; p.stunned = 40; break; }
            }}
            let checkX = p.x, checkY = p.y;
            switch(p.facing) { case 0: checkY += 8; break; case 1: checkY -= 8; break; case 2: checkX -= 8; break; case 3: checkX += 8; break; }
            if (!isWalkable(checkX, checkY)) { p._chainsawActive = false; p.abilityActive = 0; p.stunned = 60; showGameMessage('Colisão!', 30); spawnDust(p.x, p.y); }
        }
        // Legion frenzy: auto-hit nearby survivors (only damages once per survivor)
        if (p._frenzyMode) {
            for (let s of players) { if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&!s.carried&&s.hookState===0) {
                if (Math.hypot(p.x-s.x, p.y-s.y) < TILE*0.7 && !s._frenzyHitBy) {
                    s._frenzyHitBy = true; // mark so we don't double-hit
                    s.health--; s.injured = true; s.speedBoost = 40;
                    if (s.health <= 0) { s.dying = true; s.dyingTimer = 0; }
                    p._frenzyHits++;
                    spawnBlood(s.x, s.y, 5);
                    // Extend frenzy slightly per hit
                    p.abilityActive = Math.min(p.abilityActive + 20, 90);
                    showGameMessage(`Frenzy Hit! (${p._frenzyHits})`, 25);
                    setTimeout(() => { s._frenzyHitBy = false; }, 3000); // reset after 3s
                }
            }}
        }
        // Nurse chain blink window
        if (p._chainBlinkReady && p._chainBlinkReady > 0) { p._chainBlinkReady--; }
    }
    // Springtrap sonic traps: check if survivors walk near them
    if (p.role === 'killer' && p._springTraps && p._springTraps.length > 0) {
        for (let trap of p._springTraps) {
            if (!trap.active) continue;
            for (let s of players) {
                if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&s.hookState===0) {
                    if (Math.hypot(trap.x-s.x, trap.y-s.y) < TILE*1.5) {
                        // Triggered! Reveal survivor
                        trap.active = false;
                        s.revealKiller = true;
                        setTimeout(() => { s.revealKiller = false; }, 4000);
                        showGameMessage('Armadilha sonora ativada!', 40);
                        spawnParticle(trap.x, trap.y, '#aacc00', 20, 0, -1, 4);
                    }
                }
            }
        }
        p._springTraps = p._springTraps.filter(t => t.active);
    }
    if (p.speedBoost > 0) p.speedBoost--;
    if (p.attackTimer > 0) { p.attackTimer--; if (p.attackTimer === 0) p.attacking = false; }
    if (p.borrowedTimeActive > 0) p.borrowedTimeActive--;
    if (p.deadHardCooldown > 0) p.deadHardCooldown--;
    if (p.deadHardActive > 0) p.deadHardActive--;
    if (p._vaulting > 0) p._vaulting--;
    if (p._vaultCooldown > 0) p._vaultCooldown--;
}

function updatePerks(p) {
    if (p.role === 'survivor' && p.hasPerk('selfcare') && p.injured && !p.dying && !p.carried && p.hookState === 0) {
        let inCombat = p.speedBoost > 0 || p.stunned > 0;
        if (!inCombat) { p.passiveHealTimer++; if (p.passiveHealTimer > 600) { p.health = Math.min(p.health + 0.002, p.maxHealth); if (p.health >= p.maxHealth) { p.injured = false; p.passiveHealTimer = 0; } } } else p.passiveHealTimer = 0;
    }
    if (p.role === 'survivor' && p._bloodhoundSlow > 0) p._bloodhoundSlow--;
}


// ============================================================
// KILLER & SURVIVOR LOGIC
// ============================================================
function updateKiller(p) {
    const c = p.controls;
    // Check if there's a dying survivor nearby to pick up (don't attack if so)
    let nearbyDying = false;
    if (keysJustPressed[c.action] && !p.carrying) {
        for (let s of players) { if (s.role === 'survivor' && s.dying && !s.carried && s.unhookCooldown <= 0) { let d = Math.hypot(p.x - s.x, p.y - s.y); if (d < TILE) { nearbyDying = true; break; } } }
    }
    if (keysJustPressed[c.action] && p.attackCooldown <= 0 && !p.attacking && !p.carrying && !nearbyDying && p.stunned <= 0) { p.attacking = true; p.attackTimer = p.charData.attackDuration; p.attackCooldown = p.charData.attackCooldown; performAttack(p); }
    if (keys[c.action] && !p.attacking && !p.carrying) {
        // Killer vault over pallet (just pressed = vault, hold = break)
        let didKillerVault = false;
        if (keysJustPressed[c.action] && p._vaultCooldown <= 0) {
            for (let pal of pallets) { if (pal.dropped && !pal.broken) { let d = Math.hypot(p.x - (pal.x + TILE / 2), p.y - (pal.y + TILE / 2)); if (d < TILE * 1.2) {
                // Killer vaults (slower than survivor - brief stun)
                p._vaulting = 18; p._vaultCooldown = 40; p.stunned = 15;
                let pushDist = TILE * 1.2;
                switch(p.facing) { case 0: p.y += pushDist; break; case 1: p.y -= pushDist; break; case 2: p.x -= pushDist; break; case 3: p.x += pushDist; break; }
                spawnParticle(pal.x + TILE/2, pal.y + TILE/2, '#ffffff22', 10, 0, -1, 3);
                didKillerVault = true; break;
            } } }
        }
        // Hold action near pallet = break it
        if (!didKillerVault) {
            for (let pal of pallets) { if (pal.dropped && !pal.broken) { let d = Math.hypot(p.x - (pal.x + TILE / 2), p.y - (pal.y + TILE / 2)); if (d < TILE * 1.2) { pal.broken = true; pal.breakAnim = 10; p.stunned = p.hasPerk('bamboozle') ? 25 : 40; spawnDust(pal.x + TILE / 2, pal.y + TILE / 2); break; } } }
        }
        // Killer breaks closed doors
        for (let door of doors) { if (door.closed && !door.broken) { let d = Math.hypot(p.x - (door.x + TILE / 2), p.y - (door.y + TILE / 2)); if (d < TILE * 1.2) { door.broken = true; door.breakAnim = 10; p.stunned = 20; spawnDust(door.x + TILE / 2, door.y + TILE / 2); showGameMessage('Porta destruída!', 40); break; } } }
        for (let s of players) { if (s.role === 'survivor' && s.dying && !s.carried && s.unhookCooldown <= 0) { let d = Math.hypot(p.x - s.x, p.y - s.y); if (d < TILE) { s.carried = true; s.dying = false; s.wiggleProgress = 0; p.carrying = s; break; } } }
    }
    if (p.carrying) {
        p.carrying.x = p.x; p.carrying.y = p.y - 12;
        if (keysJustPressed[c.action]) { for (let hook of hooks) { if (hook.occupied || hook.broken) continue; let d = Math.hypot(p.x - (hook.x + TILE / 2), p.y - (hook.y + TILE / 2)); if (d < TILE * 1.2) { let s = p.carrying; s.carried = false; s.hookCount++; s.x = hook.x + TILE / 2; s.y = hook.y + TILE / 2 - 6; if (s.hookCount >= 3) { s.alive = false; s.dying = false; showGameMessage(`${s.charData.name} sacrificado!`, 90); spawnBlood(s.x, s.y, 15); } else { s.hookState = s.hookCount; s.hookTimer = 0; s.hookedOn = hook; hook.occupied = s; } p.carrying = null; if (p.hasPerk('bbq')) p.speedBoost = Math.max(p.speedBoost, 180); break; } } }
        if (keysJustPressed[c.ability] && p.carrying) { let s = p.carrying; s.carried = false; s.dying = true; s.dyingTimer = 0; s.unhookCooldown = 60; p.carrying = null; }
    }
    if (!p.carrying && keysJustPressed[c.ability] && p.abilityCooldown <= 0 && p.abilityActive <= 0) activateKillerAbility(p);
    // Killer kicks generators (regresses progress)
    if (keysJustPressed[c.action] && !p.carrying && !p.attacking) {
        for (let gen of generators) {
            if (gen.completed) continue;
            if (gen.progress <= 0) continue;
            let d = Math.hypot(p.x - (gen.x + TILE / 2), p.y - (gen.y + TILE / 2));
            if (d < TILE * 1.5) {
                gen.progress = Math.max(0, gen.progress - 15); // kick removes 15%
                gen.sparking = true;
                p.stunned = 20; // brief kick animation
                showGameMessage('Gerador chutado!', 40);
                spawnParticle(gen.x + TILE/2, gen.y + TILE/2, '#ff4400', 15, 0, -2, 3);
                spawnParticle(gen.x + TILE/2 + 5, gen.y + TILE/2, '#ffaa00', 12, 1, -1, 2);
                spawnParticle(gen.x + TILE/2 - 5, gen.y + TILE/2, '#ffaa00', 12, -1, -1, 2);
                setTimeout(() => { gen.sparking = false; }, 500);
                break;
            }
        }
    }
    if (keysJustPressed[c.action] && !p.carrying) { for (let locker of lockers) { let d = Math.hypot(p.x - (locker.x + TILE / 2), p.y - (locker.y + TILE / 2)); if (d < TILE && locker.occupied) { let s = locker.occupied; s.inLocker = false; s.health--; if (s.health <= 0) { s.dying = true; s.dyingTimer = 0; } else { s.injured = true; s.speedBoost = 30; } locker.occupied = null; spawnBlood(s.x, s.y, 5); break; } } }
}

function performAttack(p) {
    let range = p.charData.attackRange;
    if (p.abilityActive > 0 && p.charData.ability === 'charge') range *= 1.5;
    if (p.abilityActive > 0 && p.charData.ability === 'frenzy') p.attackCooldown = Math.floor(p.charData.attackCooldown * 0.5);
    let ax = p.x, ay = p.y;
    switch (p.facing) { case 0: ay += range * 0.7; break; case 1: ay -= range * 0.7; break; case 2: ax -= range * 0.7; break; case 3: ax += range * 0.7; break; }
    spawnParticle(ax, ay, p.charData.weaponColor, 15, 0, 0, 6);
    for (let s of players) {
        if (s.role === 'survivor' && s.alive && !s.dying && !s.inLocker && !s.carried && s.hookState === 0) {
            let d = Math.hypot(ax - s.x, ay - s.y);
            if (d < range) { 
                if (s.deadHardActive > 0) continue; 
                if (s.borrowedTimeActive > 0) { s.borrowedTimeActive = 0; s.speedBoost = 60; continue; }
                // Check if a dropped pallet blocks the attack (can't hit through pallets)
                let blocked = false;
                for (let pal of pallets) {
                    if (pal.dropped && !pal.broken) {
                        let palCx = pal.x + TILE/2, palCy = pal.y + TILE/2;
                        // Check if pallet is between killer and survivor
                        let dKillerPal = Math.hypot(p.x - palCx, p.y - palCy);
                        let dSurvPal = Math.hypot(s.x - palCx, s.y - palCy);
                        if (dKillerPal < TILE * 1.5 && dSurvPal < TILE * 1.5 && dKillerPal + dSurvPal < d + TILE) {
                            blocked = true; break;
                        }
                    }
                }
                if (blocked) continue;
                // Check if wall blocks attack
                if (!isWalkable(ax, ay)) continue;
                hitSurvivor(s, p); 
            }
        }
    }
}

function hitSurvivor(s, killer) {
    // Hillbilly chainsaw = instadown (2 estados de vida)
    if (killer._chainsawActive) {
        s.health = 0; s.dying = true; s.dyingTimer = 0; s.injured = true;
        s.speedBoost = 30; killer.attackCooldown = 240; killer.stunned = 50;
        spawnBlood(s.x, s.y, 12);
        showGameMessage('INSTADOWN!', 60);
        return;
    }
    s.health--; s.speedBoost = 90; killer.attackCooldown = 300; killer.stunned = 45; spawnBlood(s.x, s.y, 8);
    if (killer.hasPerk('ironfist')) { let kbDist = 40; switch (killer.facing) { case 0: s.y += kbDist; break; case 1: s.y -= kbDist; break; case 2: s.x -= kbDist; break; case 3: s.x += kbDist; break; } if (!isWalkable(s.x, s.y)) { s.x = killer.x; s.y = killer.y; } }
    if (killer.hasPerk('bloodhound')) s._bloodhoundSlow = 180;
    if (s.health <= 0) { s.dying = true; s.dyingTimer = 0; s.injured = true; } else s.injured = true;
}

function activateKillerAbility(p) {
    switch (p.charData.ability) {
        case 'trap':
            // TRAPPER: Coloca armadilha de urso. Pode coletar mais no mapa (lockers dão traps extras)
            if (p.trapCount > 0) { 
                traps.push({ x: p.x, y: p.y, active: true, triggered: false }); 
                p.trapCount--; p.abilityCooldown = 120;
                p.abilityActive = 20; // crouch animation
                spawnParticle(p.x, p.y, '#ffaa00', 20, 0, -1, 3);
                showGameMessage(`Armadilha! (${p.trapCount} restantes)`, 40);
            } else {
                // Sem armadilhas - verificar se perto de um locker para reabastecer
                for (let locker of lockers) {
                    let d = Math.hypot(p.x - (locker.x + TILE/2), p.y - (locker.y + TILE/2));
                    if (d < TILE * 1.5 && !locker.occupied) {
                        p.trapCount = Math.min(p.trapCount + 2, 5);
                        p.stunned = 30;
                        showGameMessage(`Reabasteceu! (${p.trapCount} armadilhas)`, 50);
                        spawnParticle(locker.x + TILE/2, locker.y + TILE/2, '#ffaa0044', 20, 0, -1, 3);
                        break;
                    }
                }
            }
            break;
            
        case 'uncloak':
            // WRAITH: Ativa sino = fica invisível + sem terror radius + speed up
            // Reativar = sair da invisibilidade com speed burst (demora 2s para "uncloak")
            if (p.stealthActive) {
                // Saindo da invisibilidade (toca sino, barulho)
                p.stealthActive = false;
                p.abilityActive = 0;
                p.speedBoost = Math.max(p.speedBoost, 90); // burst ao sair
                p.stunned = 10; // breve demora ao sair
                p.abilityCooldown = 180;
                spawnDust(p.x, p.y);
                for (let i = 0; i < 4; i++) spawnParticle(p.x+(Math.random()-0.5)*20, p.y+(Math.random()-0.5)*20, '#44ccff', 20, 0, -1, 3);
            } else {
                // Entrando na invisibilidade
                p.abilityActive = 300; // 5 segundos invisível
                p.stealthActive = true;
                p.abilityCooldown = 0; // pode sair quando quiser
                spawnParticle(p.x, p.y, '#44ccff', 25, 0, -1, 5);
            }
            break;
            
        case 'hatchet':
            // HUNTRESS: Arremessa machado (projétil). Começa com 5, reabastece em lockers.
            if (!p._hatchetCount && p._hatchetCount !== 0) p._hatchetCount = 5;
            if (p._hatchetCount > 0) {
                p._hatchetCount--;
                p.abilityCooldown = 50; // rápido entre arremessos
                p.abilityActive = 15; // wind-up animation
                let hx = p.x, hy = p.y;
                let hdx = 0, hdy = 0, spd = 5;
                switch(p.facing) { case 0: hdy = spd; break; case 1: hdy = -spd; break; case 2: hdx = -spd; break; case 3: hdx = spd; break; }
                let hatchetLife = 40;
                let hatchetInterval = setInterval(() => {
                    hx += hdx; hy += hdy; hatchetLife--;
                    spawnParticle(hx, hy, '#888888', 6, 0, 0, 2);
                    for (let s of players) {
                        if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&!s.carried&&s.hookState===0) {
                            if (Math.hypot(hx-s.x, hy-s.y) < 16) {
                                if (s.deadHardActive > 0) continue;
                                if (s.borrowedTimeActive > 0) { s.borrowedTimeActive=0; s.speedBoost=60; } 
                                else hitSurvivor(s, p);
                                hatchetLife=0; break;
                            }
                        }
                    }
                    if (!isWalkable(hx, hy)) hatchetLife = 0;
                    if (hatchetLife <= 0) clearInterval(hatchetInterval);
                }, 16);
                spawnParticle(p.x, p.y, '#88cc44', 12, hdx*0.5, hdy*0.5, 3);
            } else {
                // Sem machadinhas - reabastecer em locker
                for (let locker of lockers) {
                    let d = Math.hypot(p.x - (locker.x+TILE/2), p.y - (locker.y+TILE/2));
                    if (d < TILE * 1.5 && !locker.occupied) {
                        p._hatchetCount = 5;
                        p.stunned = 40; // demora a pegar
                        showGameMessage('Machadinhas reabastecidas! (5/5)', 50);
                        break;
                    }
                }
                if (p._hatchetCount === 0) showGameMessage('Sem machadinhas! Vá a um armário.', 40);
            }
            break;
            
        case 'blink':
            // NURSE: Blink teleporte + possibilidade de chain blink. Fadiga após.
            p.abilityCooldown = 180;
            let blinkDist = TILE * 5;
            let bx = p.x, by = p.y;
            switch(p.facing) { case 0: by += blinkDist; break; case 1: by -= blinkDist; break; case 2: bx -= blinkDist; break; case 3: bx += blinkDist; break; }
            // Try full blink, then shorter
            let blinked = false;
            for (let d = blinkDist; d > TILE; d -= TILE) {
                let tx2 = p.x, ty2 = p.y;
                switch(p.facing) { case 0: ty2 += d; break; case 1: ty2 -= d; break; case 2: tx2 -= d; break; case 3: tx2 += d; break; }
                if (isWalkable(tx2, ty2)) { 
                    for (let i = 0; i < 6; i++) spawnParticle(p.x+(Math.random()-0.5)*12, p.y+(Math.random()-0.5)*12, '#88aaff', 20, (Math.random()-0.5)*2, (Math.random()-0.5)*2, 2);
                    p.x = tx2; p.y = ty2; 
                    for (let i = 0; i < 6; i++) spawnParticle(p.x+(Math.random()-0.5)*12, p.y+(Math.random()-0.5)*12, '#88aaff', 20, (Math.random()-0.5)*2, (Math.random()-0.5)*2, 2);
                    blinked = true;
                    // Chain blink window (can blink again within 1s for half distance)
                    p._chainBlinkReady = 40;
                    break; 
                }
            }
            // Fatigue: stun after blink (nurse looks at ground)
            if (blinked) p.stunned = 35; // 35 frames = ~0.6s fadiga
            break;
            
        case 'chainsaw':
            // HILLBILLY: Corrida de motosserra em alta velocidade. INSTADOWN se acertar.
            // Colide com parede = stun grande
            p.abilityActive = 50; // duração da corrida
            p.abilityCooldown = 150;
            p._chainsawActive = true;
            p._chainsawDir = p.facing;
            spawnDust(p.x, p.y);
            // A velocidade é aplicada no speed getter. Checagem de colisão no updateKillerAbilities.
            break;
            
        case 'shred':
            // DEMOGORGON: Dar o Bote - salto longo para frente, quebra pallets, fere survivors.
            // Também: segurar ability = criar portal (secundário)
            p.abilityCooldown = 120;
            p.abilityActive = 20;
            let shredDist = TILE * 3.5;
            let sx2 = p.x, sy2 = p.y;
            switch(p.facing) { case 0: sy2 += shredDist; break; case 1: sy2 -= shredDist; break; case 2: sx2 -= shredDist; break; case 3: sx2 += shredDist; break; }
            // Try to lunge, stop at wall
            let finalX = p.x, finalY = p.y;
            for (let d = TILE; d <= shredDist; d += TILE*0.5) {
                let checkX = p.x, checkY = p.y;
                switch(p.facing) { case 0: checkY += d; break; case 1: checkY -= d; break; case 2: checkX -= d; break; case 3: checkX += d; break; }
                if (isWalkable(checkX, checkY)) { finalX = checkX; finalY = checkY; }
                else break;
            }
            p.x = finalX; p.y = finalY;
            // Break pallets in path
            for (let pal of pallets) { if (pal.dropped && !pal.broken) { if (Math.hypot(p.x-(pal.x+TILE/2), p.y-(pal.y+TILE/2)) < TILE*1.5) { pal.broken = true; pal.breakAnim = 10; spawnDust(pal.x+TILE/2, pal.y+TILE/2); } } }
            // Hit survivors at landing
            for (let s of players) { if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&!s.carried&&s.hookState===0) { if (Math.hypot(p.x-s.x, p.y-s.y) < TILE*1.8) { if (s.deadHardActive > 0) continue; hitSurvivor(s, p); } } }
            for (let i = 0; i < 8; i++) spawnParticle(p.x+(Math.random()-0.5)*20, p.y+(Math.random()-0.5)*20, '#ff4466', 18, (Math.random()-0.5)*3, (Math.random()-0.5)*3, 3);
            break;
            
        case 'tailstrike':
            // XENOMORFO: Ataque de cauda de longo alcance em modo quadrúpede
            // Se não está em modo rastreador, entra nele; se já está, ataca com cauda
            if (!p._crawlerMode) {
                // Entrar no modo rastreador (quadrúpede)
                p._crawlerMode = true;
                p.abilityActive = 300; // modo dura 5s
                p.abilityCooldown = 0; // pode atacar de cauda enquanto ativo
                showGameMessage('Modo Rastreador!', 30);
                spawnParticle(p.x, p.y, '#4488ff22', 20, 0, 0, 4);
            } else {
                // Ataque de cauda (longo alcance na direção)
                p._crawlerMode = false;
                p.abilityActive = 15;
                p.abilityCooldown = 120;
                let tailRange = TILE * 3;
                let ttx = p.x, tty = p.y;
                switch(p.facing) { case 0: tty += tailRange; break; case 1: tty -= tailRange; break; case 2: ttx -= tailRange; break; case 3: ttx += tailRange; break; }
                for (let s of players) { if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&!s.carried&&s.hookState===0) {
                    let distToTip = Math.hypot(ttx-s.x, tty-s.y);
                    let distToLine = Math.hypot(p.x-s.x, p.y-s.y);
                    if (distToTip < TILE*1.5 || (distToLine < tailRange && distToTip < TILE*2.5)) {
                        if (s.deadHardActive > 0) continue;
                        hitSurvivor(s, p); break;
                    }
                } }
                for (let i = 0; i < 6; i++) { let frac=i/6; spawnParticle(p.x+(ttx-p.x)*frac, p.y+(tty-p.y)*frac, '#4488ff', 12, 0, 0, 2); }
            }
            break;
            
        case 'magehand':
            // VECNA: Cicla entre 4 magias. Ability alterna; Action ativa a selecionada.
            // Simplificado: cada uso cicla e ativa a próxima magia
            if (!p._vecnaSpell) p._vecnaSpell = 0;
            p._vecnaSpell = (p._vecnaSpell + 1) % 4;
            p.abilityCooldown = 200;
            p.abilityActive = 20;
            
            switch(p._vecnaSpell) {
                case 0: // Voo Clérigo — dash rápido ignorando obstáculos
                    let flyDist = TILE * 4;
                    let fx = p.x, fy = p.y;
                    switch(p.facing) { case 0: fy += flyDist; break; case 1: fy -= flyDist; break; case 2: fx -= flyDist; break; case 3: fx += flyDist; break; }
                    // Pode atravessar (ignora colisão)
                    p.x = fx; p.y = fy;
                    // Mas corrige se fora do mapa
                    p.x = Math.max(TILE, Math.min(p.x, (MAP_W-1)*TILE));
                    p.y = Math.max(TILE, Math.min(p.y, (MAP_H-1)*TILE));
                    showGameMessage('Voo Clérigo!', 30);
                    for (let i = 0; i < 5; i++) spawnParticle(p.x+(Math.random()-0.5)*16, p.y+(Math.random()-0.5)*16, '#ff660044', 15, 0, -1, 3);
                    break;
                case 1: // Voo dos Mortos — projétil espectral que fere
                    let gdx = 0, gdy = 0;
                    switch(p.facing) { case 0: gdy = 4; break; case 1: gdy = -4; break; case 2: gdx = -4; break; case 3: gdx = 4; break; }
                    let gx = p.x, gy = p.y, gLife = 35;
                    let ghostInt = setInterval(() => {
                        gx += gdx; gy += gdy; gLife--;
                        spawnParticle(gx, gy, '#8844ff', 8, (Math.random()-0.5), (Math.random()-0.5), 2);
                        for (let s of players) { if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&!s.carried&&s.hookState===0) { if (Math.hypot(gx-s.x, gy-s.y) < 18) { hitSurvivor(s, p); gLife=0; break; } } }
                        if (!isWalkable(gx, gy)) gLife = 0;
                        if (gLife <= 0) clearInterval(ghostInt);
                    }, 16);
                    showGameMessage('Voo dos Mortos!', 30);
                    break;
                case 2: // Esfera Sombria — revela survivors num raio por 3 segundos
                    for (let s of players) { if (s.role==='survivor'&&s.alive) { let d = Math.hypot(p.x-s.x, p.y-s.y); if (d < TILE*10) { s.revealKiller = true; setTimeout(()=>{s.revealKiller=false;}, 3000); } } }
                    showGameMessage('Esfera Sombria — Auras reveladas!', 60);
                    spawnParticle(p.x, p.y, '#ff66ff22', 30, 0, 0, 6);
                    break;
                case 3: // Mão Mágica — puxa survivor mais próximo ou bloqueia pallet
                    let closest = null, cDist = TILE * 6;
                    for (let s of players) { if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&!s.carried&&s.hookState===0) { let d = Math.hypot(p.x-s.x, p.y-s.y); if (d < cDist) { cDist = d; closest = s; } } }
                    if (closest) {
                        let pullDist = cDist * 0.4;
                        let angle = Math.atan2(p.y-closest.y, p.x-closest.x);
                        let nx = closest.x + Math.cos(angle)*pullDist;
                        let ny = closest.y + Math.sin(angle)*pullDist;
                        if (isWalkable(nx, ny)) { closest.x = nx; closest.y = ny; }
                        closest.stunned = 25;
                        showGameMessage('Mão Mágica!', 40);
                        for (let i = 0; i < 6; i++) { let frac=i/6; spawnParticle(p.x+(closest.x-p.x)*frac, p.y+(closest.y-p.y)*frac, '#ff6600', 15, 0, -0.5, 2); }
                    } else {
                        // Sem survivor perto: bloqueia pallet mais próxima
                        for (let pal of pallets) { if (!pal.dropped && !pal.broken) { let d = Math.hypot(p.x-(pal.x+TILE/2), p.y-(pal.y+TILE/2)); if (d < TILE*5) { pal.dropped = true; pal.dropAnim = 5; showGameMessage('Pallet bloqueada!', 40); break; } } }
                    }
                    break;
            }
            break;
            
        case 'hideyho':
            // CHUCKY: Modo stealth baixo + dash ao sair. Gera pegadas falsas.
            if (p._chuckyHiding) {
                // Saindo do stealth com Slash & Dash
                p._chuckyHiding = false;
                p.stealthActive = false;
                p.abilityActive = 0;
                // Dash forward (passa por baixo de pallets)
                let dashDist = TILE * 2.5;
                let dx = p.x, dy = p.y;
                switch(p.facing) { case 0: dy += dashDist; break; case 1: dy -= dashDist; break; case 2: dx -= dashDist; break; case 3: dx += dashDist; break; }
                if (isWalkable(dx, dy)) { p.x = dx; p.y = dy; }
                // Attack ao final do dash
                p.attacking = true; p.attackTimer = p.charData.attackDuration;
                performAttack(p);
                p.abilityCooldown = 180;
                p.speedBoost = Math.max(p.speedBoost, 30);
            } else {
                // Entrando no stealth (Hide & Seek)
                p._chuckyHiding = true;
                p.stealthActive = true;
                p.abilityActive = 150; // dura 2.5s
                p.abilityCooldown = 0; // pode sair quando quiser
                // Gerar pegadas falsas (scratch marks falsos)
                for (let i = 0; i < 5; i++) {
                    let fakeX = p.x + (Math.random()-0.5) * TILE * 6;
                    let fakeY = p.y + (Math.random()-0.5) * TILE * 6;
                    if (typeof spawnScratchMark === 'function') spawnScratchMark(fakeX, fakeY, null);
                }
                showGameMessage('Escondido...', 30);
                spawnParticle(p.x, p.y, '#ff444422', 15, 0, 0, 3);
            }
            break;
            
        case 'chains':
            // PINHEAD: Lança correntes que prendem o survivor e o puxam. Também: Caixa de Lament.
            p.abilityCooldown = 180;
            p.abilityActive = 20;
            let chainDx = 0, chainDy = 0;
            switch(p.facing) { case 0: chainDy = 5; break; case 1: chainDy = -5; break; case 2: chainDx = -5; break; case 3: chainDx = 5; break; }
            let cx = p.x, cy = p.y, cLife = 35;
            let chainHit = false;
            let chainInt = setInterval(() => {
                cx += chainDx; cy += chainDy; cLife--;
                // Draw chain links
                spawnParticle(cx, cy, '#888888', 6, 0, 0, 2);
                spawnParticle(cx + (Math.random()-0.5)*4, cy + (Math.random()-0.5)*4, '#ffaa0044', 4, 0, 0, 1);
                for (let s of players) {
                    if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&!s.carried&&s.hookState===0) {
                        if (Math.hypot(cx-s.x, cy-s.y) < 18) {
                            // Chain hit! Survivor is bound — stunned + slowed + pulled slightly
                            s.stunned = 60; // bound for 1 second
                            s._bloodhoundSlow = 120; // slowed for 2 seconds
                            // Pull them slightly toward Pinhead
                            let pullAngle = Math.atan2(p.y-s.y, p.x-s.x);
                            let pullX = s.x + Math.cos(pullAngle) * TILE;
                            let pullY = s.y + Math.sin(pullAngle) * TILE;
                            if (isWalkable(pullX, pullY)) { s.x = pullX; s.y = pullY; }
                            showGameMessage('Correntes!', 40);
                            for (let i = 0; i < 5; i++) spawnParticle(s.x+(Math.random()-0.5)*10, s.y+(Math.random()-0.5)*10, '#ffaa00', 15, (Math.random()-0.5)*2, (Math.random()-0.5)*2, 2);
                            chainHit = true; cLife = 0; break;
                        }
                    }
                }
                if (!isWalkable(cx, cy)) cLife = 0;
                if (cLife <= 0) clearInterval(chainInt);
            }, 16);
            // Chain launch particles
            for (let i = 0; i < 3; i++) spawnParticle(p.x+chainDx*i*2, p.y+chainDy*i*2, '#888', 10, chainDx*0.3, chainDy*0.3, 2);
            break;
            
        case 'frenzy':
            // LEGION: Feral Frenzy — sprint massivo, pode acertar múltiplos survivors.
            // Cada hit em frenzy aplica Deep Wound. Ao acabar, stun grande.
            if (p.abilityActive > 0) break; // já em frenzy
            p.abilityActive = 90; // dura 1.5s
            p.abilityCooldown = 150;
            p._frenzyHits = 0;
            p._frenzyMode = true;
            showGameMessage('FRENZY!', 30);
            spawnDust(p.x, p.y);
            for (let i = 0; i < 4; i++) spawnParticle(p.x+(Math.random()-0.5)*14, p.y+(Math.random()-0.5)*14, '#ff44aa', 15, (Math.random()-0.5)*3, (Math.random()-0.5)*3, 2);
            break;
            
        case 'siren':
            // SIREN HEAD: Emite sirene paralisante em área grande.
            // Todos survivors num raio ficam stunned + revelados. Quanto mais perto, mais stun.
            p.abilityActive = 60; // animação da sirene
            p.abilityCooldown = 240;
            p.stunned = 30; // Siren Head fica parado tocando a sirene
            showGameMessage('🔊 SIRENE!', 50);
            // Efeito em área
            let sirenRange = TILE * 7;
            for (let s of players) {
                if (s.role === 'survivor' && s.alive && !s.dying && !s.inLocker && s.hookState === 0) {
                    let d = Math.hypot(p.x - s.x, p.y - s.y);
                    if (d < sirenRange) {
                        // Quanto mais perto, mais stun
                        let intensity = 1 - (d / sirenRange);
                        s.stunned = Math.max(s.stunned, Math.floor(40 + intensity * 60)); // 40-100 frames
                        s.revealKiller = true;
                        setTimeout(() => { s.revealKiller = false; }, 3000);
                        // Particle on affected survivor
                        spawnParticle(s.x, s.y, '#ccaa0044', 20, 0, -1, 3);
                    }
                }
            }
            // Shockwave particles
            for (let i = 0; i < 12; i++) {
                let angle = (i / 12) * Math.PI * 2;
                spawnParticle(p.x + Math.cos(angle)*20, p.y + Math.sin(angle)*20, '#ccaa00', 25, Math.cos(angle)*3, Math.sin(angle)*3, 2);
            }
            break;
            
        case 'springlock':
            // SPRINGTRAP: Investida + coloca armadilhas sonoras que revelam survivors.
            // Toggle: sem armadilha ativa = investida curta. Com cooldown = coloca armadilha sonora.
            if (!p._springTraps) p._springTraps = [];
            if (p._springTraps.length < 3) {
                // Colocar armadilha sonora (revela quando survivor pisa perto)
                p._springTraps.push({ x: p.x, y: p.y, active: true });
                p.abilityCooldown = 120;
                p.abilityActive = 15;
                showGameMessage(`Armadilha sonora! (${p._springTraps.length}/3)`, 40);
                spawnParticle(p.x, p.y, '#aacc00', 15, 0, -1, 3);
            } else {
                // Investida (lunge rápido para frente, como um animatrônico)
                p.abilityCooldown = 180;
                p.abilityActive = 20;
                let lungeDist = TILE * 3;
                let lx = p.x, ly = p.y;
                switch(p.facing) { case 0: ly += lungeDist; break; case 1: ly -= lungeDist; break; case 2: lx -= lungeDist; break; case 3: lx += lungeDist; break; }
                // Move step by step
                let finalLX = p.x, finalLY = p.y;
                for (let d = TILE; d <= lungeDist; d += TILE*0.5) {
                    let checkX = p.x, checkY = p.y;
                    switch(p.facing) { case 0: checkY += d; break; case 1: checkY -= d; break; case 2: checkX -= d; break; case 3: checkX += d; break; }
                    if (isWalkable(checkX, checkY)) { finalLX = checkX; finalLY = checkY; } else break;
                }
                p.x = finalLX; p.y = finalLY;
                // Hit at landing
                for (let s of players) { if (s.role==='survivor'&&s.alive&&!s.dying&&!s.inLocker&&!s.carried&&s.hookState===0) { if (Math.hypot(p.x-s.x, p.y-s.y) < TILE*1.5) { if (s.deadHardActive > 0) continue; hitSurvivor(s, p); } } }
                showGameMessage('Investida!', 30);
                for (let i = 0; i < 6; i++) spawnParticle(p.x+(Math.random()-0.5)*16, p.y+(Math.random()-0.5)*16, '#aacc00', 15, (Math.random()-0.5)*2, (Math.random()-0.5)*2, 2);
                // Reset traps after lunge
                p._springTraps = [];
            }
            break;
            
        // Legacy fallbacks
        case 'charge': p.abilityActive = p.charData.abilityDur; p.abilityCooldown = p.charData.abilityCD; spawnDust(p.x, p.y); break;
        case 'stealth': p.abilityActive = p.charData.abilityDur; p.stealthActive = true; p.abilityCooldown = p.charData.abilityCD; break;
        case 'teleport': if (lockers.length > 0) { let t = lockers[Math.floor(Math.random() * lockers.length)]; if (!t.occupied) { p.x = t.x + TILE / 2; p.y = t.y + TILE / 2; p.abilityCooldown = p.charData.abilityCD; spawnParticle(p.x, p.y, '#cc44cc', 30, 0, -2, 6); } } break;
    }
}

function updateSurvivor(p) {
    if (p._interactAnim > 0) p._interactAnim--;
    const c = p.controls; if (p.hookState > 0) return;
    if (p.dying) {
        p.dyingTimer++;
        if (p.dyingTimer > 2700) { p.alive = false; p.dying = false; }
        // CRAWLING: survivor can move slowly while dying
        const c2 = p.controls;
        let cvx = 0, cvy = 0;
        if (keys[c2.up]) { cvy = -1; p.facing = 1; }
        if (keys[c2.down]) { cvy = 1; p.facing = 0; }
        if (keys[c2.left]) { cvx = -1; p.facing = 2; }
        if (keys[c2.right]) { cvx = 1; p.facing = 3; }
        if (cvx !== 0 && cvy !== 0) { cvx *= 0.707; cvy *= 0.707; }
        let crawlSpeed = 0.5;
        let nx = p.x + cvx * crawlSpeed;
        let ny = p.y + cvy * crawlSpeed;
        if (isWalkable(nx, p.y)) p.x = nx;
        if (isWalkable(p.x, ny)) p.y = ny;
        p.isRunning = (cvx !== 0 || cvy !== 0); // for crawl animation
        // Blood trail while crawling
        if (p.isRunning && gameTimer % 20 === 0) {
            bloodPools.push({ x: p.x + (Math.random()-0.5)*6, y: p.y + (Math.random()-0.5)*4, size: 2 + Math.random()*2, life: 400, maxLife: 400 });
        }
        if (gameTimer % 60 === 0) spawnParticle(p.x + (Math.random() - 0.5) * 10, p.y, '#cc000088', 40, 0, -0.5, 2);
        // Self-recover: hold action to slowly recover (takes 30 seconds alone)
        if (keys[c2.action]) {
            p.dyingTimer -= 1.5; // counteracts the +1 above, net = slowly recovering
            if (p.dyingTimer <= -90) { p.dying = false; p.health = 1; p.injured = true; showGameMessage(`${p.charData.name} se recuperou!`, 60); }
        }
        return;
    }
    
    // Ability key pressed - decide what to do
    if (keysJustPressed[c.ability] && !p.inLocker) {
        // Priority 1: Dead Hard (only if injured + has perk)
        if (p.hasPerk('deadhard') && p.injured && p.deadHardCooldown <= 0) {
            p.deadHardActive = 12; p.deadHardCooldown = 360; spawnDust(p.x, p.y);
        }
        // Priority 2: Use held item
        else if (p.heldItem && p.itemUses > 0) {
            useItem(p);
        }
        // Priority 3: Character ability
        else if (p.abilityCooldown <= 0 && p.abilityActive <= 0) {
            activateSurvivorAbility(p);
        }
    }
    
    if (keys[c.action]) {
        let didAction = false;
        
        // Unhook allies (priority 1)
        if (!didAction) {
            for (let other of players) {
                if (other === p) continue;
                if (other.role === 'survivor' && other.hookState > 0) {
                    let d = Math.hypot(p.x - other.x, p.y - other.y);
                    if (d < TILE * 2) {
                        if (!p._unhookProgress) p._unhookProgress = 0;
                        let speed = p.charData.ability === 'fastunhook' ? 3 : 1.5;
                        p._unhookProgress += speed;
                        if (p._unhookProgress >= 60) { unhookSurvivor(p, other); p._unhookProgress = 0; }
                        didAction = true; break;
                    }
                }
            }
        }
        
        // Heal dying allies (pick them up from the ground)
        if (!didAction) { for (let other of players) { if (other === p) continue; if (other.role === 'survivor' && other.dying && !other.carried && other.hookState === 0) { let d = Math.hypot(p.x - other.x, p.y - other.y); if (d < TILE * 2) {
            if (!p._reviveProgress) p._reviveProgress = 0;
            p._reviveProgress += 2;
            if (p._reviveProgress >= 60) { other.dying = false; other.dyingTimer = 0; other.health = 1; other.injured = true; p._reviveProgress = 0; showGameMessage(`${p.charData.name} levantou ${other.charData.name}!`, 60); spawnParticle(other.x, other.y, '#44ff44', 20, 0, -1, 3); }
            didAction = true; break;
        } } } }
        
        // Heal injured allies
        if (!didAction) { for (let other of players) { if (other === p) continue; if (other.role === 'survivor' && other.injured && !other.dying && other.health < other.maxHealth && other.hookState === 0) { let d = Math.hypot(p.x - other.x, p.y - other.y); if (d < TILE * 1.5) { other.health += 0.015; if (other.health >= other.maxHealth) { other.health = other.maxHealth; other.injured = false; spawnParticle(other.x, other.y, '#44ff44', 30, 0, -1, 3); showGameMessage(`${other.charData.name} curado!`, 60); } didAction = true; break; } } } }
        
        // Search chests for items
        if (!didAction && !p.heldItem) {
            for (let chest of chests) {
                if (chest.opened) continue;
                let d = Math.hypot(p.x - (chest.x + TILE / 2), p.y - (chest.y + TILE / 2));
                if (d < TILE * 1.5) {
                    if (!p._searchProgress) p._searchProgress = 0;
                    p._searchProgress += 2;
                    if (p._searchProgress >= 60) {
                        chest.opened = true;
                        let roll = Math.random();
                        if (roll < 0.5) { p.heldItem = 'medkit'; p.itemUses = 1; }
                        else { p.heldItem = 'flashlight'; p.itemUses = 2; }
                        p._interactAnim = 28;
                        showGameMessage(`${p.charData.name} achou ${p.heldItem === 'medkit' ? '🩹 Kit Médico' : '🔦 Lanterna'}!`, 90);
                        spawnParticle(chest.x + TILE / 2, chest.y + TILE / 2, '#ffcc00', 30, 0, -1, 4);
                        p._searchProgress = 0;
                    }
                    didAction = true; break;
                }
            }
        }
        
        // Enter locker
        if (!didAction) { for (let locker of lockers) { if (!locker.occupied) { let d = Math.hypot(p.x - (locker.x + TILE / 2), p.y - (locker.y + TILE / 2)); if (d < TILE * 0.8) { p.inLocker = true; locker.occupied = p; didAction = true; break; } } } }
        
        // REPAIR GENERATORS
        if (!didAction) {
            for (let gen of generators) {
                if (gen.completed) continue;
                let d = Math.hypot(p.x - (gen.x + TILE / 2), p.y - (gen.y + TILE / 2));
                if (d < TILE * 1.5) {
                    gen.progress += 0.072; // ~23 seconds solo to complete (100 / (23*60))
                    // Sparking effect while repairing
                    if (gameTimer % 20 === 0) spawnParticle(gen.x + TILE/2 + (Math.random()-0.5)*10, gen.y + 4, '#ffcc00', 10, (Math.random()-0.5)*2, -1, 2);
                    if (gen.progress >= 100) {
                        gen.completed = true;
                        gen.progress = 100;
                        gensCompleted++;
                        showGameMessage(`⚡ Gerador concluído! (${gensCompleted}/${GENS_TO_POWER})`, 90);
                        for (let i = 0; i < 8; i++) spawnParticle(gen.x+TILE/2+(Math.random()-0.5)*16, gen.y+TILE/2+(Math.random()-0.5)*16, '#ffcc00', 25, (Math.random()-0.5)*3, -2, 3);
                        // Check if enough gens to power gates
                        if (gensCompleted >= GENS_TO_POWER && !gatesOpen) {
                            gatesOpen = true;
                            for (let g of exitGates) g.open = true;
                            showGameMessage('⚡ GERADORES PRONTOS — PORTÕES ABERTOS!', 180);
                            for (let pl of players) { if (pl.role === 'survivor' && pl.alive && pl.hasPerk('adrenaline') && pl.injured) { pl.health = Math.min(pl.health + 1, pl.maxHealth); if (pl.health >= pl.maxHealth) pl.injured = false; } }
                        }
                    }
                    didAction = true; break;
                }
            }
        }
        
        // Escape through gate
        if (!didAction && gatesOpen) { for (let gate of exitGates) { let d = Math.hypot(p.x - (gate.x + TILE / 2), p.y - (gate.y + TILE / 2)); if (d < TILE) { p.escaped = true; showGameMessage(`${p.charData.name} escapou!`, 90); didAction = true; break; } } }
        
        // Vault over dropped pallet (fast hop) OR Drop standing pallet
        if (!didAction) {
            for (let pal of pallets) {
                let d = Math.hypot(p.x - (pal.x + TILE / 2), p.y - (pal.y + TILE / 2));
                if (d < TILE * 1.2) {
                    if (pal.dropped && !pal.broken && p._vaultCooldown <= 0) {
                        // VAULT over dropped pallet
                        p._vaulting = 12; // frames of vault (passes through)
                        p._vaultCooldown = 30; // cooldown before next vault
                        // Push player to other side
                        let pushDist = TILE * 1.2;
                        switch(p.facing) {
                            case 0: p.y += pushDist; break;
                            case 1: p.y -= pushDist; break;
                            case 2: p.x -= pushDist; break;
                            case 3: p.x += pushDist; break;
                        }
                        spawnParticle(pal.x + TILE/2, pal.y + TILE/2, '#ffffff44', 10, 0, -1, 3);
                        didAction = true; break;
                    } else if (!pal.dropped && !pal.broken) {
                        // DROP standing pallet
                        pal.dropped = true; pal.dropAnim = 8;
                        spawnDust(pal.x + TILE / 2, pal.y + TILE / 2);
                        for (let k of players) { if (k.role === 'killer') { let kd = Math.hypot(k.x - (pal.x + TILE / 2), k.y - (pal.y + TILE / 2)); if (kd < TILE * 1.5) { k.stunned = 120; showGameMessage('Killer atordoado!', 60); } } }
                        didAction = true; break;
                    }
                }
            }
        }
        
        // Close door (survivors can slam doors shut)
        if (!didAction) { for (let door of doors) { if (!door.closed && !door.broken) { let d = Math.hypot(p.x - (door.x + TILE / 2), p.y - (door.y + TILE / 2)); if (d < TILE * 1.2) { door.closed = true; door.closeAnim = 6; spawnDust(door.x + TILE / 2, door.y + TILE / 2); for (let k of players) { if (k.role === 'killer') { let kd = Math.hypot(k.x - (door.x + TILE / 2), k.y - (door.y + TILE / 2)); if (kd < TILE * 1.2) { k.stunned = 60; showGameMessage('Porta na cara!', 50); } } } didAction = true; break; } } } }
    } else {
        // Decay progress slowly instead of instant reset (forgiveness for key flicker)
        if (p._unhookProgress > 0) p._unhookProgress -= 2;
        if (p._unhookProgress < 0) p._unhookProgress = 0;
        if (p._searchProgress > 0) p._searchProgress -= 2;
        if (p._searchProgress < 0) p._searchProgress = 0;
        if (p._reviveProgress > 0) p._reviveProgress -= 2;
        if (p._reviveProgress < 0) p._reviveProgress = 0;
    }
}

function useItem(p) {
    if (!p.heldItem || p.itemUses <= 0) return;
    if (p.heldItem === 'medkit') {
        if (p.injured) {
            p.health = p.maxHealth; p.injured = false; p.itemUses--;
            spawnParticle(p.x, p.y, '#44ff44', 30, 0, -1, 4);
            spawnParticle(p.x - 5, p.y - 5, '#88ffaa', 20, -0.5, -1, 2);
            spawnParticle(p.x + 5, p.y - 5, '#88ffaa', 20, 0.5, -1, 2);
            showGameMessage(`${p.charData.name} usou Kit Médico!`, 60);
            if (p.itemUses <= 0) p.heldItem = null;
        }
    } else if (p.heldItem === 'flashlight') {
        let killer = players.find(k => k.role === 'killer');
        if (killer) {
            let d = Math.hypot(p.x - killer.x, p.y - killer.y);
            if (d < TILE * 5) {
                let dx = killer.x - p.x, dy = killer.y - p.y;
                let facingKiller = false;
                if (p.facing === 0 && dy > 0) facingKiller = true;
                if (p.facing === 1 && dy < 0) facingKiller = true;
                if (p.facing === 2 && dx < 0) facingKiller = true;
                if (p.facing === 3 && dx > 0) facingKiller = true;
                if (facingKiller) {
                    killer.stunned = 90; p.itemUses--;
                    showGameMessage(`${p.charData.name} cegou o Killer!`, 60);
                    // Flash beam particles
                    let beamAngle = Math.atan2(dy, dx);
                    for (let i = 0; i < 8; i++) spawnParticle(p.x + Math.cos(beamAngle) * (i * 8), p.y + Math.sin(beamAngle) * (i * 8), '#ffffaa', 20, Math.cos(beamAngle) * 0.5, Math.sin(beamAngle) * 0.5, 3);
                    spawnParticle(killer.x, killer.y, '#ffffff', 25, 0, 0, 10);
                    if (p.itemUses <= 0) p.heldItem = null;
                }
            }
        }
    }
}

function activateSurvivorAbility(p) {
    switch (p.charData.ability) {
        case 'sprint': p.abilityActive = p.charData.abilityDur; p.speedBoost = p.charData.abilityDur; p.abilityCooldown = p.charData.abilityCD; spawnDust(p.x, p.y); break;
        case 'selfheal': if (p.injured && !p.dying) { p.abilityActive = p.charData.abilityDur; p.abilityCooldown = p.charData.abilityCD; setTimeout(() => { if (p.alive && p.injured) { p.health = p.maxHealth; p.injured = false; } }, p.charData.abilityDur * 16); } break;
        case 'reveal': p.abilityActive = p.charData.abilityDur; p.revealKiller = true; p.abilityCooldown = p.charData.abilityCD; setTimeout(() => { p.revealKiller = false; }, p.charData.abilityDur * 16); break;
    }
}

function updateTraps() {
    for (let trap of traps) { if (!trap.active) continue; for (let p of players) { if (p.role === 'survivor' && p.alive && !p.dying && !p.inLocker && !p.carried && p.hookState === 0) { let d = Math.hypot(p.x - trap.x, p.y - trap.y); if (d < TILE * 0.6) { trap.active = false; trap.triggered = true; p.stunned = 120; p.health--; if (p.health <= 0) { p.dying = true; p.dyingTimer = 0; } else p.injured = true; showGameMessage('Armadilha!', 60); spawnBlood(p.x, p.y, 6); } } } }
}

const HOOK_PHASE1_TIME = 1800;
const HOOK_PHASE2_TIME = 1200;

function updateHooks() {
    for (let p of players) {
        if (p.role !== 'survivor') continue;
        if (p.hookState === 0) { if (p.unhookCooldown > 0) p.unhookCooldown--; continue; }
        p.hookTimer++;
        if (p.hookState === 1) { if (p.hookTimer >= HOOK_PHASE1_TIME) { if (p.hookCount >= 2) sacrificeSurvivor(p); else { p.hookState = 2; p.hookTimer = 0; } } }
        else if (p.hookState === 2) { if (p.hookTimer >= HOOK_PHASE2_TIME) sacrificeSurvivor(p); const c = p.controls; if (keys[c.action]) { p.hookTimer -= 0.5; if (p.hookTimer < 0) p.hookTimer = 0; } }
    }
}

function sacrificeSurvivor(p) { p.alive = false; p.dying = false; p.hookState = 0; if (p.hookedOn) { p.hookedOn.occupied = null; p.hookedOn.broken = true; } p.hookedOn = null; showGameMessage(`${p.charData.name} sacrificado!`, 120); spawnBlood(p.x, p.y, 20); }

function unhookSurvivor(rescuer, hooked) { hooked.hookState = 0; hooked.hookTimer = 0; hooked.health = 1; hooked.injured = true; hooked.dying = false; hooked.unhookCooldown = 90; hooked.speedBoost = 30; if (hooked.hookedOn) hooked.hookedOn.occupied = null; hooked.hookedOn = null; if (rescuer.hasPerk('borrowed')) hooked.borrowedTimeActive = 180; }

function checkWinCondition() {
    let survivors = players.filter(p => p.role === 'survivor');
    let alive = survivors.filter(p => p.alive && !p.escaped);
    let escaped = survivors.filter(p => p.escaped);
    let hooked = survivors.filter(p => p.alive && p.hookState > 0);
    // All survivors dead
    if (alive.length === 0 && escaped.length === 0) endGame('Killer eliminou todos! ☠');
    // Some escaped, rest dead
    if (alive.length === 0 && escaped.length > 0) endGame(`${escaped.length} escaparam! 🏃`);
    // All escaped
    if (escaped.length === survivors.length) endGame('Todos escaparam! 🎉');
    // All remaining alive survivors are on hooks (killer wins)
    if (alive.length > 0 && hooked.length === alive.length && escaped.length === 0) {
        endGame('Killer enganchou todos! ☠');
    }
}

function endGame(msg) {
    gameState = GAME_STATES.ENDED; showGameMessage(msg, 999);
    if (onlineMode && isHost) broadcastToPeers({ type: 'returnToLobby', message: msg });
    
    // Calculate match rewards and show results screen
    let myPlayer = players[myPlayerId || 0];
    let stats = { timeAlive: Math.floor(gameTimer / 60), kills: 0, hooks: 0, hits: 0, escaped: false, unhooks: 0, heals: 0, sacrificed: 0, charKey: myPlayer ? myPlayer.charKey : null };
    if (myPlayer) {
        if (myPlayer.role === 'killer') {
            stats.kills = players.filter(p => p.role === 'survivor' && !p.alive && !p.escaped).length;
            stats.hooks = players.filter(p => p.role === 'survivor').reduce((sum, p) => sum + p.hookCount, 0);
            stats.sacrificed = players.filter(p => p.role === 'survivor' && !p.alive && !p.escaped).length;
        } else {
            stats.escaped = myPlayer.escaped;
        }
    }
    
    let rewards = { bp: 0, xp: 0 };
    if (typeof calculateMatchRewards === 'function' && myPlayer) {
        rewards = calculateMatchRewards(myPlayer.role, stats);
    }
    
    // Show end-of-match results screen after a brief delay
    setTimeout(() => {
        showResultsScreen(msg, myPlayer, stats, rewards);
    }, 1500);
}

function showResultsScreen(msg, myPlayer, stats, rewards) {
    // Remove previous results screen if exists
    let existing = document.getElementById('results-screen');
    if (existing) existing.remove();
    
    let role = myPlayer ? myPlayer.role : 'survivor';
    let charName = myPlayer ? myPlayer.charData.name : 'Player';
    let won = msg.includes('escaparam') || msg.includes('Todos escaparam') || (role === 'killer' && (msg.includes('eliminou') || msg.includes('enganchou')));
    
    let prevLevel = playerProfile.level;
    let xpBar = playerProfile.xp / PROGRESSION.xpPerLevel;
    
    // Build stats rows
    let statsHtml = '';
    if (role === 'killer') {
        statsHtml = `
            <div class="rs-stat"><span class="rs-stat-icon">💀</span><span class="rs-stat-label">Sacrifícios</span><span class="rs-stat-val">${stats.kills}</span></div>
            <div class="rs-stat"><span class="rs-stat-icon">🪝</span><span class="rs-stat-label">Enganchados</span><span class="rs-stat-val">${stats.hooks}</span></div>
            <div class="rs-stat"><span class="rs-stat-icon">⏱️</span><span class="rs-stat-label">Duração</span><span class="rs-stat-val">${Math.floor(stats.timeAlive / 60)}:${String(stats.timeAlive % 60).padStart(2,'0')}</span></div>
        `;
    } else {
        statsHtml = `
            <div class="rs-stat"><span class="rs-stat-icon">${stats.escaped ? '🏃' : '💀'}</span><span class="rs-stat-label">${stats.escaped ? 'Escapou!' : 'Sacrificado'}</span><span class="rs-stat-val">${stats.escaped ? '✓' : '✗'}</span></div>
            <div class="rs-stat"><span class="rs-stat-icon">⏱️</span><span class="rs-stat-label">Sobreviveu</span><span class="rs-stat-val">${Math.floor(stats.timeAlive / 60)}:${String(stats.timeAlive % 60).padStart(2,'0')}</span></div>
        `;
    }
    
    let overlay = document.createElement('div');
    overlay.id = 'results-screen';
    overlay.innerHTML = `
        <div class="rs-backdrop"></div>
        <div class="rs-container">
            <div class="rs-header">
                <div class="rs-result ${won ? 'victory' : 'defeat'}">${won ? '⚔ VITÓRIA' : '💀 DERROTA'}</div>
                <div class="rs-message">${msg}</div>
            </div>
            <div class="rs-body">
                <div class="rs-character">
                    <div class="rs-char-icon">${role === 'killer' ? '🔪' : '🏃'}</div>
                    <div class="rs-char-name">${charName}</div>
                    <div class="rs-char-role">${role === 'killer' ? 'Killer' : 'Survivor'}</div>
                </div>
                <div class="rs-stats">
                    ${statsHtml}
                </div>
                <div class="rs-rewards">
                    <div class="rs-reward-title">RECOMPENSAS</div>
                    <div class="rs-reward-row">
                        <div class="rs-reward-item">
                            <span class="rs-reward-icon">🩸</span>
                            <span class="rs-reward-value rs-animate-count" data-target="${rewards.bp}">0</span>
                            <span class="rs-reward-label">Bloodpoints</span>
                        </div>
                        <div class="rs-reward-item">
                            <span class="rs-reward-icon">⭐</span>
                            <span class="rs-reward-value rs-animate-count" data-target="${rewards.xp}">0</span>
                            <span class="rs-reward-label">XP</span>
                        </div>
                    </div>
                    <div class="rs-xp-bar-container">
                        <div class="rs-xp-label">Nível ${playerProfile.level} — ${playerProfile.xp}/${PROGRESSION.xpPerLevel} XP</div>
                        <div class="rs-xp-bar-bg">
                            <div class="rs-xp-bar-fill" style="width:${xpBar * 100}%"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rs-footer">
                <button class="rs-btn" onclick="closeResultsScreen()">CONTINUAR</button>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);
    
    // Animate reward counters
    setTimeout(() => {
        let counters = overlay.querySelectorAll('.rs-animate-count');
        counters.forEach(el => {
            let target = parseInt(el.getAttribute('data-target'));
            let current = 0;
            let step = Math.max(1, Math.floor(target / 40));
            let interval = setInterval(() => {
                current += step;
                if (current >= target) { current = target; clearInterval(interval); }
                el.textContent = current;
            }, 30);
        });
    }, 500);
}

function closeResultsScreen() {
    let screen = document.getElementById('results-screen');
    if (screen) {
        screen.style.opacity = '0';
        screen.style.transition = 'opacity 0.4s';
        setTimeout(() => {
            screen.remove();
            returnToLobby();
        }, 400);
    } else {
        returnToLobby();
    }
}

function returnToLobby() {
    canvas.style.display = 'none';
    document.getElementById('hud').style.display = 'none';
    document.getElementById('timer-display').style.display = 'none';
    document.getElementById('mobile-controls').style.display = 'none';
    document.getElementById('terror-overlay').style.opacity = '0';
    document.getElementById('game-msg').style.opacity = '0';
    openLobby(gameMode);
}

function showGameMessage(msg, duration) { 
    gameMessage = msg; gameMsgTimer = duration; 
    const el = document.getElementById('game-msg'); 
    if (el) { el.textContent = msg; el.style.opacity = '1'; }
    // Broadcast to peers if we're the host
    if (onlineMode && isHost && peerConnections.length > 0) {
        broadcastToPeers({ type: 'msg', text: msg, dur: duration });
    }
}

// Loading screen with killer info and tips
const GAME_TIPS = [
    'Pallets atordoam o Killer por 2 segundos. Use com sabedoria!',
    'Portas podem ser fechadas na cara do Killer para ganhar tempo.',
    'Baús contêm itens — Kit Médico cura, Lanterna cega o Killer.',
    'Scratch marks revelam por onde survivors correram recentemente.',
    'O Terror Radius indica que o Killer está perto. Esconda-se!',
    'Lockers são ótimos para se esconder, mas o Killer pode abri-los.',
    'Sobreviventes no chão podem rastejar. Segure ação para se recuperar.',
    'Allies podem levantar survivors caídos segurando a tecla de ação.',
    'Cada Killer tem uma habilidade única. Aprenda a contra-jogar!',
    'Gates abrem quando o timer acaba. Corra para escapar!',
    'Vault pallets caídas apertando ação quando estiver perto.',
    'O Killer pode destruir pallets ou pular por cima delas.'
];

function showLoadingScreen(callback) {
    let loadingEl = document.getElementById('loading-screen');
    if (!loadingEl) { callback(); return; }
    
    // Set tip text
    document.getElementById('loading-tip').textContent = GAME_TIPS[Math.floor(Math.random() * GAME_TIPS.length)];
    
    // Show
    loadingEl.style.display = 'flex';
    
    // Draw pixel art logo (DBD-style 4 claw marks)
    let logoCanvas = document.getElementById('loading-logo-canvas');
    if (logoCanvas) {
        let c = logoCanvas.getContext('2d');
        let W = logoCanvas.width, H = logoCanvas.height;
        c.clearRect(0, 0, W, H);
        
        // Draw 4 vertical claw marks with dripping effect
        let clawData = [
            { x: 100, h: 180, lean: -3, thick: 18 },
            { x: 155, h: 200, lean: -1, thick: 20 },
            { x: 215, h: 210, lean: 1, thick: 20 },
            { x: 275, h: 190, lean: 3, thick: 18 }
        ];
        
        let baseY = 40;
        let PX = 2;
        
        // Horizontal slash across (the big horizontal mark)
        let slashY = baseY + 90;
        c.fillStyle = '#ffffff';
        c.fillRect(30, slashY, 340, 14);
        c.fillStyle = '#eee';
        c.fillRect(28, slashY + 2, 344, 10);
        c.fillStyle = '#ddd';
        c.fillRect(32, slashY + 4, 336, 6);
        // Slash taper ends
        c.fillStyle = '#fff';
        c.fillRect(20, slashY + 3, 12, 8);
        c.fillRect(368, slashY + 4, 10, 6);
        // Slash drip on left
        c.fillRect(22, slashY + 10, 4, 8);
        c.fillRect(24, slashY + 16, 3, 6);
        c.fillRect(25, slashY + 20, 2, 4);
        // Splash dots on left
        c.fillRect(12, slashY + 4, 4, 4);
        c.fillRect(8, slashY + 8, 3, 3);
        c.fillRect(14, slashY + 12, 3, 3);
        
        // Draw each claw mark (vertical)
        for (let cl of clawData) {
            let cx = cl.x;
            let ch = cl.h;
            let lean = cl.lean;
            let thick = cl.thick;
            
            // Main claw body
            c.fillStyle = '#ffffff';
            for (let row = 0; row < ch; row += PX) {
                let offset = Math.floor(row * lean / ch);
                let w = thick - Math.floor(Math.abs(row - ch/2) / ch * 6);
                c.fillRect(cx + offset - w/2, baseY + row, w, PX);
            }
            
            // Lighter inner highlight
            c.fillStyle = '#eeeeee';
            for (let row = 10; row < ch - 20; row += PX) {
                let offset = Math.floor(row * lean / ch);
                let w = thick * 0.5;
                c.fillRect(cx + offset - w/2, baseY + row, w, PX);
            }
            
            // Top - skull/knob shape (rounded top of claw)
            c.fillStyle = '#ffffff';
            let topOff = Math.floor(0 * lean / ch);
            c.fillRect(cx + topOff - thick/2 - 2, baseY - 6, thick + 4, 10);
            c.fillRect(cx + topOff - thick/2 + 2, baseY - 10, thick - 4, 6);
            // Skull eye sockets (dark pits)
            c.fillStyle = '#000';
            c.fillRect(cx + topOff - 4, baseY - 4, 3, 4);
            c.fillRect(cx + topOff + 2, baseY - 4, 3, 4);
            // Skull nose
            c.fillRect(cx + topOff - 1, baseY, 2, 3);
            
            // Bottom drips
            c.fillStyle = '#ffffff';
            let botY = baseY + ch;
            // Main drip
            c.fillRect(cx + lean - 2, botY, 4, 12);
            c.fillRect(cx + lean - 1, botY + 10, 3, 8);
            c.fillRect(cx + lean, botY + 16, 2, 10);
            c.fillRect(cx + lean, botY + 24, 1, 6);
            // Side drip
            c.fillRect(cx + lean - 6, botY - 4, 2, 8);
            c.fillRect(cx + lean - 5, botY + 3, 2, 5);
            c.fillRect(cx + lean + 5, botY - 2, 2, 6);
            c.fillRect(cx + lean + 5, botY + 3, 1, 4);
        }
        
        // Subtle glow effect around the marks (very faint)
        c.fillStyle = 'rgba(255,255,255,0.03)';
        c.fillRect(60, baseY - 20, 280, 260);
    }
    
    // Animate loading bar
    let bar = document.getElementById('loading-bar');
    let progress = 0;
    let loadInterval = setInterval(() => {
        progress += 2;
        bar.style.width = progress + '%';
        if (progress >= 100) {
            clearInterval(loadInterval);
            setTimeout(() => {
                loadingEl.style.display = 'none';
                callback();
            }, 300);
        }
    }, 50);
}

function updateHUD() {
    const hud = document.getElementById('hud');
    let html = '';
    // Generator counter
    html += `<div class="hud-player" style="border-color:#ffaa00;color:#ffcc00;">⚡ ${gensCompleted}/${GENS_TO_POWER} Geradores</div>`;
    for (let p of players) {
        let cls = p.role === 'killer' ? 'killer' : '';
        if (!p.alive && !p.dying) cls += ' dead';
        let status = p.escaped ? '🏃 Escapou' : p.dying ? '💀 Morrendo' : p.hookState > 0 ? '🪝 Enganchado' : p.injured ? '🩸 Ferido' : '♥ Saudável';
        if (!p.alive && !p.dying) status = '☠ Morto';
        let itemStr = '';
        if (p.heldItem === 'medkit') itemStr = ' 🩹';
        else if (p.heldItem === 'flashlight') itemStr = ' 🔦';
        html += `<div class="hud-player ${cls}">J${p.id + 1} ${p.charData.name}: ${status}${itemStr}</div>`;
    }
    hud.innerHTML = html;
}

// Online helpers
function sendInput() {
    if (peerConnections.length === 0 || myPlayerId === null || gameState !== GAME_STATES.PLAYING) return;
    if (gameTimer % 3 !== 0) return; // Every 3 frames = 20 times/sec (less bandwidth)
    // Read any common input method: WASD, Arrows, or Touch
    let up = keys['KeyW'] || keys['ArrowUp'] || keys['_touchUp'] || false;
    let down = keys['KeyS'] || keys['ArrowDown'] || keys['_touchDown'] || false;
    let left = keys['KeyA'] || keys['ArrowLeft'] || keys['_touchLeft'] || false;
    let right = keys['KeyD'] || keys['ArrowRight'] || keys['_touchRight'] || false;
    let action = keys['KeyE'] || keys['Space'] || keys['Numpad0'] || keys['_touchAction'] || false;
    let ability = keys['KeyQ'] || keys['ShiftLeft'] || keys['NumpadDecimal'] || keys['_touchAbility'] || false;
    const k = (up?1:0)|(down?2:0)|(left?4:0)|(right?8:0)|(action?16:0)|(ability?32:0);
    const msg = `{"type":"input","id":${myPlayerId},"k":${k}}`;
    for (let conn of peerConnections) { if (conn.open) conn.send(msg); }
}

function broadcastGameState() {
    if (!isHost || peerConnections.length === 0) return;
    let pData = '[';
    for (let i = 0; i < players.length; i++) {
        let p = players[i];
        let flags = (p.alive?1:0)|(p.injured?2:0)|(p.dying?4:0)|(p.carried?8:0)|(p.escaped?16:0)|(p.attacking?32:0)|(p.stealthActive?64:0)|(p.inLocker?128:0)|((p.speedBoost>0)?256:0)|((p.stunned>0)?512:0)|((p.abilityActive>0)?1024:0)|(p.isRunning?2048:0)|((p._searchProgress>0)?4096:0);
        if (i > 0) pData += ',';
        pData += `[${Math.round(p.x)},${Math.round(p.y)},${flags},${p.facing},${p.animFrame},${p.hookState},${p.carrying?p.carrying.id:-1},${Math.round(p.wiggleProgress)},${p.hookCount},${Math.round(p.health*10)/10}]`;
    }
    pData += ']';
    
    // Build object state (pallets, doors, gens, hooks) - send every broadcast
    // Pallets: [dropped, broken] per pallet
    let palStr = '[';
    for (let i = 0; i < pallets.length; i++) { if (i>0) palStr += ','; palStr += `[${pallets[i].dropped?1:0},${pallets[i].broken?1:0}]`; }
    palStr += ']';
    // Doors: [closed, broken]
    let doorStr = '[';
    for (let i = 0; i < doors.length; i++) { if (i>0) doorStr += ','; doorStr += `[${doors[i].closed?1:0},${doors[i].broken?1:0}]`; }
    doorStr += ']';
    // Generators: [progress, completed]
    let genStr = '[';
    for (let i = 0; i < generators.length; i++) { if (i>0) genStr += ','; genStr += `[${Math.round(generators[i].progress)},${generators[i].completed?1:0}]`; }
    genStr += ']';
    // Hooks: [broken, occupied_id]
    let hookStr = '[';
    for (let i = 0; i < hooks.length; i++) { if (i>0) hookStr += ','; hookStr += `[${hooks[i].broken?1:0},${hooks[i].occupied?hooks[i].occupied.id:-1}]`; }
    hookStr += ']';
    
    // Send recent scratch marks (only last few, compact)
    let smStr = '[';
    let recentSM = scratchMarks.filter(s => s.life > s.maxLife - 20); // only fresh ones
    for (let i = 0; i < Math.min(recentSM.length, 8); i++) { if (i>0) smStr += ','; smStr += `[${Math.round(recentSM[i].x)},${Math.round(recentSM[i].y)}]`; }
    smStr += ']';
    
    const msg = `{"type":"s","p":${pData},"g":${gatesOpen?1:0},"t":${matchTimeRemaining},"pal":${palStr},"dor":${doorStr},"gen":${genStr},"hk":${hookStr},"gc":${gensCompleted},"sm":${smStr}}`;
    for (let conn of peerConnections) { if (conn.open) conn.send(msg); }
}

function updateFromServer(state) {
    if (!state || gameState !== GAME_STATES.PLAYING) return;
    let pArr = state.p || state.players; if (!pArr) return;
    for (let i = 0; i < pArr.length && i < players.length; i++) {
        let sp = pArr[i];
        let prevAlive = players[i].alive;
        let prevInjured = players[i].injured;
        let prevDying = players[i].dying;
        let prevHookState = players[i].hookState;
        let prevCarried = players[i].carried;
        let prevAttacking = players[i].attacking;
        
        if (Array.isArray(sp)) {
            // Compact: [x, y, flags, facing, animFrame, hookState, carryId, wiggle, hookCount, health]
            let newX = sp[0], newY = sp[1];
            if (players[i]._targetX === undefined || Math.abs(newX - players[i].x) > TILE * 4) {
                players[i].x = newX; players[i].y = newY;
            }
            players[i]._targetX = newX; players[i]._targetY = newY;
            
            let f = sp[2];
            players[i].alive = !!(f & 1); players[i].injured = !!(f & 2); players[i].dying = !!(f & 4);
            players[i].carried = !!(f & 8); players[i].escaped = !!(f & 16); players[i].attacking = !!(f & 32);
            players[i].stealthActive = !!(f & 64); players[i].inLocker = !!(f & 128);
            players[i].speedBoost = (f & 256) ? 1 : 0; players[i].stunned = (f & 512) ? 1 : 0;
            players[i].abilityActive = (f & 1024) ? 1 : 0;
            players[i].isRunning = !!(f & 2048);
            players[i]._searchProgress = (f & 4096) ? 30 : 0; // show searching indicator
            players[i].facing = sp[3]; players[i].animFrame = sp[4]; players[i].hookState = sp[5];
            let carryId = sp[6]; players[i].carrying = carryId >= 0 ? players[carryId] : null;
            players[i].wiggleProgress = sp[7]; players[i].hookCount = sp[8];
            if (sp[9] !== undefined) players[i].health = sp[9];
        } else {
            // Legacy object format
            let newX = sp.x !== undefined ? sp.x : players[i].x;
            let newY = sp.y !== undefined ? sp.y : players[i].y;
            if (players[i]._targetX === undefined || Math.abs(newX - players[i].x) > TILE * 4) {
                players[i].x = newX; players[i].y = newY;
            }
            players[i]._targetX = newX; players[i]._targetY = newY;
            
            if (sp.h !== undefined) players[i].health = sp.h;
            players[i].alive = sp.a !== undefined ? !!sp.a : players[i].alive;
            players[i].injured = sp.i !== undefined ? !!sp.i : players[i].injured;
            players[i].dying = sp.d !== undefined ? !!sp.d : players[i].dying;
            players[i].hookState = sp.hs !== undefined ? sp.hs : players[i].hookState;
            players[i].carried = sp.c !== undefined ? !!sp.c : players[i].carried;
            players[i].escaped = sp.e !== undefined ? !!sp.e : players[i].escaped;
            players[i].attacking = sp.at !== undefined ? !!sp.at : players[i].attacking;
            players[i].stealthActive = sp.st !== undefined ? !!sp.st : players[i].stealthActive;
            players[i].facing = sp.f !== undefined ? sp.f : players[i].facing;
            players[i].animFrame = sp.af !== undefined ? sp.af : players[i].animFrame;
            players[i].inLocker = sp.il !== undefined ? !!sp.il : players[i].inLocker;
            players[i].speedBoost = sp.sb !== undefined ? (sp.sb ? 1 : 0) : players[i].speedBoost;
            players[i].stunned = sp.sn !== undefined ? (sp.sn ? 1 : 0) : players[i].stunned;
            let carryId = sp.ci !== undefined ? sp.ci : -1;
            players[i].carrying = carryId >= 0 ? players[carryId] : null;
            players[i].wiggleProgress = sp.wp || 0;
            players[i].hookCount = sp.hc || 0;
            players[i].abilityActive = sp.aa ? 1 : 0;
        }
        
        // Detect state transitions and spawn local animations on client
        let p = players[i];
        let px2 = p._targetX || p.x, py2 = p._targetY || p.y;
        // Got injured — spawn blood
        if (p.injured && !prevInjured && typeof spawnBlood === 'function') { spawnBlood(px2, py2, 6); }
        // Got downed — blood pool
        if (p.dying && !prevDying && typeof spawnBlood === 'function') { spawnBlood(px2, py2, 10); }
        // Got hooked
        if (p.hookState > 0 && prevHookState === 0 && typeof spawnParticle === 'function') { 
            for (let j = 0; j < 4; j++) spawnParticle(px2 + (Math.random()-0.5)*10, py2 - 10, '#ff440044', 20, (Math.random()-0.5)*2, -1, 2); 
        }
        // Died/sacrificed
        if (!p.alive && prevAlive && typeof spawnBlood === 'function') { spawnBlood(px2, py2, 15); }
        // Attack swing visual
        if (p.attacking && !prevAttacking && typeof spawnParticle === 'function') {
            let ax = px2, ay = py2;
            switch(p.facing) { case 0: ay += 20; break; case 1: ay -= 20; break; case 2: ax -= 20; break; case 3: ax += 20; break; }
            spawnParticle(ax, ay, p.charData?.weaponColor || '#888', 12, 0, 0, 4);
        }
    }
    if (state.g !== undefined) { 
        let wasOpen = gatesOpen;
        gatesOpen = !!state.g;
        if (gatesOpen && !wasOpen) { for (let g of exitGates) g.open = true; }
    }
    if (state.t !== undefined) matchTimeRemaining = state.t;
    
    // Sync object states (pallets, doors, generators, hooks)
    if (state.pal && pallets.length === state.pal.length) {
        for (let i = 0; i < state.pal.length; i++) {
            pallets[i].dropped = !!state.pal[i][0];
            pallets[i].broken = !!state.pal[i][1];
        }
    }
    if (state.dor && doors.length === state.dor.length) {
        for (let i = 0; i < state.dor.length; i++) {
            doors[i].closed = !!state.dor[i][0];
            doors[i].broken = !!state.dor[i][1];
        }
    }
    if (state.gen && generators.length === state.gen.length) {
        for (let i = 0; i < state.gen.length; i++) {
            generators[i].progress = state.gen[i][0];
            generators[i].completed = !!state.gen[i][1];
        }
    }
    if (state.hk && hooks.length === state.hk.length) {
        for (let i = 0; i < state.hk.length; i++) {
            hooks[i].broken = !!state.hk[i][0];
            let occId = state.hk[i][1];
            hooks[i].occupied = occId >= 0 ? players[occId] : null;
        }
    }
    if (state.gc !== undefined) gensCompleted = state.gc;
    // Sync scratch marks from host
    if (state.sm && state.sm.length > 0) {
        for (let sm of state.sm) {
            // Only add if not already near this position
            let exists = scratchMarks.some(s => Math.abs(s.x - sm[0]) < 4 && Math.abs(s.y - sm[1]) < 4 && s.life > 160);
            if (!exists) {
                scratchMarks.push({ x: sm[0], y: sm[1], life: 180, maxLife: 180 });
            }
        }
    }
}

function applyRemoteInput(data) {
    if (!isHost) return;
    let id = data.id;
    let p = players[id]; if (!p) return;
    let c = p.controls;
    
    if (data.k !== undefined) {
        // Compact bitfield: bit0=up, bit1=down, bit2=left, bit3=right, bit4=action, bit5=ability
        let k = data.k;
        let newUp = !!(k & 1), newDown = !!(k & 2), newLeft = !!(k & 4), newRight = !!(k & 8);
        let newAction = !!(k & 16), newAbility = !!(k & 32);
        
        // Detect just-pressed for action/ability
        if (newAction && !keys[c.action]) keysJustPressed[c.action] = true;
        if (newAbility && !keys[c.ability]) keysJustPressed[c.ability] = true;
        
        // Map to this player's control scheme keys
        keys[c.up] = newUp;
        keys[c.down] = newDown;
        keys[c.left] = newLeft;
        keys[c.right] = newRight;
        keys[c.action] = newAction;
        keys[c.ability] = newAbility;
    } else if (data.keys) {
        // Legacy format
        if (data.keys.action && !keys[c.action]) keysJustPressed[c.action] = true;
        if (data.keys.ability && !keys[c.ability]) keysJustPressed[c.ability] = true;
        keys[c.up] = data.keys.up;
        keys[c.down] = data.keys.down;
        keys[c.left] = data.keys.left;
        keys[c.right] = data.keys.right;
        keys[c.action] = data.keys.action;
        keys[c.ability] = data.keys.ability;
    }
}


// ============================================================
// RENDERING
// ============================================================
function render() {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    if (gameState !== GAME_STATES.PLAYING && gameState !== GAME_STATES.ENDED) return;
    
    drawMapEnhanced();
    drawBloodPools();
    drawScratchMarks();
    for (let trap of traps) if (trap.active) drawTrap(trap);
    for (let gate of exitGates) drawExitGate(gate);
    for (let pal of pallets) drawPallet(pal);
    for (let locker of lockers) drawLocker(locker);
    for (let hook of hooks) drawHook(hook);
    for (let gen of generators) drawGenerator(gen);
    for (let chest of chests) drawChest(chest);
    for (let door of doors) drawDoor(door);
    drawFog();
    drawTerrorRadiusOnMap();
    
    for (let p of players) {
        if (p.carried || p.escaped || (!p.alive && !p.dying) || p.inLocker) continue;
        if (p.stealthActive && p.role === 'killer') ctx.globalAlpha = 0.6;
        drawPlayerSprite(p);
        ctx.globalAlpha = 1.0;
    }
    
    for (let p of players) { if (p.role === 'survivor' && p.carried && p.wiggleProgress > 0) drawWiggleBar(p); }
    // Revive progress bar (shown on the player doing the reviving)
    for (let p of players) { if (p._reviveProgress > 0 && p.role === 'survivor') { let ratio = p._reviveProgress / 60; ctx.fillStyle = '#002200'; ctx.fillRect(p.x - 12, p.y - 28, 24, 4); ctx.fillStyle = '#44ff44'; ctx.fillRect(p.x - 12, p.y - 28, 24 * ratio, 4); ctx.fillStyle = '#ffffff44'; ctx.fillRect(p.x - 12, p.y - 28, 24 * ratio, 1); } }
    // Unhook progress bar
    for (let p of players) { if (p._unhookProgress > 0 && p.role === 'survivor') { let ratio = p._unhookProgress / 60; ctx.fillStyle = '#222200'; ctx.fillRect(p.x - 12, p.y - 28, 24, 4); ctx.fillStyle = '#ffaa00'; ctx.fillRect(p.x - 12, p.y - 28, 24 * ratio, 4); } }
    // Search progress bar
    for (let p of players) { if (p._searchProgress > 0 && p.role === 'survivor') { let ratio = p._searchProgress / 60; ctx.fillStyle = '#1a1a00'; ctx.fillRect(p.x - 12, p.y - 28, 24, 4); ctx.fillStyle = '#ffcc00'; ctx.fillRect(p.x - 12, p.y - 28, 24 * ratio, 4); } }
    drawParticles();
    drawAuras();
    drawVignette();
    drawSurvivorDarkness();
    drawGeneratorHUD();
    drawGameInfo();
}

function drawSurvivorDarkness() {
    if (!onlineMode) return;
    let myPlayer = players[myPlayerId];
    if (!myPlayer || !myPlayer.alive) return;
    if (myPlayer.role === 'survivor') return;
    
    // KILLER: tudo 100% preto, apenas o raio de terror é visível
    let px = myPlayer.x, py = myPlayer.y;
    let viewRadius = TILE * 4;
    
    ctx.save();
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.rect(0, 0, VIEW_W, VIEW_H);
    ctx.arc(px, py, viewRadius, 0, Math.PI * 2, true);
    ctx.fill();
    ctx.restore();
    
    // Draw a red circle border showing the terror radius edge
    ctx.save();
    ctx.strokeStyle = 'rgba(255,0,0,0.3)';
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    ctx.arc(px, py, viewRadius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
}

function drawGeneratorHUD() {
    // Global generator status panel (top-right corner, visible to all players)
    if (!generators || generators.length === 0) return;
    let panelX = VIEW_W - 110;
    let panelY = 8;
    let barW = 80;
    let barH = 6;
    let gap = 12;
    
    // Panel background
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    ctx.fillRect(panelX - 8, panelY - 4, barW + 24, generators.length * gap + 20);
    ctx.fillStyle = '#333';
    ctx.fillRect(panelX - 8, panelY - 4, barW + 24, 1);
    
    // Title
    ctx.fillStyle = '#ffcc00';
    ctx.font = 'bold 8px monospace';
    ctx.fillText(`⚡ ${gensCompleted}/${GENS_TO_POWER}`, panelX, panelY + 6);
    
    panelY += 14;
    
    for (let i = 0; i < generators.length; i++) {
        let gen = generators[i];
        let by = panelY + i * gap;
        
        // Bar background
        ctx.fillStyle = '#111';
        ctx.fillRect(panelX, by, barW, barH);
        ctx.fillStyle = '#1a1a1a';
        ctx.fillRect(panelX + 1, by + 1, barW - 2, barH - 2);
        
        // Fill
        let ratio = gen.progress / 100;
        if (gen.completed) {
            ctx.fillStyle = '#44ff44';
            ctx.fillRect(panelX + 1, by + 1, barW - 2, barH - 2);
        } else if (ratio > 0) {
            let col = ratio > 0.7 ? '#44cc44' : ratio > 0.3 ? '#ccaa00' : '#cc4400';
            ctx.fillRect(panelX + 1, by + 1, Math.floor((barW - 2) * ratio), barH - 2);
            ctx.fillStyle = col;
            ctx.fillRect(panelX + 1, by + 1, Math.floor((barW - 2) * ratio), barH - 2);
        }
        
        // Percentage text
        ctx.fillStyle = gen.completed ? '#44ff44' : '#aaa';
        ctx.font = '7px monospace';
        ctx.fillText(gen.completed ? '✓' : `${Math.floor(gen.progress)}%`, panelX + barW + 3, by + barH - 1);
        
        // Sparking indicator
        if (gen.sparking) {
            ctx.fillStyle = '#ff4400';
            ctx.fillRect(panelX - 4, by + 1, 3, barH - 2);
        }
    }
}

function drawMapEnhanced() {
    const mapColors = MAPS[currentMapKey];
    for (let y = 0; y < currentMap.height; y++) {
        for (let x = 0; x < currentMap.width; x++) {
            let tile = currentMap.grid[y][x], px = x * TILE, py = y * TILE;
            if (tile === 1) {
                // Wall - detailed pixel art brickwork
                ctx.fillStyle = mapColors.wallColor; ctx.fillRect(px, py, TILE, TILE);
                // Top edge (lighter - light source from above)
                ctx.fillStyle = mapColors.accentColor; ctx.fillRect(px, py, TILE, 2);
                // Bottom shadow
                ctx.fillStyle = '#00000077'; ctx.fillRect(px, py+TILE-2, TILE, 2);
                // Right shadow edge
                ctx.fillStyle = '#00000033'; ctx.fillRect(px+TILE-2, py, 2, TILE);
                // Left highlight edge
                ctx.fillStyle = '#ffffff06'; ctx.fillRect(px, py, 1, TILE);
                
                let seed = (x * 7 + y * 13) % 17;
                if (seed < 5) {
                    // Detailed brick pattern
                    ctx.fillStyle = '#ffffff06';
                    // Row 1 bricks
                    ctx.fillRect(px+1, py+3, 12, 5); ctx.fillRect(px+14, py+3, 13, 5);
                    // Row 2 bricks (offset)
                    ctx.fillRect(px+1, py+10, 7, 5); ctx.fillRect(px+9, py+10, 11, 5); ctx.fillRect(px+21, py+10, 7, 5);
                    // Row 3 bricks
                    ctx.fillRect(px+1, py+17, 13, 5); ctx.fillRect(px+15, py+17, 12, 5);
                    // Mortar lines (dark gaps between bricks)
                    ctx.fillStyle = '#00000022';
                    ctx.fillRect(px, py+8, TILE, 1); ctx.fillRect(px, py+15, TILE, 1); ctx.fillRect(px, py+22, TILE, 1);
                    ctx.fillRect(px+13, py+3, 1, 5); ctx.fillRect(px+8, py+10, 1, 5); ctx.fillRect(px+20, py+10, 1, 5);
                    ctx.fillRect(px+14, py+17, 1, 5);
                } else if (seed >= 5 && seed < 9) {
                    // Stone block pattern
                    ctx.fillStyle = '#ffffff04';
                    ctx.fillRect(px+2, py+2, TILE-4, TILE-4);
                    ctx.fillStyle = '#ffffff06';
                    ctx.fillRect(px+2, py+2, TILE-4, 1); // top highlight of stone
                    ctx.fillStyle = '#00000015';
                    ctx.fillRect(px+2, py+TILE-4, TILE-4, 1); // bottom shadow
                    ctx.fillRect(px+TILE/2, py+2, 1, TILE-4); // center crack
                    // Stone texture dots
                    ctx.fillStyle = '#ffffff03';
                    ctx.fillRect(px+5, py+6, 2, 1); ctx.fillRect(px+14, py+10, 2, 1); ctx.fillRect(px+8, py+18, 2, 1); ctx.fillRect(px+20, py+14, 1, 2);
                } else if (seed === 9 || seed === 10) {
                    // Damaged/cracked wall
                    ctx.fillStyle = '#ffffff05';
                    ctx.fillRect(px+1, py+3, 12, 5); ctx.fillRect(px+14, py+3, 13, 5);
                    ctx.fillRect(px+1, py+10, 7, 5); ctx.fillRect(px+9, py+10, 11, 5);
                    // Cracks
                    ctx.fillStyle = '#00000055';
                    ctx.fillRect(px+10, py+2, 1, 8); ctx.fillRect(px+11, py+9, 1, 6); ctx.fillRect(px+10, py+14, 1, 4);
                    ctx.fillRect(px+18, py+5, 1, 5); ctx.fillRect(px+17, py+9, 1, 7);
                    // Chipped brick
                    ctx.fillStyle = '#00000033';
                    ctx.fillRect(px+9, py+4, 3, 3);
                }
                // Moss (forest/catacombs)
                if (seed === 11 && (currentMapKey === 'forest' || currentMapKey === 'catacombs')) {
                    ctx.fillStyle = '#22882215'; ctx.fillRect(px, py+TILE-6, TILE, 4);
                    ctx.fillStyle = '#33aa3310'; ctx.fillRect(px+2, py+TILE-8, 3, 2); ctx.fillRect(px+12, py+TILE-7, 4, 2); ctx.fillRect(px+22, py+TILE-8, 3, 2);
                }
                // Rust stains (factory)
                if (seed === 14 && currentMapKey === 'factory') {
                    ctx.fillStyle = '#44220015'; ctx.fillRect(px+4, py+8, 5, 14); ctx.fillRect(px+3, py+10, 2, 10);
                }
                // Blood splatter (hospital/asylum)
                if (seed === 15 && (currentMapKey === 'hospital' || currentMapKey === 'asylum')) {
                    ctx.fillStyle = '#33000012'; ctx.fillRect(px+8, py+5, 3, 8); ctx.fillRect(px+7, py+8, 2, 3); ctx.fillRect(px+10, py+4, 1, 3);
                }
            } else if (tile === 8) {
                // Door tile - pixel art floor with threshold
                ctx.fillStyle = mapColors.floorColor; ctx.fillRect(px, py, TILE, TILE);
                // Stone threshold (pixel art flagstones)
                ctx.fillStyle = '#44332215'; ctx.fillRect(px, py, TILE, 3); ctx.fillRect(px, py+TILE-3, TILE, 3);
                ctx.fillStyle = '#55443318'; ctx.fillRect(px+2, py, 5, 2); ctx.fillRect(px+8, py, 6, 2); ctx.fillRect(px+15, py, 5, 2); ctx.fillRect(px+21, py, 5, 2);
            } else {
                // Floor - detailed pixel art tile/stone floor
                ctx.fillStyle = mapColors.floorColor; ctx.fillRect(px, py, TILE, TILE);
                // Alternate tile brightness for checkerboard effect
                if ((x + y) % 2 === 0) { ctx.fillStyle = '#ffffff02'; ctx.fillRect(px, py, TILE, TILE); }
                // Tile edge lines (subtle grid)
                ctx.fillStyle = '#ffffff04'; ctx.fillRect(px, py, TILE, 1); ctx.fillRect(px, py, 1, TILE);
                ctx.fillStyle = '#00000008'; ctx.fillRect(px+TILE-1, py, 1, TILE); ctx.fillRect(px, py+TILE-1, TILE, 1);
                
                let fseed = (x * 11 + y * 3) % 31;
                // Floor tiles pattern (pixel art detailed stones)
                if (fseed < 3) {
                    // Floor crack pattern
                    ctx.fillStyle = '#00000018';
                    ctx.fillRect(px+6, py+12, 1, 8); ctx.fillRect(px+7, py+19, 6, 1);
                    ctx.fillRect(px+14, py+8, 1, 5); ctx.fillRect(px+15, py+12, 4, 1);
                    // Small debris pixel
                    ctx.fillStyle = '#00000010'; ctx.fillRect(px+8, py+14, 2, 1);
                }
                // Blood spot (pixel art splatter)
                if (fseed === 5) {
                    ctx.fillStyle = '#22000010'; ctx.fillRect(px+12, py+12, 4, 3); ctx.fillRect(px+11, py+13, 2, 2); ctx.fillRect(px+15, py+11, 2, 2);
                    ctx.fillStyle = '#33000008'; ctx.fillRect(px+10, py+14, 1, 1); ctx.fillRect(px+16, py+10, 1, 1);
                }
                // Debris/rubble (pixel blocks)
                if (fseed === 8) {
                    ctx.fillStyle = mapColors.accentColor + '12'; ctx.fillRect(px+3, py+20, 4, 3); ctx.fillRect(px+10, py+22, 3, 2);
                    ctx.fillStyle = mapColors.accentColor + '08'; ctx.fillRect(px+5, py+19, 2, 2); ctx.fillRect(px+12, py+21, 1, 2);
                }
                // Pipe/wire on floor (factory/hospital)
                if (fseed === 12 && (currentMapKey === 'factory' || currentMapKey === 'hospital')) {
                    ctx.fillStyle = '#33333322'; ctx.fillRect(px, py+12, TILE, 2);
                    ctx.fillStyle = '#44444418'; ctx.fillRect(px, py+12, TILE, 1); // pipe highlight
                    // Pipe joints
                    ctx.fillStyle = '#44444428'; ctx.fillRect(px+6, py+11, 3, 4); ctx.fillRect(px+20, py+11, 3, 4);
                }
                // Dead leaves (forest) - pixel art leaves
                if (fseed === 15 && currentMapKey === 'forest') {
                    ctx.fillStyle = '#44330015'; ctx.fillRect(px+5, py+7, 3, 2); ctx.fillRect(px+6, py+8, 1, 1);
                    ctx.fillStyle = '#55440012'; ctx.fillRect(px+16, py+18, 3, 2); ctx.fillRect(px+17, py+19, 1, 1);
                    ctx.fillStyle = '#33220010'; ctx.fillRect(px+10, py+4, 2, 2); ctx.fillRect(px+22, py+12, 2, 2);
                }
                // Puddle (catacombs) - pixel art water
                if (fseed === 18 && currentMapKey === 'catacombs') {
                    ctx.fillStyle = '#11223310'; ctx.fillRect(px+8, py+10, 10, 8);
                    ctx.fillStyle = '#22334408'; ctx.fillRect(px+9, py+11, 8, 6);
                    // Water reflection highlight
                    ctx.fillStyle = '#ffffff06'; ctx.fillRect(px+10, py+11, 3, 1); ctx.fillRect(px+14, py+13, 2, 1);
                }
                // Tile pattern (asylum/hospital) - checkered tiles
                if (fseed === 20 && (currentMapKey === 'asylum' || currentMapKey === 'hospital')) {
                    ctx.fillStyle = '#ffffff04'; ctx.fillRect(px+2, py+2, 12, 12); ctx.fillRect(px+14, py+14, 12, 12);
                    ctx.fillStyle = '#ffffff02'; ctx.fillRect(px+2, py+14, 12, 12); ctx.fillRect(px+14, py+2, 12, 12);
                }
                // Wall cast shadow (more detailed with pixel gradient)
                if (y > 0 && currentMap.grid[y-1][x] === 1) {
                    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fillRect(px, py, TILE, 4);
                    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(px, py+4, TILE, 4);
                    ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fillRect(px, py+8, TILE, 4);
                }
                if (x > 0 && currentMap.grid[y][x-1] === 1) {
                    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(px, py, 4, TILE);
                    ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fillRect(px+4, py, 4, TILE);
                }
            }
        }
    }
}

function drawBloodPools() {
    for (let bp of bloodPools) {
        let a = bp.life / bp.maxLife;
        // Main pool
        ctx.fillStyle = `rgba(100,0,0,${a * 0.5})`;
        ctx.beginPath(); ctx.ellipse(bp.x, bp.y, bp.size * 1.2, bp.size * 0.7, 0, 0, Math.PI * 2); ctx.fill();
        // Inner darker blood
        ctx.fillStyle = `rgba(60,0,0,${a * 0.7})`;
        ctx.beginPath(); ctx.ellipse(bp.x, bp.y, bp.size * 0.7, bp.size * 0.4, 0, 0, Math.PI * 2); ctx.fill();
        // Highlight reflection
        ctx.fillStyle = `rgba(180,20,20,${a * 0.3})`;
        ctx.beginPath(); ctx.ellipse(bp.x - bp.size * 0.3, bp.y - bp.size * 0.2, bp.size * 0.3, bp.size * 0.15, 0, 0, Math.PI * 2); ctx.fill();
    }
}
function drawScratchMarks() {
    for (let sm of scratchMarks) {
        let a = sm.life / sm.maxLife;
        // Main mark
        ctx.fillStyle = `rgba(255,100,0,${a * 0.6})`;
        ctx.fillRect(sm.x - 1, sm.y - 1, 3, 3);
        // Scratch lines
        ctx.fillStyle = `rgba(255,60,0,${a * 0.4})`;
        ctx.fillRect(sm.x - 3, sm.y, 2, 1);
        ctx.fillRect(sm.x + 2, sm.y - 1, 2, 1);
        // Glow
        ctx.fillStyle = `rgba(255,120,0,${a * 0.15})`;
        ctx.beginPath(); ctx.arc(sm.x, sm.y, 4, 0, Math.PI * 2); ctx.fill();
    }
}
function drawFog() { const mapColors = MAPS[currentMapKey]; for (let f of fogParticles) { let pulse = Math.sin(gameTimer * 0.01 + f.offset) * 0.02; ctx.fillStyle = mapColors.fogColor; ctx.globalAlpha = f.alpha + pulse; ctx.beginPath(); ctx.ellipse(f.x, f.y, f.size, f.size * 0.6, 0, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1; } }
function drawVignette() { let grad = ctx.createRadialGradient(VIEW_W / 2, VIEW_H / 2, VIEW_W * 0.35, VIEW_W / 2, VIEW_H / 2, VIEW_W * 0.6); grad.addColorStop(0, 'rgba(0,0,0,0)'); grad.addColorStop(1, 'rgba(0,0,0,0.25)'); ctx.fillStyle = grad; ctx.fillRect(0, 0, VIEW_W, VIEW_H); }
function drawParticles() {
    for (let p of particles) {
        let a = p.life / p.maxLife;
        ctx.globalAlpha = a;
        ctx.fillStyle = p.color;
        // Vary particle shape based on size
        if (p.size > 4) {
            // Large particles: glow circle
            ctx.beginPath(); ctx.arc(p.x, p.y, p.size / 2, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#ffffff33'; ctx.beginPath(); ctx.arc(p.x, p.y, p.size / 4, 0, Math.PI * 2); ctx.fill();
        } else if (p.size > 2) {
            // Medium: diamond
            ctx.beginPath(); ctx.moveTo(p.x, p.y - p.size); ctx.lineTo(p.x + p.size, p.y); ctx.lineTo(p.x, p.y + p.size); ctx.lineTo(p.x - p.size, p.y); ctx.fill();
        } else {
            // Small: pixel
            ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
        }
    }
    ctx.globalAlpha = 1;
}

function drawTerrorRadiusOnMap() {
    let killer = players.find(p => p.role === 'killer');
    if (!killer || !killer.alive) return;
    let terrorRange = killer.charData.terrorRadius || 200;
    if (killer.stealthActive) terrorRange = 0;
    if (terrorRange <= 0) return;
    let scaledRadius = terrorRange * (TILE / 32);
    let pulse = Math.sin(gameTimer * 0.06) * 0.12 + 0.88;
    let grad = ctx.createRadialGradient(killer.x, killer.y, scaledRadius * 0.3, killer.x, killer.y, scaledRadius);
    grad.addColorStop(0, `rgba(255,0,0,${0.06 * pulse})`); grad.addColorStop(1, 'rgba(100,0,0,0)');
    ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(killer.x, killer.y, scaledRadius, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = `rgba(255,30,30,${0.2 * pulse})`; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.arc(killer.x, killer.y, scaledRadius, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
}

function drawAuras() { for (let p of players) { if (p.role === 'survivor' && p.revealKiller) { for (let k of players) { if (k.role === 'killer') { let pulse = Math.sin(gameTimer * 0.1) * 3; ctx.strokeStyle = '#ff000088'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(k.x, k.y, 18 + pulse, 0, Math.PI * 2); ctx.stroke(); } } } } }

function drawExitGate(gate) {
    const x = gate.x, y = gate.y;
    if (gate.open) {
        let glow = Math.sin(gameTimer * 0.08) * 0.2 + 0.8;
        let t = gameTimer * 0.04;
        // Portal energy background
        ctx.fillStyle = '#001a00'; ctx.fillRect(x, y, TILE, TILE);
        // Brick frame - pixel art style
        ctx.fillStyle = '#2a2a2a'; ctx.fillRect(x, y, TILE, 3); ctx.fillRect(x, y+TILE-3, TILE, 3);
        ctx.fillRect(x, y, 3, TILE); ctx.fillRect(x+TILE-3, y, 3, TILE);
        // Frame detail bricks
        ctx.fillStyle = '#3a3a3a'; ctx.fillRect(x+1, y+1, 4, 2); ctx.fillRect(x+6, y+1, 5, 2); ctx.fillRect(x+12, y+1, 5, 2); ctx.fillRect(x+18, y+1, 5, 2); ctx.fillRect(x+24, y+1, 3, 2);
        ctx.fillRect(x+1, y+TILE-3, 5, 2); ctx.fillRect(x+7, y+TILE-3, 5, 2); ctx.fillRect(x+13, y+TILE-3, 5, 2); ctx.fillRect(x+19, y+TILE-3, 5, 2);
        // Mortar lines
        ctx.fillStyle = '#1a1a1a'; ctx.fillRect(x+5, y, 1, 3); ctx.fillRect(x+11, y, 1, 3); ctx.fillRect(x+17, y, 1, 3); ctx.fillRect(x+23, y, 1, 3);
        // Green swirling portal inside
        ctx.fillStyle = `rgba(0,180,60,${0.4*glow})`; ctx.fillRect(x+4, y+4, TILE-8, TILE-8);
        ctx.fillStyle = `rgba(0,255,80,${0.3*glow})`; ctx.fillRect(x+6, y+6, TILE-12, TILE-12);
        // Pixel energy swirls
        ctx.fillStyle = `rgba(100,255,100,${0.7*glow})`;
        ctx.fillRect(x+8+Math.sin(t)*4, y+8+Math.cos(t)*4, 3, 3);
        ctx.fillRect(x+16+Math.cos(t+1)*3, y+12+Math.sin(t+1)*3, 2, 2);
        ctx.fillRect(x+10+Math.sin(t+2)*5, y+18+Math.cos(t+2)*3, 2, 3);
        ctx.fillStyle = `rgba(200,255,200,${0.9*glow})`;
        ctx.fillRect(x+12+Math.cos(t)*3, y+14+Math.sin(t)*2, 2, 2);
        // Arrow indicator pixel art
        ctx.fillStyle = '#00ff44';
        ctx.fillRect(x+13, y+9, 2, 10); ctx.fillRect(x+11, y+11, 2, 2); ctx.fillRect(x+15, y+11, 2, 2);
        ctx.fillRect(x+9, y+13, 2, 2); ctx.fillRect(x+17, y+13, 2, 2);
        // Corner rivets
        ctx.fillStyle = '#666'; ctx.fillRect(x+1, y+1, 2, 2); ctx.fillRect(x+TILE-3, y+1, 2, 2); ctx.fillRect(x+1, y+TILE-3, 2, 2); ctx.fillRect(x+TILE-3, y+TILE-3, 2, 2);
        // Sparkle particles
        if (gameTimer % 10 === 0) spawnParticle(x + TILE / 2 + (Math.random() - 0.5) * 20, y + TILE / 2, '#00ff0066', 30, 0, -0.5, 2);
    } else {
        // Closed gate - heavy iron pixel art
        // Dark stone background
        ctx.fillStyle = '#1a0808'; ctx.fillRect(x, y, TILE, TILE);
        ctx.fillStyle = '#2a1010'; ctx.fillRect(x+2, y+2, TILE-4, TILE-4);
        // Stone frame bricks
        ctx.fillStyle = '#3a2a2a'; ctx.fillRect(x, y, TILE, 3); ctx.fillRect(x, y+TILE-3, TILE, 3);
        ctx.fillRect(x, y, 3, TILE); ctx.fillRect(x+TILE-3, y, 3, TILE);
        ctx.fillStyle = '#4a3535'; ctx.fillRect(x+1, y+1, 5, 2); ctx.fillRect(x+7, y+1, 4, 2); ctx.fillRect(x+12, y+1, 5, 2); ctx.fillRect(x+18, y+1, 4, 2); ctx.fillRect(x+23, y+1, 4, 2);
        // Iron bars (thick pixel art)
        ctx.fillStyle = '#5a5a5a'; 
        ctx.fillRect(x+5, y+4, 3, TILE-8); ctx.fillRect(x+11, y+4, 3, TILE-8);
        ctx.fillRect(x+17, y+4, 3, TILE-8); ctx.fillRect(x+23, y+4, 3, TILE-8);
        // Bar highlights (metallic shine)
        ctx.fillStyle = '#7a7a7a'; 
        ctx.fillRect(x+5, y+4, 1, TILE-8); ctx.fillRect(x+11, y+4, 1, TILE-8);
        ctx.fillRect(x+17, y+4, 1, TILE-8); ctx.fillRect(x+23, y+4, 1, TILE-8);
        // Bar shadows
        ctx.fillStyle = '#3a3a3a'; 
        ctx.fillRect(x+7, y+4, 1, TILE-8); ctx.fillRect(x+13, y+4, 1, TILE-8);
        ctx.fillRect(x+19, y+4, 1, TILE-8); ctx.fillRect(x+25, y+4, 1, TILE-8);
        // Cross bars with rivets
        ctx.fillStyle = '#5a5a5a'; ctx.fillRect(x+4, y+8, TILE-8, 3); ctx.fillRect(x+4, y+17, TILE-8, 3);
        ctx.fillStyle = '#7a7a7a'; ctx.fillRect(x+4, y+8, TILE-8, 1); ctx.fillRect(x+4, y+17, TILE-8, 1);
        // Rivets at intersections
        ctx.fillStyle = '#888'; ctx.fillRect(x+5, y+9, 2, 2); ctx.fillRect(x+11, y+9, 2, 2); ctx.fillRect(x+17, y+9, 2, 2); ctx.fillRect(x+23, y+9, 2, 2);
        ctx.fillRect(x+5, y+18, 2, 2); ctx.fillRect(x+11, y+18, 2, 2); ctx.fillRect(x+17, y+18, 2, 2); ctx.fillRect(x+23, y+18, 2, 2);
        // Central lock mechanism
        ctx.fillStyle = '#444'; ctx.fillRect(x+11, y+11, 6, 7);
        ctx.fillStyle = '#555'; ctx.fillRect(x+12, y+12, 4, 5);
        ctx.fillStyle = '#333'; ctx.fillRect(x+12, y+10, 4, 2); // lock top arch
        // Keyhole
        ctx.fillStyle = '#111'; ctx.fillRect(x+13, y+13, 2, 2); ctx.fillRect(x+13, y+15, 2, 1);
        // Red warning indicator (pulsing)
        let rp = Math.sin(gameTimer*0.06)*0.3+0.7;
        ctx.fillStyle = `rgba(255,0,0,${rp})`; ctx.fillRect(x+13, y+11, 2, 1);
        // Corner brackets
        ctx.fillStyle = '#666'; ctx.fillRect(x+1, y+1, 3, 2); ctx.fillRect(x+1, y+1, 2, 3);
        ctx.fillRect(x+TILE-4, y+1, 3, 2); ctx.fillRect(x+TILE-3, y+1, 2, 3);
        ctx.fillRect(x+1, y+TILE-3, 3, 2); ctx.fillRect(x+1, y+TILE-3, 2, 3);
        ctx.fillRect(x+TILE-4, y+TILE-3, 3, 2); ctx.fillRect(x+TILE-3, y+TILE-4, 2, 3);
    }
}

function drawPallet(pal) {
    const x = pal.x, y = pal.y;
    // Broken debris - pixel art splinters
    if (pal.broken) {
        let breakFade = pal.breakAnim || 0;
        if (breakFade > 0) { pal.breakAnim--; ctx.fillStyle = '#ffaa0015'; ctx.fillRect(x, y, TILE, TILE); }
        // Scattered pixel wood splinters
        ctx.fillStyle = '#5a3818'; ctx.fillRect(x+3, y+14, 5, 3); ctx.fillRect(x+18, y+11, 4, 3);
        ctx.fillStyle = '#7a4a20'; ctx.fillRect(x+9, y+17, 6, 2); ctx.fillRect(x+20, y+16, 3, 2);
        ctx.fillStyle = '#3a2008'; ctx.fillRect(x+14, y+9, 3, 2); ctx.fillRect(x+5, y+20, 4, 2);
        ctx.fillStyle = '#4a2810'; ctx.fillRect(x+7, y+12, 2, 4); ctx.fillRect(x+22, y+19, 3, 2);
        // Nails scattered
        ctx.fillStyle = '#888'; ctx.fillRect(x+6, y+15, 1, 2); ctx.fillRect(x+16, y+13, 1, 2); ctx.fillRect(x+24, y+18, 1, 1);
        // Sawdust particles
        ctx.fillStyle = '#8a6a3022'; ctx.fillRect(x+4, y+18, 8, 2); ctx.fillRect(x+15, y+20, 6, 2);
        return;
    }
    if (pal.dropped) {
        // Fallen pallet - detailed pixel art wooden plank
        let anim = pal.dropAnim || 0;
        if (anim > 0) { pal.dropAnim--; }
        let tilt = anim * 2;
        // Drop shadow
        ctx.fillStyle = '#00000044'; ctx.fillRect(x+2, y+20, TILE-4, 3);
        // Main plank body
        ctx.fillStyle = '#5a3010'; ctx.fillRect(x+1, y+9-tilt, TILE-2, 10);
        // Top face (lighter - shows depth)
        ctx.fillStyle = '#7a5028'; ctx.fillRect(x+2, y+9-tilt, TILE-4, 2);
        // Wood plank surface
        ctx.fillStyle = '#6a4220'; ctx.fillRect(x+2, y+11-tilt, TILE-4, 7);
        // Individual plank boards (pixel lines)
        ctx.fillStyle = '#8a5a30'; ctx.fillRect(x+2, y+11-tilt, 5, 6); ctx.fillRect(x+8, y+11-tilt, 6, 6); ctx.fillRect(x+15, y+11-tilt, 5, 6); ctx.fillRect(x+21, y+11-tilt, 5, 6);
        // Gaps between boards
        ctx.fillStyle = '#3a1a08'; ctx.fillRect(x+7, y+10-tilt, 1, 8); ctx.fillRect(x+14, y+10-tilt, 1, 8); ctx.fillRect(x+20, y+10-tilt, 1, 8);
        // Wood grain detail
        ctx.fillStyle = '#4a2808'; ctx.fillRect(x+3, y+13-tilt, 3, 1); ctx.fillRect(x+9, y+12-tilt, 4, 1); ctx.fillRect(x+16, y+14-tilt, 3, 1); ctx.fillRect(x+22, y+12-tilt, 3, 1);
        ctx.fillRect(x+4, y+16-tilt, 2, 1); ctx.fillRect(x+11, y+15-tilt, 2, 1); ctx.fillRect(x+17, y+16-tilt, 3, 1); ctx.fillRect(x+23, y+15-tilt, 2, 1);
        // Nails (shiny pixel dots)
        ctx.fillStyle = '#bbb'; ctx.fillRect(x+3, y+12-tilt, 1, 1); ctx.fillRect(x+TILE-4, y+12-tilt, 1, 1);
        ctx.fillRect(x+3, y+16-tilt, 1, 1); ctx.fillRect(x+TILE-4, y+16-tilt, 1, 1);
        // Metal end bands
        ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x+1, y+10-tilt, 2, 8); ctx.fillRect(x+TILE-3, y+10-tilt, 2, 8);
        ctx.fillStyle = '#5a5a5a'; ctx.fillRect(x+1, y+10-tilt, 1, 8); ctx.fillRect(x+TILE-3, y+10-tilt, 1, 8);
    } else {
        // Standing pallet - upright pixel art wooden structure
        // Subtle interaction highlight
        ctx.fillStyle = '#ffff0006'; ctx.fillRect(x+4, y+4, TILE-8, TILE-8);
        // Base support (stone block)
        ctx.fillStyle = '#3a3a3a'; ctx.fillRect(x+6, y+TILE-5, 16, 5);
        ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x+7, y+TILE-5, 14, 2);
        ctx.fillStyle = '#2a2a2a'; ctx.fillRect(x+7, y+TILE-2, 14, 2);
        // Vertical wooden beam - main structure
        ctx.fillStyle = '#5a3010'; ctx.fillRect(x+9, y+1, 10, TILE-5);
        // Individual vertical planks
        ctx.fillStyle = '#7a5028'; ctx.fillRect(x+10, y+2, 3, TILE-7);
        ctx.fillStyle = '#6a4220'; ctx.fillRect(x+14, y+2, 3, TILE-7);
        ctx.fillStyle = '#8a5a30'; ctx.fillRect(x+12, y+3, 2, TILE-8);
        // Plank gaps
        ctx.fillStyle = '#3a1a08'; ctx.fillRect(x+13, y+1, 1, TILE-5); ctx.fillRect(x+17, y+1, 1, TILE-5);
        // Wood grain (horizontal lines)
        ctx.fillStyle = '#4a2808';
        ctx.fillRect(x+10, y+5, 7, 1); ctx.fillRect(x+10, y+10, 7, 1); ctx.fillRect(x+10, y+15, 7, 1); ctx.fillRect(x+10, y+20, 7, 1);
        // Metal reinforcement bands (top & bottom)
        ctx.fillStyle = '#555'; ctx.fillRect(x+8, y+1, 12, 2); ctx.fillRect(x+8, y+TILE-7, 12, 2);
        ctx.fillStyle = '#777'; ctx.fillRect(x+8, y+1, 12, 1); ctx.fillRect(x+8, y+TILE-7, 12, 1);
        // Rivets on bands
        ctx.fillStyle = '#999'; ctx.fillRect(x+9, y+1, 1, 1); ctx.fillRect(x+18, y+1, 1, 1);
        ctx.fillRect(x+9, y+TILE-7, 1, 1); ctx.fillRect(x+18, y+TILE-7, 1, 1);
        // Highlight edge (light catching left side)
        ctx.fillStyle = '#9a6a3844'; ctx.fillRect(x+9, y+2, 1, TILE-7);
    }
}

function drawDoor(door) {
    const x = door.x, y = door.y;
    
    if (door.broken) {
        // Broken door: pixel art splintered remains
        let breakFade = door.breakAnim || 0;
        if (breakFade > 0) { door.breakAnim--; ctx.fillStyle = '#ff440018'; ctx.fillRect(x-2, y-2, TILE+4, TILE+4); }
        // Stone frame remains (pixel bricks)
        ctx.fillStyle = '#4a3a2a'; ctx.fillRect(x, y, 3, TILE); ctx.fillRect(x+TILE-3, y, 3, TILE);
        ctx.fillStyle = '#3a2a1a'; ctx.fillRect(x+1, y+2, 2, 5); ctx.fillRect(x+1, y+9, 2, 5); ctx.fillRect(x+TILE-3, y+3, 2, 5); ctx.fillRect(x+TILE-3, y+10, 2, 5);
        // Splinters (pixel wood pieces)
        ctx.fillStyle = '#6a4a28'; ctx.fillRect(x+5, y+4, 4, 7); ctx.fillRect(x+16, y+8, 3, 8);
        ctx.fillStyle = '#5a3a18'; ctx.fillRect(x+10, y+15, 5, 5); ctx.fillRect(x+7, y+20, 4, 3);
        ctx.fillStyle = '#7a5a38'; ctx.fillRect(x+18, y+18, 4, 4); ctx.fillRect(x+5, y+12, 3, 3);
        // Small splinter pixels
        ctx.fillStyle = '#4a2a10'; ctx.fillRect(x+8, y+6, 2, 2); ctx.fillRect(x+20, y+14, 2, 2); ctx.fillRect(x+12, y+22, 2, 2);
        // Dust
        ctx.fillStyle = '#5a4a3a11'; ctx.fillRect(x+4, y+22, 20, 3);
        return;
    }
    
    if (door.closed) {
        let anim = door.closeAnim || 0;
        if (anim > 0) { door.closeAnim--; }
        let shake = anim > 0 ? Math.sin(anim * 2) * 1 : 0;
        
        // Stone door frame (pixel bricks)
        ctx.fillStyle = '#3a2a1a'; ctx.fillRect(x, y, TILE, 2); ctx.fillRect(x, y+TILE-2, TILE, 2);
        ctx.fillRect(x, y, 3, TILE); ctx.fillRect(x+TILE-3, y, 3, TILE);
        // Frame brick details
        ctx.fillStyle = '#4a3a28'; ctx.fillRect(x, y, 3, 6); ctx.fillRect(x, y+7, 3, 5); ctx.fillRect(x, y+13, 3, 5); ctx.fillRect(x, y+19, 3, 5);
        ctx.fillRect(x+TILE-3, y+2, 3, 5); ctx.fillRect(x+TILE-3, y+8, 3, 6); ctx.fillRect(x+TILE-3, y+15, 3, 5); ctx.fillRect(x+TILE-3, y+21, 3, 5);
        // Mortar lines on frame
        ctx.fillStyle = '#2a1a0a'; ctx.fillRect(x, y+6, 3, 1); ctx.fillRect(x, y+12, 3, 1); ctx.fillRect(x, y+18, 3, 1);
        ctx.fillRect(x+TILE-3, y+7, 3, 1); ctx.fillRect(x+TILE-3, y+14, 3, 1); ctx.fillRect(x+TILE-3, y+20, 3, 1);
        // Door body (thick wooden planks)
        ctx.fillStyle = '#5a3a18'; ctx.fillRect(x+3+shake, y+2, TILE-6, TILE-4);
        ctx.fillStyle = '#6a4a28'; ctx.fillRect(x+4+shake, y+3, TILE-8, TILE-6);
        // Vertical plank lines
        ctx.fillStyle = '#7a5a38'; ctx.fillRect(x+5+shake, y+3, 4, TILE-6); ctx.fillRect(x+10+shake, y+3, 5, TILE-6); ctx.fillRect(x+16+shake, y+3, 4, TILE-6); ctx.fillRect(x+21+shake, y+3, 4, TILE-6);
        // Plank gaps
        ctx.fillStyle = '#3a2008'; ctx.fillRect(x+9+shake, y+2, 1, TILE-4); ctx.fillRect(x+15+shake, y+2, 1, TILE-4); ctx.fillRect(x+20+shake, y+2, 1, TILE-4);
        // Horizontal support bands (iron)
        ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x+3+shake, y+7, TILE-6, 2); ctx.fillRect(x+3+shake, y+19, TILE-6, 2);
        ctx.fillStyle = '#5a5a5a'; ctx.fillRect(x+3+shake, y+7, TILE-6, 1); ctx.fillRect(x+3+shake, y+19, TILE-6, 1);
        // Rivets on bands
        ctx.fillStyle = '#777'; ctx.fillRect(x+5+shake, y+7, 1, 2); ctx.fillRect(x+12+shake, y+7, 1, 2); ctx.fillRect(x+19+shake, y+7, 1, 2); ctx.fillRect(x+23+shake, y+7, 1, 2);
        ctx.fillRect(x+5+shake, y+19, 1, 2); ctx.fillRect(x+12+shake, y+19, 1, 2); ctx.fillRect(x+19+shake, y+19, 1, 2); ctx.fillRect(x+23+shake, y+19, 1, 2);
        // Door handle (round pixel art)
        ctx.fillStyle = '#666'; ctx.fillRect(x+20+shake, y+12, 4, 4);
        ctx.fillStyle = '#888'; ctx.fillRect(x+20+shake, y+12, 4, 2);
        ctx.fillStyle = '#999'; ctx.fillRect(x+21+shake, y+12, 2, 1);
        // Keyhole below handle
        ctx.fillStyle = '#222'; ctx.fillRect(x+21+shake, y+16, 2, 2); ctx.fillRect(x+21+shake, y+17, 1, 1);
        // Wood grain pixel detail
        ctx.fillStyle = '#4a2a08'; ctx.fillRect(x+6+shake, y+11, 2, 1); ctx.fillRect(x+11+shake, y+14, 3, 1); ctx.fillRect(x+17+shake, y+10, 2, 1); ctx.fillRect(x+22+shake, y+23, 2, 1);
    } else {
        // Open door (pixel art swung to side)
        // Stone frame stays
        ctx.fillStyle = '#3a2a1a'; ctx.fillRect(x, y, 3, TILE); ctx.fillRect(x+TILE-3, y, 3, TILE);
        ctx.fillRect(x, y, TILE, 2); ctx.fillRect(x, y+TILE-2, TILE, 2);
        // Frame brick detail
        ctx.fillStyle = '#4a3a28'; ctx.fillRect(x, y+2, 3, 5); ctx.fillRect(x, y+8, 3, 5); ctx.fillRect(x, y+14, 3, 5); ctx.fillRect(x, y+20, 3, 5);
        // Open door leaf (pressed flat to left side)
        ctx.fillStyle = '#5a3a18'; ctx.fillRect(x+3, y+2, 4, TILE-4);
        ctx.fillStyle = '#6a4a28'; ctx.fillRect(x+4, y+3, 2, TILE-6);
        // Planks on open door
        ctx.fillStyle = '#4a2a10'; ctx.fillRect(x+3, y+7, 4, 1); ctx.fillRect(x+3, y+14, 4, 1); ctx.fillRect(x+3, y+20, 4, 1);
        // Handle (now facing forward on open door)
        ctx.fillStyle = '#777'; ctx.fillRect(x+5, y+13, 2, 2);
        // Opening highlight
        ctx.fillStyle = '#44ff4404'; ctx.fillRect(x+7, y+3, TILE-10, TILE-6);
    }
}

function drawLocker(locker) {
    const x = locker.x, y = locker.y;
    // Ground shadow
    ctx.fillStyle = '#00000044'; ctx.fillRect(x+2, y+TILE-3, TILE-4, 3);
    // Main locker body (dark metal)
    ctx.fillStyle = '#1a2228'; ctx.fillRect(x+2, y+1, TILE-4, TILE-2);
    // Body panels with slight color variation
    ctx.fillStyle = '#222d35'; ctx.fillRect(x+3, y+2, TILE-6, TILE-4);
    // Metal sheet texture - horizontal ridges
    ctx.fillStyle = '#283840'; ctx.fillRect(x+4, y+3, TILE-8, 2); ctx.fillRect(x+4, y+6, TILE-8, 1);
    ctx.fillRect(x+4, y+TILE-6, TILE-8, 1);
    // Left door panel
    ctx.fillStyle = '#1a2530'; ctx.fillRect(x+4, y+3, 9, TILE-6);
    ctx.fillStyle = '#203040'; ctx.fillRect(x+5, y+4, 7, TILE-8);
    // Right door panel
    ctx.fillStyle = '#1a2530'; ctx.fillRect(x+15, y+3, 9, TILE-6);
    ctx.fillStyle = '#203040'; ctx.fillRect(x+16, y+4, 7, TILE-8);
    // Vent slits (top of each door) - pixel art detail
    ctx.fillStyle = '#0a0e12';
    ctx.fillRect(x+5, y+4, 6, 1); ctx.fillRect(x+5, y+6, 6, 1); ctx.fillRect(x+5, y+8, 6, 1);
    ctx.fillRect(x+16, y+4, 6, 1); ctx.fillRect(x+16, y+6, 6, 1); ctx.fillRect(x+16, y+8, 6, 1);
    // Vent highlight (metal between slits)
    ctx.fillStyle = '#2a3a44';
    ctx.fillRect(x+5, y+5, 6, 1); ctx.fillRect(x+5, y+7, 6, 1);
    ctx.fillRect(x+16, y+5, 6, 1); ctx.fillRect(x+16, y+7, 6, 1);
    // Lower panel indents
    ctx.fillStyle = '#18222a'; ctx.fillRect(x+5, y+11, 6, 8); ctx.fillRect(x+5, y+20, 6, 4);
    ctx.fillRect(x+16, y+11, 6, 8); ctx.fillRect(x+16, y+20, 6, 4);
    // Panel highlight (top edge catch light)
    ctx.fillStyle = '#334855'; ctx.fillRect(x+5, y+11, 6, 1); ctx.fillRect(x+5, y+20, 6, 1);
    ctx.fillRect(x+16, y+11, 6, 1); ctx.fillRect(x+16, y+20, 6, 1);
    // Center line (door gap)
    ctx.fillStyle = '#0a0e12'; ctx.fillRect(x+13, y+3, 2, TILE-6);
    // Handle/latch (pixel art detail)
    ctx.fillStyle = '#6a6a6a'; ctx.fillRect(x+12, y+13, 1, 4); ctx.fillRect(x+15, y+13, 1, 4);
    ctx.fillStyle = '#8a8a8a'; ctx.fillRect(x+12, y+13, 1, 1); ctx.fillRect(x+15, y+13, 1, 1);
    // Lock plate
    ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x+13, y+14, 2, 3);
    ctx.fillStyle = '#3a3a3a'; ctx.fillRect(x+13, y+15, 2, 1);
    // Top crown (locker top)
    ctx.fillStyle = '#2a3844'; ctx.fillRect(x+2, y, TILE-4, 2);
    ctx.fillStyle = '#334855'; ctx.fillRect(x+3, y, TILE-6, 1);
    // Side edges (3D depth)
    ctx.fillStyle = '#111a20'; ctx.fillRect(x+2, y+1, 1, TILE-2); ctx.fillRect(x+TILE-3, y+1, 1, TILE-2);
    // Left edge highlight
    ctx.fillStyle = '#2a3a4466'; ctx.fillRect(x+3, y+2, 1, TILE-4);
    // Occupied glow (warm yellow seeping through vents)
    if (locker.occupied) {
        ctx.fillStyle = '#ffaa0008'; ctx.fillRect(x+2, y, TILE-4, TILE);
        ctx.fillStyle = '#ffcc0018';
        ctx.fillRect(x+5, y+4, 6, 1); ctx.fillRect(x+5, y+6, 6, 1);
        ctx.fillRect(x+16, y+4, 6, 1); ctx.fillRect(x+16, y+6, 6, 1);
    }
}

function drawHook(hook) {
    const x = hook.x, y = hook.y;
    if (hook.broken) {
        // Broken hook pixel art remains
        ctx.fillStyle = '#2a2a2a'; ctx.fillRect(x+12, y+18, 5, 12);
        ctx.fillStyle = '#333'; ctx.fillRect(x+13, y+18, 3, 10);
        // Broken base
        ctx.fillStyle = '#1a1a1a'; ctx.fillRect(x+9, y+28, 11, 4);
        ctx.fillStyle = '#252525'; ctx.fillRect(x+10, y+28, 9, 2);
        // Metal shards scattered
        ctx.fillStyle = '#555'; ctx.fillRect(x+8, y+13, 3, 3); ctx.fillRect(x+17, y+15, 2, 3);
        ctx.fillStyle = '#444'; ctx.fillRect(x+6, y+17, 2, 2); ctx.fillRect(x+19, y+12, 2, 2);
        ctx.fillStyle = '#3a3a3a'; ctx.fillRect(x+11, y+14, 2, 2);
        return;
    }
    // Ground shadow
    ctx.fillStyle = '#00000044'; ctx.fillRect(x+8, y+TILE-1, 14, 3);
    // Base plate (heavy metal, detailed)
    ctx.fillStyle = '#222'; ctx.fillRect(x+7, y+28, 15, 4);
    ctx.fillStyle = '#2a2a2a'; ctx.fillRect(x+8, y+28, 13, 2);
    ctx.fillStyle = '#333'; ctx.fillRect(x+8, y+28, 13, 1); // highlight top
    // Base bolts
    ctx.fillStyle = '#555'; ctx.fillRect(x+8, y+29, 1, 1); ctx.fillRect(x+20, y+29, 1, 1);
    // Main post (iron with detail)
    ctx.fillStyle = '#3a3a3a'; ctx.fillRect(x+12, y+5, 5, 24);
    // Post highlight (left edge catches light)
    ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x+12, y+5, 2, 24);
    // Post shadow (right edge)
    ctx.fillStyle = '#2a2a2a'; ctx.fillRect(x+16, y+5, 1, 24);
    // Post rivets (evenly spaced)
    ctx.fillStyle = '#555'; ctx.fillRect(x+13, y+10, 1, 1); ctx.fillRect(x+13, y+16, 1, 1); ctx.fillRect(x+13, y+22, 1, 1);
    ctx.fillRect(x+15, y+13, 1, 1); ctx.fillRect(x+15, y+19, 1, 1); ctx.fillRect(x+15, y+25, 1, 1);
    // Post wrapping (rope/chain detail)
    ctx.fillStyle = '#4a3a2a'; ctx.fillRect(x+11, y+20, 7, 1); ctx.fillRect(x+12, y+22, 5, 1);
    // Hook arm (horizontal bracket)
    ctx.fillStyle = '#555'; ctx.fillRect(x+7, y+4, 15, 3);
    ctx.fillStyle = '#666'; ctx.fillRect(x+7, y+4, 15, 1); // top highlight
    ctx.fillStyle = '#3a3a3a'; ctx.fillRect(x+7, y+6, 15, 1); // bottom shadow
    // Hook curve (L-shape going down)
    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(x+7, y+4, 3, 12);
    ctx.fillStyle = '#666'; ctx.fillRect(x+7, y+4, 1, 12); // highlight edge
    ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x+9, y+4, 1, 12); // shadow edge
    // Hook bottom curve (going right)
    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(x+7, y+14, 8, 3);
    ctx.fillStyle = '#666'; ctx.fillRect(x+7, y+14, 8, 1); // top highlight
    // Hook point (sharp, getting thinner)
    ctx.fillStyle = '#777'; ctx.fillRect(x+7, y+14, 2, 6);
    ctx.fillStyle = '#8a8a8a'; ctx.fillRect(x+7, y+14, 1, 6);
    ctx.fillStyle = '#aaa'; ctx.fillRect(x+7, y+18, 1, 3); // sharp tip highlight
    ctx.fillStyle = '#ccc'; ctx.fillRect(x+7, y+19, 1, 2); // very tip (bright)
    // Entity corruption tendrils (animated dark energy pixel art)
    let t = gameTimer * 0.03;
    let t2 = gameTimer * 0.02;
    // Left tendril
    ctx.fillStyle = '#ff330022';
    ctx.fillRect(x+4, y+7+Math.sin(t)*2, 2, 2); ctx.fillRect(x+3, y+10+Math.sin(t+0.5)*2, 2, 3);
    ctx.fillRect(x+5, y+14+Math.sin(t+1)*2, 2, 2); ctx.fillRect(x+3, y+18+Math.sin(t+1.5)*2, 2, 2);
    // Right tendril
    ctx.fillStyle = '#ff220018';
    ctx.fillRect(x+22, y+8+Math.cos(t)*2, 2, 3); ctx.fillRect(x+23, y+13+Math.cos(t+0.7)*2, 2, 2);
    ctx.fillRect(x+21, y+17+Math.cos(t+1.4)*2, 2, 3);
    // Entity red glow particles
    ctx.fillStyle = `rgba(255,50,0,${0.15+Math.sin(t2)*0.1})`;
    ctx.fillRect(x+5, y+5+Math.sin(t)*3, 1, 1); ctx.fillRect(x+22, y+6+Math.cos(t)*3, 1, 1);
    ctx.fillRect(x+4, y+20+Math.sin(t+2)*2, 1, 1); ctx.fillRect(x+24, y+19+Math.cos(t+2)*2, 1, 1);
    
    if (hook.occupied) {
        let s = hook.occupied;
        let phase = s.hookState;
        // Entity corruption intensifies
        let intensity = phase === 2 ? 0.6 : 0.3;
        ctx.fillStyle = `rgba(255,50,0,${intensity * (Math.sin(gameTimer * 0.05) * 0.3 + 0.7) * 0.3})`;
        let to = Math.sin(gameTimer * 0.05) * 3;
        ctx.fillRect(x+1, y+6+to, 3, 14);
        ctx.fillRect(x+TILE-4, y+8-to, 3, 12);
        // Additional entity pixels when occupied
        ctx.fillStyle = `rgba(255,80,0,${intensity*0.5})`;
        ctx.fillRect(x+2, y+4+to, 2, 2); ctx.fillRect(x+24, y+5-to, 2, 2);
        ctx.fillRect(x+3, y+22+to, 2, 2); ctx.fillRect(x+23, y+21-to, 2, 2);
        // Timer bar (pixel art style)
        let maxTime = phase === 1 ? HOOK_PHASE1_TIME : HOOK_PHASE2_TIME;
        let ratio = 1 - (s.hookTimer / maxTime);
        ctx.fillStyle = '#111'; ctx.fillRect(x+2, y-7, 24, 6);
        ctx.fillStyle = '#1a1a1a'; ctx.fillRect(x+3, y-6, 22, 4);
        ctx.fillStyle = '#222'; ctx.fillRect(x+3, y-6, 22, 1); // inner border top
        ctx.fillStyle = phase === 2 ? '#cc0000' : '#cc8800'; ctx.fillRect(x+3, y-5, Math.floor(22*ratio), 3);
        ctx.fillStyle = phase === 2 ? '#ff2222' : '#ffcc00'; ctx.fillRect(x+3, y-5, Math.floor(22*ratio), 1); // bar highlight
    }
}

function drawTrap(trap) {
    // Ground shadow (pixel art)
    ctx.fillStyle = '#00000033'; ctx.fillRect(trap.x-10, trap.y+2, 20, 4);
    // Trap base plate (outer dark metal ring)
    ctx.fillStyle = '#3a2800'; ctx.fillRect(trap.x-10, trap.y-10, 20, 20);
    // Inner base (rusted metal)
    ctx.fillStyle = '#4a3408'; ctx.fillRect(trap.x-9, trap.y-9, 18, 18);
    ctx.fillStyle = '#5a4010'; ctx.fillRect(trap.x-8, trap.y-8, 16, 16);
    // Metal texture detail
    ctx.fillStyle = '#6a4a18'; ctx.fillRect(trap.x-7, trap.y-7, 14, 14);
    // Dark inner ring
    ctx.fillStyle = '#3a2800'; ctx.fillRect(trap.x-6, trap.y-6, 12, 12);
    ctx.fillStyle = '#4a3408'; ctx.fillRect(trap.x-5, trap.y-5, 10, 10);
    // Steel teeth (pixel art jagged pattern - top row)
    ctx.fillStyle = '#bbb';
    ctx.fillRect(trap.x-7, trap.y-4, 1, 3); ctx.fillRect(trap.x-5, trap.y-5, 1, 4);
    ctx.fillRect(trap.x-3, trap.y-4, 1, 3); ctx.fillRect(trap.x-1, trap.y-5, 1, 4);
    ctx.fillRect(trap.x+1, trap.y-4, 1, 3); ctx.fillRect(trap.x+3, trap.y-5, 1, 4);
    ctx.fillRect(trap.x+5, trap.y-4, 1, 3); ctx.fillRect(trap.x+7, trap.y-5, 1, 4);
    // Bottom teeth
    ctx.fillRect(trap.x-6, trap.y+2, 1, 3); ctx.fillRect(trap.x-4, trap.y+1, 1, 4);
    ctx.fillRect(trap.x-2, trap.y+2, 1, 3); ctx.fillRect(trap.x+0, trap.y+1, 1, 4);
    ctx.fillRect(trap.x+2, trap.y+2, 1, 3); ctx.fillRect(trap.x+4, trap.y+1, 1, 4);
    ctx.fillRect(trap.x+6, trap.y+2, 1, 3);
    // Teeth highlights
    ctx.fillStyle = '#ddd';
    ctx.fillRect(trap.x-5, trap.y-5, 1, 1); ctx.fillRect(trap.x-1, trap.y-5, 1, 1);
    ctx.fillRect(trap.x+3, trap.y-5, 1, 1); ctx.fillRect(trap.x+7, trap.y-5, 1, 1);
    // Center trigger mechanism
    ctx.fillStyle = '#888'; ctx.fillRect(trap.x-2, trap.y-2, 4, 4);
    ctx.fillStyle = '#666'; ctx.fillRect(trap.x-1, trap.y-1, 2, 2);
    ctx.fillStyle = '#aaa'; ctx.fillRect(trap.x-2, trap.y-2, 4, 1); // highlight
    // Corner bolts
    ctx.fillStyle = '#777'; ctx.fillRect(trap.x-8, trap.y-8, 2, 2); ctx.fillRect(trap.x+7, trap.y-8, 2, 2);
    ctx.fillRect(trap.x-8, trap.y+7, 2, 2); ctx.fillRect(trap.x+7, trap.y+7, 2, 2);
    // Warning glow (subtle pulsing)
    let pulse = Math.sin(gameTimer * 0.06) * 0.3 + 0.7;
    ctx.fillStyle = `rgba(255,170,0,${0.05 * pulse})`; ctx.fillRect(trap.x-12, trap.y-12, 24, 24);
}

function drawGenerator(gen) {
    const x = gen.x, y = gen.y;
    let t = gameTimer * 0.03;
    
    // Ground shadow
    ctx.fillStyle = '#00000044'; ctx.fillRect(x+3, y+TILE-2, 22, 3);
    
    if (gen.completed) {
        // Completed generator — glowing, powered
        // Base/platform
        ctx.fillStyle = '#3a3a3a'; ctx.fillRect(x+2, y+22, 24, 6);
        ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x+3, y+22, 22, 3);
        // Main body (metal housing)
        ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x+4, y+8, 20, 15);
        ctx.fillStyle = '#555'; ctx.fillRect(x+5, y+9, 18, 13);
        // Pistons/cylinders on top
        ctx.fillStyle = '#666'; ctx.fillRect(x+6, y+3, 5, 7); ctx.fillRect(x+17, y+3, 5, 7);
        ctx.fillStyle = '#777'; ctx.fillRect(x+7, y+4, 3, 5); ctx.fillRect(x+18, y+4, 3, 5);
        // Piston caps
        ctx.fillStyle = '#888'; ctx.fillRect(x+6, y+2, 5, 2); ctx.fillRect(x+17, y+2, 5, 2);
        // Center engine block
        ctx.fillStyle = '#555'; ctx.fillRect(x+11, y+5, 6, 6);
        ctx.fillStyle = '#666'; ctx.fillRect(x+12, y+6, 4, 4);
        // POWERED GLOW (yellow/white)
        let glow = Math.sin(t * 2) * 0.2 + 0.8;
        ctx.fillStyle = `rgba(255,200,0,${0.15 * glow})`; ctx.fillRect(x, y, TILE, TILE);
        // Light indicator (bright)
        ctx.fillStyle = '#ffcc00'; ctx.fillRect(x+13, y+14, 2, 2);
        ctx.fillStyle = '#fff'; ctx.fillRect(x+13, y+14, 1, 1);
        // Exhaust pipe with steam
        ctx.fillStyle = '#444'; ctx.fillRect(x+22, y+6, 3, 4);
        if (gameTimer % 30 < 15) { ctx.fillStyle = '#ffffff22'; ctx.fillRect(x+23, y+3, 2, 3); ctx.fillRect(x+24, y+1, 2, 2); }
        // Wires (connected, tidy)
        ctx.fillStyle = '#333'; ctx.fillRect(x+2, y+16, 3, 2); ctx.fillRect(x+23, y+16, 3, 2);
    } else {
        // In-progress generator
        // Base/platform
        ctx.fillStyle = '#2a2a2a'; ctx.fillRect(x+2, y+22, 24, 6);
        ctx.fillStyle = '#333'; ctx.fillRect(x+3, y+22, 22, 3);
        // Bolts on base
        ctx.fillStyle = '#555'; ctx.fillRect(x+4, y+23, 1, 1); ctx.fillRect(x+23, y+23, 1, 1);
        // Main body (darker, not powered)
        ctx.fillStyle = '#2a2a2a'; ctx.fillRect(x+4, y+8, 20, 15);
        ctx.fillStyle = '#333'; ctx.fillRect(x+5, y+9, 18, 13);
        // Metal panel lines
        ctx.fillStyle = '#222'; ctx.fillRect(x+13, y+9, 1, 13); // center seam
        ctx.fillRect(x+5, y+15, 18, 1); // horizontal seam
        // Pistons/cylinders
        ctx.fillStyle = '#3a3a3a'; ctx.fillRect(x+6, y+3, 5, 7); ctx.fillRect(x+17, y+3, 5, 7);
        ctx.fillStyle = '#444'; ctx.fillRect(x+7, y+4, 3, 5); ctx.fillRect(x+18, y+4, 3, 5);
        // Piston caps
        ctx.fillStyle = '#555'; ctx.fillRect(x+6, y+2, 5, 2); ctx.fillRect(x+17, y+2, 5, 2);
        // Piston rods (animated when being repaired)
        if (gen.progress > 0 && gen.progress < 100) {
            let piston = Math.sin(t * 4) * 2;
            ctx.fillStyle = '#666'; ctx.fillRect(x+8, y+1+piston, 1, 3); ctx.fillRect(x+19, y+1-piston, 1, 3);
        }
        // Center engine block
        ctx.fillStyle = '#2a2a2a'; ctx.fillRect(x+11, y+5, 6, 6);
        ctx.fillStyle = '#333'; ctx.fillRect(x+12, y+6, 4, 4);
        // Fan/flywheel in center (rotates when repairing)
        if (gen.progress > 0) {
            let rot = gameTimer % 4;
            ctx.fillStyle = '#555';
            if (rot < 2) { ctx.fillRect(x+12, y+7, 4, 1); ctx.fillRect(x+13, y+6, 1, 4); }
            else { ctx.fillRect(x+12, y+8, 4, 1); ctx.fillRect(x+14, y+6, 1, 4); }
        }
        // Exhaust pipe
        ctx.fillStyle = '#333'; ctx.fillRect(x+22, y+6, 3, 4);
        ctx.fillStyle = '#2a2a2a'; ctx.fillRect(x+22, y+7, 3, 2);
        // Exposed wires (messy, hanging)
        ctx.fillStyle = '#882222'; ctx.fillRect(x+2, y+16, 3, 1); ctx.fillRect(x+1, y+17, 2, 3);
        ctx.fillStyle = '#228822'; ctx.fillRect(x+23, y+14, 3, 1); ctx.fillRect(x+24, y+15, 2, 3);
        ctx.fillStyle = '#222288'; ctx.fillRect(x+10, y+21, 4, 2);
        // Light indicator (off/red)
        ctx.fillStyle = gen.progress > 0 ? '#ff6600' : '#440000';
        ctx.fillRect(x+13, y+14, 2, 2);
        // Rust spots
        ctx.fillStyle = '#4a2a1a11'; ctx.fillRect(x+7, y+11, 3, 3); ctx.fillRect(x+18, y+18, 3, 2);
        
        // PROGRESS BAR (shows repair progress)
        if (gen.progress > 0) {
            ctx.fillStyle = '#111'; ctx.fillRect(x+2, y-4, 24, 4);
            ctx.fillStyle = '#1a1a1a'; ctx.fillRect(x+3, y-3, 22, 2);
            let ratio = gen.progress / 100;
            ctx.fillStyle = ratio > 0.7 ? '#44ff44' : ratio > 0.3 ? '#ffaa00' : '#ff4444';
            ctx.fillRect(x+3, y-3, Math.floor(22 * ratio), 2);
            ctx.fillStyle = '#ffffff44'; ctx.fillRect(x+3, y-3, Math.floor(22 * ratio), 1);
        }
        
        // Sparking effect (random sparks when partially done)
        if (gen.progress > 20 && gen.progress < 100 && gameTimer % 40 < 3) {
            ctx.fillStyle = '#ffcc00'; ctx.fillRect(x+8+(gameTimer%12), y+5, 2, 2);
            ctx.fillStyle = '#fff'; ctx.fillRect(x+10+(gameTimer%8), y+4, 1, 1);
        }
    }
}

function drawChest(chest) {
    const x = chest.x, y = chest.y;
    // Ground shadow
    ctx.fillStyle = '#00000044'; ctx.fillRect(x+4, y+TILE-2, 20, 3);
    
    if (chest.opened) {
        // Open chest - pixel art treasure chest
        // Main body (wooden)
        ctx.fillStyle = '#4a2808'; ctx.fillRect(x+3, y+13, 22, 13);
        ctx.fillStyle = '#5a3810'; ctx.fillRect(x+4, y+14, 20, 11);
        // Body plank lines
        ctx.fillStyle = '#6a4818'; ctx.fillRect(x+5, y+15, 8, 4); ctx.fillRect(x+14, y+15, 8, 4);
        ctx.fillStyle = '#6a4818'; ctx.fillRect(x+5, y+20, 8, 4); ctx.fillRect(x+14, y+20, 8, 4);
        // Plank gaps horizontal
        ctx.fillStyle = '#3a1a04'; ctx.fillRect(x+4, y+19, 20, 1);
        // Inner darkness (cavity)
        ctx.fillStyle = '#0a0400'; ctx.fillRect(x+5, y+14, 18, 6);
        ctx.fillStyle = '#140a00'; ctx.fillRect(x+6, y+15, 16, 4);
        // Lid (swung open, angled back)
        ctx.fillStyle = '#5a3810'; ctx.fillRect(x+3, y+4, 22, 10);
        ctx.fillStyle = '#6a4818'; ctx.fillRect(x+4, y+5, 20, 8);
        // Lid planks
        ctx.fillStyle = '#7a5828'; ctx.fillRect(x+5, y+5, 5, 7); ctx.fillRect(x+11, y+5, 5, 7); ctx.fillRect(x+17, y+5, 5, 7);
        // Lid plank gaps
        ctx.fillStyle = '#4a2808'; ctx.fillRect(x+10, y+4, 1, 10); ctx.fillRect(x+16, y+4, 1, 10);
        // Lid inner (visible since open)
        ctx.fillStyle = '#3a1a08'; ctx.fillRect(x+4, y+9, 20, 4);
        // Metal band on lid
        ctx.fillStyle = '#555'; ctx.fillRect(x+3, y+7, 22, 2);
        ctx.fillStyle = '#666'; ctx.fillRect(x+3, y+7, 22, 1);
        // Hinges (connecting lid to body)
        ctx.fillStyle = '#5a5a5a'; ctx.fillRect(x+6, y+12, 3, 2); ctx.fillRect(x+19, y+12, 3, 2);
        ctx.fillStyle = '#777'; ctx.fillRect(x+7, y+12, 1, 1); ctx.fillRect(x+20, y+12, 1, 1);
        // Body corner brackets
        ctx.fillStyle = '#555'; ctx.fillRect(x+3, y+13, 2, 13); ctx.fillRect(x+23, y+13, 2, 13);
        ctx.fillStyle = '#666'; ctx.fillRect(x+3, y+13, 1, 13); ctx.fillRect(x+23, y+13, 1, 13);
        // Body bottom band
        ctx.fillStyle = '#555'; ctx.fillRect(x+3, y+24, 22, 2);
        ctx.fillStyle = '#666'; ctx.fillRect(x+3, y+24, 22, 1);
    } else {
        // Closed chest - pixel art with magical aura
        let pulse = Math.sin(gameTimer * 0.05) * 0.15 + 0.85;
        // Subtle golden glow
        ctx.fillStyle = `rgba(255,200,0,${0.06 * pulse})`; ctx.fillRect(x+1, y+3, 26, 24);
        // Main body (wooden)
        ctx.fillStyle = '#4a2808'; ctx.fillRect(x+3, y+12, 22, 14);
        ctx.fillStyle = '#5a3810'; ctx.fillRect(x+4, y+13, 20, 12);
        // Body planks (individual boards)
        ctx.fillStyle = '#6a4818'; ctx.fillRect(x+5, y+14, 4, 5); ctx.fillRect(x+10, y+14, 5, 5); ctx.fillRect(x+16, y+14, 4, 5); ctx.fillRect(x+21, y+14, 4, 5);
        ctx.fillStyle = '#6a4818'; ctx.fillRect(x+5, y+20, 4, 4); ctx.fillRect(x+10, y+20, 5, 4); ctx.fillRect(x+16, y+20, 4, 4); ctx.fillRect(x+21, y+20, 4, 4);
        // Plank gaps (vertical)
        ctx.fillStyle = '#3a1a04'; ctx.fillRect(x+9, y+13, 1, 11); ctx.fillRect(x+15, y+13, 1, 11); ctx.fillRect(x+20, y+13, 1, 11);
        // Horizontal middle gap
        ctx.fillStyle = '#3a1a04'; ctx.fillRect(x+4, y+19, 20, 1);
        // Wood grain pixels
        ctx.fillStyle = '#4a2808'; ctx.fillRect(x+6, y+16, 2, 1); ctx.fillRect(x+12, y+15, 2, 1); ctx.fillRect(x+18, y+17, 2, 1);
        ctx.fillRect(x+7, y+22, 2, 1); ctx.fillRect(x+17, y+21, 2, 1);
        // Lid (rounded top - characteristic treasure chest shape)
        ctx.fillStyle = '#5a3810'; ctx.fillRect(x+2, y+6, 24, 7);
        ctx.fillStyle = '#6a4818'; ctx.fillRect(x+3, y+7, 22, 5);
        // Lid rounded top pixels
        ctx.fillStyle = '#6a4818'; ctx.fillRect(x+4, y+5, 20, 2);
        ctx.fillStyle = '#7a5828'; ctx.fillRect(x+6, y+4, 16, 2);
        ctx.fillStyle = '#7a5828'; ctx.fillRect(x+8, y+3, 12, 2);
        // Lid plank detail
        ctx.fillStyle = '#7a5828'; ctx.fillRect(x+5, y+7, 5, 4); ctx.fillRect(x+11, y+7, 5, 4); ctx.fillRect(x+17, y+7, 5, 4);
        ctx.fillStyle = '#4a2808'; ctx.fillRect(x+10, y+5, 1, 7); ctx.fillRect(x+16, y+5, 1, 7);
        // Metal corner brackets (pixel art L-shapes)
        ctx.fillStyle = '#555'; ctx.fillRect(x+3, y+6, 2, 20); ctx.fillRect(x+23, y+6, 2, 20);
        ctx.fillStyle = '#666'; ctx.fillRect(x+3, y+6, 1, 20); ctx.fillRect(x+23, y+6, 1, 20);
        // Horizontal metal bands
        ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x+3, y+11, 22, 2); ctx.fillRect(x+3, y+24, 22, 2);
        ctx.fillStyle = '#5a5a5a'; ctx.fillRect(x+3, y+11, 22, 1); ctx.fillRect(x+3, y+24, 22, 1);
        // Rivets on bands
        ctx.fillStyle = '#777'; ctx.fillRect(x+6, y+11, 1, 1); ctx.fillRect(x+14, y+11, 1, 1); ctx.fillRect(x+21, y+11, 1, 1);
        ctx.fillRect(x+6, y+24, 1, 1); ctx.fillRect(x+14, y+24, 1, 1); ctx.fillRect(x+21, y+24, 1, 1);
        // Lock (ornate golden pixel art)
        ctx.fillStyle = '#aa7700'; ctx.fillRect(x+11, y+14, 6, 6);
        ctx.fillStyle = '#cc9900'; ctx.fillRect(x+12, y+15, 4, 4);
        ctx.fillStyle = '#ddaa00'; ctx.fillRect(x+12, y+15, 4, 2); // highlight top
        // Lock arch (top semicircle)
        ctx.fillStyle = '#aa7700'; ctx.fillRect(x+12, y+12, 4, 3);
        ctx.fillStyle = '#cc9900'; ctx.fillRect(x+13, y+12, 2, 2);
        // Keyhole
        ctx.fillStyle = '#1a0a00'; ctx.fillRect(x+13, y+16, 2, 2); ctx.fillRect(x+13, y+18, 1, 1);
        // Latch plate behind lock
        ctx.fillStyle = '#444'; ctx.fillRect(x+10, y+14, 1, 6); ctx.fillRect(x+17, y+14, 1, 6);
    }
}

function drawWiggleBar(p) { let ratio = p.wiggleProgress / 100; ctx.fillStyle = '#222'; ctx.fillRect(p.x - 15, p.y - 25, 30, 5); ctx.fillStyle = '#ffaa00'; ctx.fillRect(p.x - 15, p.y - 25, 30 * ratio, 5); }

function drawPlayerSprite(p) {
    const x = p.x, y = p.y;
    
    // ===== CRAWLING (DYING) SURVIVOR =====
    if (p.dying && p.role === 'survivor') {
        drawCrawlingSurvivor(p, x, y);
        return;
    }
    
    // Enhanced drop shadow
    ctx.fillStyle = '#00000044'; ctx.beginPath(); ctx.ellipse(x, y + 12, 9, 4, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#00000022'; ctx.beginPath(); ctx.ellipse(x, y + 12, 12, 5, 0, 0, Math.PI * 2); ctx.fill();
    
    const bobY = Math.sin(gameTimer * 0.15) * (p.isRunning ? 2 : 0.8);
    const breathe = Math.sin(gameTimer * 0.05) * 0.5;
    const lean = p.isRunning ? Math.sin(gameTimer * 0.12) * 1.5 : 0;
    const armSwing = p.isRunning ? Math.sin(gameTimer * 0.2) * 4 : Math.sin(gameTimer * 0.04) * 1;
    
    if (p.role === 'killer') {
        drawKillerDetailed(p, x, y, bobY, lean);
    } else {
        drawSurvivorDetailed(p, x, y, bobY, lean);
    }
    
    // Item indicator
    if (p.heldItem && p.role === 'survivor') {
        let itemIcon = p.heldItem === 'medkit' ? '#44ff44' : '#ffff44';
        ctx.fillStyle = itemIcon; ctx.shadowColor = itemIcon; ctx.shadowBlur = 4;
        ctx.fillRect(x + 8, y - 18 + bobY, 4, 4);
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#ffffff88'; ctx.fillRect(x + 9, y - 17 + bobY, 2, 2);
    }
    
    // Speed boost trail
    if (p.speedBoost > 30 && p.role === 'survivor') {
        ctx.globalAlpha = 0.3;
        for (let i = 1; i <= 3; i++) {
            ctx.fillStyle = '#ffffff11';
            ctx.beginPath(); ctx.arc(x - p.vx * i * 6, y - p.vy * i * 6 + 2, 6 - i, 0, Math.PI * 2); ctx.fill();
        }
        ctx.globalAlpha = 1;
    }
    
    // Stun stars (enhanced)
    if (p.stunned > 0) {
        let s = gameTimer * 0.12;
        for (let i = 0; i < 4; i++) {
            let sx = x + Math.cos(s + i * 1.57) * 15, sy = y - 20 + Math.sin(s + i * 1.57) * 5;
            ctx.fillStyle = '#ffff00'; ctx.shadowColor = '#ffff00'; ctx.shadowBlur = 3;
            ctx.fillRect(sx - 1, sy - 1, 3, 3);
            ctx.fillStyle = '#ffffff'; ctx.fillRect(sx, sy, 1, 1);
        }
        ctx.shadowBlur = 0;
    }
    
    // Dying bleedout bar
    if (p.dying) {
        let ratio = 1 - (p.dyingTimer / 2700);
        ctx.fillStyle = '#11000088'; ctx.fillRect(x - 14, y - 24, 28, 5);
        ctx.fillStyle = '#330000'; ctx.fillRect(x - 13, y - 23, 26, 3);
        let barCol = ratio > 0.5 ? '#ff4400' : '#ff0000';
        ctx.fillStyle = barCol; ctx.fillRect(x - 13, y - 23, 26 * ratio, 3);
        ctx.fillStyle = '#ffffff44'; ctx.fillRect(x - 13, y - 23, 26 * ratio, 1);
    }
    
    // Player label
    ctx.fillStyle = p.role === 'killer' ? '#ff4444' : '#44ff44';
    ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center';
    ctx.fillText(`J${p.id + 1}`, x, y - 26);
    
    // Borrowed Time shield
    if (p.borrowedTimeActive > 0) {
        let pulse = Math.sin(gameTimer * 0.15) * 0.3 + 0.7;
        ctx.strokeStyle = `rgba(255,200,0,${pulse})`; ctx.lineWidth = 2;
        ctx.shadowColor = '#ffcc00'; ctx.shadowBlur = 6;
        ctx.beginPath(); ctx.arc(x, y, 16, 0, Math.PI * 2); ctx.stroke();
        ctx.shadowBlur = 0;
    }
    
    // Dead Hard dash effect
    if (p.deadHardActive > 0) {
        ctx.fillStyle = '#44aaff33';
        ctx.beginPath(); ctx.arc(x, y, 14, 0, Math.PI * 2); ctx.fill();
        for (let i = 0; i < 4; i++) {
            let angle = gameTimer * 0.3 + i * 1.57;
            ctx.fillStyle = '#88ccff'; ctx.fillRect(x + Math.cos(angle) * 12 - 1, y + Math.sin(angle) * 12 - 1, 2, 2);
        }
    }
}

function drawKillerDetailed(p, x, y, bobY, lean, armSwing, breathe) {
    let cd = p.charData, sk = p.skinData;
    let mainColor = sk?.color || cd.color;
    let secColor = sk?.secondaryColor || cd.secondaryColor;
    let weapColor = sk?.weaponColor || cd.weaponColor;
    let glowCol = sk?.glowColor || cd.glowColor;
    let skinKey = p.skin;
    
    // Ominous ground glow
    let glowPulse = Math.sin(gameTimer * 0.04) * 0.3 + 0.7;
    ctx.fillStyle = glowCol + '12'; ctx.beginPath(); ctx.arc(x, y + 12, 20 * glowPulse, 0, Math.PI * 2); ctx.fill();
    
    // ====== LEGS ======
    let legAnim = Math.sin(gameTimer * 0.2) * (p.isRunning ? 4 : 0);
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(x - 6 + lean, y + 8 + bobY, 5, 8 + legAnim);
    ctx.fillRect(x + 2 + lean, y + 8 + bobY, 5, 8 - legAnim);
    // Boots
    ctx.fillStyle = '#111111';
    ctx.fillRect(x - 7 + lean, y + 15 + bobY + legAnim, 6, 3);
    ctx.fillRect(x + 1 + lean, y + 15 + bobY - legAnim, 6, 3);
    // Boot soles
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(x - 7 + lean, y + 17 + bobY + legAnim, 6, 1);
    ctx.fillRect(x + 1 + lean, y + 17 + bobY - legAnim, 6, 1);
    
    // ====== BODY (character specific) ======
    let charKey = p.charKey;
    
    if (charKey === 'trapper' && skinKey === 'default') {
        // TRAPPER - overalls, bone/leather mask, machete, bulky
        ctx.fillStyle = '#4a4030'; ctx.fillRect(x-10+lean, y-6+bobY, 20, 16);
        ctx.fillStyle = '#5a5040'; ctx.fillRect(x-9+lean, y-4+bobY, 18, 12);
        ctx.fillStyle = '#333322'; ctx.fillRect(x-7+lean, y-5+bobY, 3, 12); ctx.fillRect(x+5+lean, y-5+bobY, 3, 12);
        ctx.fillStyle = '#444433'; ctx.fillRect(x-9+lean, y+4+bobY, 18, 3);
        ctx.fillStyle = '#886644'; ctx.fillRect(x-12+lean, y-4+bobY, 3, 10); ctx.fillRect(x+10+lean, y-4+bobY, 3, 10);
        ctx.fillStyle = '#665544'; ctx.fillRect(x-6+lean, y-16+bobY, 12, 11);
        ctx.fillStyle = '#998877'; ctx.fillRect(x-5+lean, y-14+bobY, 10, 8);
        ctx.fillStyle = '#111100'; ctx.fillRect(x-3+lean, y-12+bobY, 2, 3); ctx.fillRect(x+2+lean, y-12+bobY, 2, 3);
        ctx.fillStyle = '#443322'; ctx.fillRect(x-1+lean, y-9+bobY, 1, 3); ctx.fillRect(x+1+lean, y-10+bobY, 1, 4);
        if (!p.attacking) { ctx.fillStyle = '#999999'; ctx.fillRect(x+10+lean, y-8+bobY, 3, 14); ctx.fillStyle='#554422'; ctx.fillRect(x+10+lean, y+4+bobY, 3, 4); }
    } else if (charKey === 'huntress' && skinKey === 'default') {
        // HUNTRESS - bunny mask, green military, hatchet
        ctx.fillStyle = '#3a5a3a'; ctx.fillRect(x-9+lean, y-6+bobY, 18, 16);
        ctx.fillStyle = '#4a6a4a'; ctx.fillRect(x-8+lean, y-4+bobY, 16, 12);
        ctx.fillStyle = '#2a4a2a'; ctx.fillRect(x-11+lean, y-3+bobY, 3, 9); ctx.fillRect(x+9+lean, y-3+bobY, 3, 9);
        // Bunny mask - white
        ctx.fillStyle = '#eeeedd'; ctx.fillRect(x-5+lean, y-16+bobY, 10, 11);
        ctx.fillStyle = '#ddddcc'; ctx.fillRect(x-4+lean, y-14+bobY, 8, 8);
        // Rabbit ears
        ctx.fillStyle = '#eeeedd'; ctx.fillRect(x-3+lean, y-24+bobY, 3, 9); ctx.fillRect(x+1+lean, y-24+bobY, 3, 9);
        ctx.fillStyle = '#ffcccc'; ctx.fillRect(x-2+lean, y-23+bobY, 1, 7); ctx.fillRect(x+2+lean, y-23+bobY, 1, 7);
        // Dark eyes
        ctx.fillStyle = '#000000'; ctx.fillRect(x-3+lean, y-12+bobY, 2, 3); ctx.fillRect(x+2+lean, y-12+bobY, 2, 3);
        if (!p.attacking) { ctx.fillStyle='#888888'; ctx.fillRect(x+9+lean, y-6+bobY, 4, 8); ctx.fillStyle='#554422'; ctx.fillRect(x+9+lean, y+0+bobY, 4, 4); }
    } else if (charKey === 'demogorgon' && skinKey === 'default') {
        // DEMOGORGON - tall grey/brown creature, flower head opens
        ctx.fillStyle = '#3a2a2a'; ctx.fillRect(x-9+lean, y-6+bobY, 18, 16);
        ctx.fillStyle = '#4a3535'; ctx.fillRect(x-8+lean, y-4+bobY, 16, 12);
        // Long clawed arms
        ctx.fillStyle = '#4a3030'; ctx.fillRect(x-12+lean, y-3+bobY, 3, 12); ctx.fillRect(x+10+lean, y-3+bobY, 3, 12);
        ctx.fillStyle = '#ccaaaa'; ctx.fillRect(x-12+lean, y+7+bobY, 3, 3); ctx.fillRect(x+10+lean, y+7+bobY, 3, 3);
        // Petal head (open flower)
        ctx.fillStyle = '#5a3333'; ctx.fillRect(x-6+lean, y-18+bobY, 12, 13);
        ctx.fillStyle = '#cc6666'; ctx.fillRect(x-5+lean, y-20+bobY, 3, 6); ctx.fillRect(x+3+lean, y-20+bobY, 3, 6);
        ctx.fillRect(x-2+lean, y-21+bobY, 4, 4);
        ctx.fillStyle = '#ff8888'; ctx.fillRect(x-4+lean, y-19+bobY, 2, 4); ctx.fillRect(x+3+lean, y-19+bobY, 2, 4);
        // Inner mouth
        ctx.fillStyle = '#220000'; ctx.fillRect(x-3+lean, y-14+bobY, 6, 6);
        ctx.fillStyle = '#cc0000'; ctx.fillRect(x-2+lean, y-12+bobY, 4, 3);
        if (!p.attacking) { ctx.fillStyle='#ccaaaa'; ctx.fillRect(x+10+lean, y+5+bobY, 3, 5); }
    } else if (charKey === 'alien' && skinKey === 'default') {
        // XENOMORPH - black/dark blue, elongated head, tail
        ctx.fillStyle = '#0a0a1a'; ctx.fillRect(x-8+lean, y-6+bobY, 16, 16);
        ctx.fillStyle = '#1a1a2a'; ctx.fillRect(x-7+lean, y-4+bobY, 14, 12);
        // Ribbed detail
        ctx.fillStyle = '#222233'; ctx.fillRect(x-5+lean, y-3+bobY, 10, 1); ctx.fillRect(x-5+lean, y-1+bobY, 10, 1); ctx.fillRect(x-5+lean, y+1+bobY, 10, 1);
        // Long arms
        ctx.fillStyle = '#0a0a1a'; ctx.fillRect(x-11+lean, y-3+bobY, 3, 12); ctx.fillRect(x+9+lean, y-3+bobY, 3, 12);
        // Elongated dome head
        ctx.fillStyle = '#0a0a1a'; ctx.fillRect(x-4+lean, y-22+bobY, 8, 17);
        ctx.fillStyle = '#111122'; ctx.fillRect(x-3+lean, y-20+bobY, 6, 14);
        // No eyes - smooth
        ctx.fillStyle = '#222233'; ctx.fillRect(x-2+lean, y-12+bobY, 4, 2);
        // Inner jaw/teeth
        ctx.fillStyle = '#cccccc'; ctx.fillRect(x-2+lean, y-9+bobY, 1, 2); ctx.fillRect(x+2+lean, y-9+bobY, 1, 2);
        // Tail
        ctx.fillStyle = '#0a0a1a'; ctx.fillRect(x-14+lean, y+4+bobY, 6, 2); ctx.fillRect(x-16+lean, y+2+bobY, 3, 2);
        if (!p.attacking) { ctx.fillStyle='#333344'; ctx.fillRect(x+9+lean, y+7+bobY, 3, 5); }
    } else if (charKey === 'vecna' && skinKey === 'default') {
        // VECNA - decayed robed lich, one hand raised, tentacles
        ctx.fillStyle = '#1a0a0a'; ctx.fillRect(x-9+lean, y-6+bobY, 18, 18);
        ctx.fillStyle = '#2a1515'; ctx.fillRect(x-8+lean, y-4+bobY, 16, 14);
        // Robes flowing
        ctx.fillStyle = '#110505'; ctx.fillRect(x-9+lean, y+6+bobY, 5, 8); ctx.fillRect(x+5+lean, y+6+bobY, 5, 8);
        // Skeletal arms
        ctx.fillStyle = '#886644'; ctx.fillRect(x-11+lean, y-3+bobY, 2, 10); ctx.fillRect(x+10+lean, y-3+bobY, 2, 10);
        // Decayed head
        ctx.fillStyle = '#553322'; ctx.fillRect(x-5+lean, y-17+bobY, 10, 12);
        ctx.fillStyle = '#443322'; ctx.fillRect(x-4+lean, y-15+bobY, 8, 8);
        // Vine/tentacle on face
        ctx.fillStyle = '#333311'; ctx.fillRect(x+2+lean, y-16+bobY, 2, 8);
        ctx.fillRect(x-3+lean, y-14+bobY, 1, 6);
        // Glowing orange eyes
        ctx.fillStyle = '#ff6600'; ctx.shadowColor='#ff6600'; ctx.shadowBlur=5;
        ctx.fillRect(x-3+lean, y-13+bobY, 2, 2); ctx.fillRect(x+2+lean, y-13+bobY, 2, 2); ctx.shadowBlur=0;
        if (!p.attacking) { ctx.fillStyle='#886644'; ctx.fillRect(x+10+lean, y+0+bobY, 2, 8); }
    } else if (charKey === 'chucky' && skinKey === 'default') {
        // CHUCKY - short! blue overalls, orange hair, knife
        // He's smaller than other killers
        ctx.fillStyle = '#2244aa'; ctx.fillRect(x-7+lean, y-2+bobY, 14, 12);
        ctx.fillStyle = '#3355bb'; ctx.fillRect(x-6+lean, y+0+bobY, 12, 8);
        // Red/striped shirt underneath
        ctx.fillStyle = '#cc3333'; ctx.fillRect(x-5+lean, y-4+bobY, 10, 4);
        ctx.fillStyle = '#aa2222'; ctx.fillRect(x-5+lean, y-3+bobY, 10, 1); ctx.fillRect(x-5+lean, y-1+bobY, 10, 1);
        // Small arms
        ctx.fillStyle = '#ddbb88'; ctx.fillRect(x-8+lean, y-1+bobY, 2, 7); ctx.fillRect(x+7+lean, y-1+bobY, 2, 7);
        // Doll face
        ctx.fillStyle = '#eeccaa'; ctx.fillRect(x-4+lean, y-12+bobY, 8, 9);
        // Wild orange hair
        ctx.fillStyle = '#ff6622'; ctx.fillRect(x-5+lean, y-15+bobY, 10, 5);
        ctx.fillRect(x-5+lean, y-12+bobY, 2, 3); ctx.fillRect(x+4+lean, y-12+bobY, 2, 3);
        // Scar/stitch marks
        ctx.fillStyle = '#884444'; ctx.fillRect(x-2+lean, y-10+bobY, 4, 1);
        // Evil eyes
        ctx.fillStyle = '#4488ff'; ctx.fillRect(x-2+lean, y-9+bobY, 2, 2); ctx.fillRect(x+1+lean, y-9+bobY, 2, 2);
        // Evil smile
        ctx.fillStyle = '#cc0000'; ctx.fillRect(x-2+lean, y-6+bobY, 4, 1);
        if (!p.attacking) { ctx.fillStyle='#cccccc'; ctx.fillRect(x+7+lean, y+2+bobY, 2, 8); }
    } else if (charKey === 'wraith' && skinKey === 'default') {
        // WRAITH - thin spectral, bandaged, skull head, bell weapon
        ctx.fillStyle = '#1a3344'; ctx.fillRect(x-8+lean, y-6+bobY, 16, 16);
        ctx.fillStyle = '#224455'; ctx.fillRect(x-7+lean, y-4+bobY, 14, 12);
        ctx.fillStyle = '#334455'; ctx.fillRect(x-6+lean, y-3+bobY, 12, 1); ctx.fillRect(x-5+lean, y+0+bobY, 10, 1); ctx.fillRect(x-6+lean, y+3+bobY, 12, 1);
        ctx.fillStyle = '#2a4455'; ctx.fillRect(x-10+lean, y-3+bobY, 2, 10); ctx.fillRect(x+9+lean, y-3+bobY, 2, 10);
        ctx.fillStyle = '#445566'; ctx.fillRect(x-5+lean, y-20+bobY, 10, 14);
        ctx.fillStyle = '#334455'; ctx.fillRect(x-4+lean, y-18+bobY, 8, 10);
        ctx.fillStyle = '#000000'; ctx.fillRect(x-3+lean, y-15+bobY, 2, 3); ctx.fillRect(x+2+lean, y-15+bobY, 2, 3);
        ctx.fillStyle = '#112233'; ctx.fillRect(x-1+lean, y-11+bobY, 2, 2);
        ctx.fillStyle='#44ccff'; ctx.shadowColor='#44ccff'; ctx.shadowBlur=4;
        ctx.fillRect(x-2+lean, y-15+bobY, 1, 1); ctx.fillRect(x+2+lean, y-15+bobY, 1, 1); ctx.shadowBlur=0;
        if (!p.attacking) { ctx.fillStyle='#667788'; ctx.fillRect(x+9+lean, y-8+bobY, 3, 14); ctx.fillStyle='#aabbcc'; ctx.fillRect(x+9+lean, y-8+bobY, 3, 3); }
    } else if (charKey === 'nurse' && skinKey === 'default') {
        // NURSE - dirty white dress, bandaged head, floating feel
        ctx.fillStyle = '#888888'; ctx.fillRect(x-9+lean, y-6+bobY, 18, 18);
        ctx.fillStyle = '#aaaaaa'; ctx.fillRect(x-8+lean, y-4+bobY, 16, 14);
        ctx.fillStyle = '#999999'; ctx.fillRect(x-8+lean, y+6+bobY, 16, 6);
        // Blood stains on dress
        ctx.fillStyle = '#663333'; ctx.fillRect(x-5+lean, y+2+bobY, 4, 3); ctx.fillRect(x+2+lean, y+4+bobY, 3, 4);
        // Bandaged head
        ctx.fillStyle = '#bbbbaa'; ctx.fillRect(x-5+lean, y-17+bobY, 10, 12);
        ctx.fillStyle = '#999988'; ctx.fillRect(x-4+lean, y-15+bobY, 8, 8);
        // One eye peeking
        ctx.fillStyle = '#000000'; ctx.fillRect(x+1+lean, y-13+bobY, 2, 2);
        // Bandage wrap lines
        ctx.fillStyle = '#888877'; ctx.fillRect(x-4+lean, y-16+bobY, 8, 1); ctx.fillRect(x-4+lean, y-12+bobY, 8, 1);
        ctx.fillStyle='#88aaff'; ctx.shadowColor='#88aaff'; ctx.shadowBlur=4;
        ctx.fillRect(x+1+lean, y-13+bobY, 1, 1); ctx.shadowBlur=0;
        if (!p.attacking) { ctx.fillStyle='#666666'; ctx.fillRect(x+9+lean, y-4+bobY, 2, 10); }
    } else if (charKey === 'hillbilly' && skinKey === 'default') {
        // HILLBILLY - shirtless, deformed, overalls, chainsaw
        ctx.fillStyle = '#4a3a22'; ctx.fillRect(x-10+lean, y-6+bobY, 20, 16);
        ctx.fillStyle = '#5a4a33'; ctx.fillRect(x-9+lean, y-4+bobY, 18, 12);
        // Bare chest/deformed skin
        ctx.fillStyle = '#886644'; ctx.fillRect(x-7+lean, y-4+bobY, 14, 8);
        ctx.fillStyle = '#664422'; ctx.fillRect(x-4+lean, y-2+bobY, 2, 4); ctx.fillRect(x+3+lean, y-1+bobY, 2, 3);
        // Overall straps
        ctx.fillStyle = '#333322'; ctx.fillRect(x-7+lean, y-5+bobY, 2, 12); ctx.fillRect(x+6+lean, y-5+bobY, 2, 12);
        // Deformed head
        ctx.fillStyle = '#775544'; ctx.fillRect(x-6+lean, y-17+bobY, 12, 12);
        ctx.fillStyle = '#664433'; ctx.fillRect(x-5+lean, y-15+bobY, 10, 8);
        // Deformed features
        ctx.fillStyle = '#443322'; ctx.fillRect(x+2+lean, y-15+bobY, 4, 4); // bulge
        ctx.fillStyle = '#ffaa00'; ctx.shadowColor='#ffaa00'; ctx.shadowBlur=3;
        ctx.fillRect(x-3+lean, y-12+bobY, 2, 2); ctx.fillRect(x+1+lean, y-13+bobY, 2, 2); ctx.shadowBlur=0;
        if (!p.attacking) { ctx.fillStyle='#888888'; ctx.fillRect(x+10+lean, y-6+bobY, 4, 14); ctx.fillStyle='#cc8800'; ctx.fillRect(x+10+lean, y-2+bobY, 4, 4); ctx.fillStyle='#666666'; ctx.fillRect(x+11+lean, y+6+bobY, 2, 4); }
    } else {
        // Generic/skin killer body
        ctx.fillStyle = secColor; ctx.fillRect(x - 10 + lean, y - 6 + bobY, 20, 16);
        ctx.fillStyle = mainColor; ctx.fillRect(x - 9 + lean, y - 4 + bobY, 18, 12);
        ctx.fillStyle = mainColor; ctx.fillRect(x - 6 + lean, y - 16 + bobY, 12, 11);
        ctx.fillStyle = '#000000'; ctx.fillRect(x - 5 + lean, y - 14 + bobY, 10, 7);
        if (!p.attacking) { ctx.fillStyle = weapColor; ctx.fillRect(x + 9 + lean, y - 8 + bobY, 3, 14); }
    }
    
    // ====== EYES (default killers without skin override) ======
    if (skinKey === 'default') {
        let eyeFlicker = Math.sin(gameTimer * 0.1) * 0.2 + 0.8;
        ctx.fillStyle = '#ff0000'; ctx.shadowColor = '#ff0000'; ctx.shadowBlur = 5 * eyeFlicker;
        ctx.fillRect(x - 3 + lean, y - 12 + bobY, 2, 2); ctx.fillRect(x + 2 + lean, y - 12 + bobY, 2, 2);
        ctx.shadowBlur = 0;
    }
    
    // ====== ATTACK ANIMATION (all killers) ======
    if (p.attacking) {
        let swing = p.attackTimer / p.charData.attackDuration;
        ctx.fillStyle = weapColor; ctx.shadowColor = weapColor; ctx.shadowBlur = 8;
        switch (p.facing) {
            case 0: ctx.fillRect(x - 2, y + 14, 4, 14 + swing * 6); break;
            case 1: ctx.fillRect(x - 2, y - 28 - swing * 6, 4, 14); break;
            case 2: ctx.fillRect(x - 20 - swing * 6, y - 2 + bobY, 14 + swing * 6, 4); break;
            case 3: ctx.fillRect(x + 8, y - 2 + bobY, 14 + swing * 6, 4); break;
        }
        ctx.shadowBlur = 0;
        // Slash trail
        if (p.attackTimer > p.charData.attackDuration - 4) {
            ctx.fillStyle = '#ffffff22';
            switch (p.facing) { case 0: ctx.fillRect(x - 6, y + 16, 12, 3); break; case 1: ctx.fillRect(x - 6, y - 22, 12, 3); break; case 2: ctx.fillRect(x - 18, y - 4, 3, 12); break; case 3: ctx.fillRect(x + 16, y - 4, 3, 12); break; }
        }
    }
    
    // ====== ABILITY EFFECTS ======
    if (p.stealthActive) {
        ctx.fillStyle = glowCol + '18'; ctx.fillRect(x - 12, y - 20, 24, 36);
        if (gameTimer % 6 < 3) { ctx.fillStyle = glowCol + '0a'; ctx.fillRect(x - 12, y - 18 + (gameTimer % 36), 24, 2); }
    }
    if (p.abilityActive > 0 && cd.ability === 'charge') {
        for (let i = 0; i < 3; i++) { ctx.fillStyle = '#ff440033'; ctx.fillRect(x - 14 - i * 5, y - 2 + i * 3 + bobY, 5, 3); }
    }
    if (p.abilityActive > 0 && cd.ability === 'frenzy') {
        ctx.fillStyle = '#ff110015'; ctx.fillRect(x - 14, y - 20, 28, 36);
        ctx.fillStyle = '#ff4400'; ctx.shadowColor = '#ff4400'; ctx.shadowBlur = 8;
        ctx.fillRect(x - 3 + lean, y - 12 + bobY, 2, 3); ctx.fillRect(x + 2 + lean, y - 12 + bobY, 2, 3);
        ctx.shadowBlur = 0;
    }
}

function drawSurvivorDetailed(p, x, y, bobY, lean, armSwing, breathe) {
    let cd = p.charData, sk = p.skinData;
    let shirtCol = sk?.shirtColor || cd.shirtColor;
    let secCol = sk?.secondaryColor || cd.secondaryColor;
    let hairCol = sk?.color || cd.color;
    let skinTone = '#ddb088';
    let skinKey = p.skin;
    let charKey = p.charKey;
    
    // ====== LEGS ======
    let legAnim = Math.sin(gameTimer * 0.22) * (p.isRunning ? 4 : 0);
    ctx.fillStyle = '#222244';
    ctx.fillRect(x - 5 + lean, y + 8 + bobY, 4, 7 + legAnim);
    ctx.fillRect(x + 1 + lean, y + 8 + bobY, 4, 7 - legAnim);
    // Shoes
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(x - 6 + lean, y + 14 + bobY + legAnim, 5, 3);
    ctx.fillRect(x + lean, y + 14 + bobY - legAnim, 5, 3);
    ctx.fillStyle = '#ffffff08';
    ctx.fillRect(x - 6 + lean, y + 14 + bobY + legAnim, 5, 1);
    ctx.fillRect(x + lean, y + 14 + bobY - legAnim, 5, 1);
    
    // ====== CHARACTER-SPECIFIC BODY ======
    if (charKey === 'meg' && skinKey === 'default') {
        // MEG THOMAS - red tank top, athletic, brown ponytail
        ctx.fillStyle = '#661122'; ctx.fillRect(x-7+lean, y-4+bobY, 14, 13);
        ctx.fillStyle = '#cc3344'; ctx.fillRect(x-6+lean, y-2+bobY, 12, 9);
        ctx.fillStyle = skinTone; ctx.fillRect(x-8+lean, y-1+bobY, 2, 7); ctx.fillRect(x+7+lean, y-1+bobY, 2, 7);
        ctx.fillStyle = skinTone; ctx.fillRect(x-4+lean, y-13+bobY, 8, 10);
        ctx.fillStyle = '#553322'; ctx.fillRect(x-5+lean, y-16+bobY, 10, 5);
        ctx.fillStyle = '#553322'; ctx.fillRect(x+4+lean, y-13+bobY, 2, 7); // ponytail
    } else if (charKey === 'claudette' && skinKey === 'default') {
        // CLAUDETTE - green cardigan, dark skin, curly dark hair
        ctx.fillStyle = '#2a4a2a'; ctx.fillRect(x-7+lean, y-4+bobY, 14, 13);
        ctx.fillStyle = '#4a7a4a'; ctx.fillRect(x-6+lean, y-2+bobY, 12, 9);
        ctx.fillStyle = '#8a6644'; ctx.fillRect(x-8+lean, y-1+bobY, 2, 7); ctx.fillRect(x+7+lean, y-1+bobY, 2, 7);
        ctx.fillStyle = '#8a6644'; ctx.fillRect(x-4+lean, y-13+bobY, 8, 10);
        ctx.fillStyle = '#1a0a00'; ctx.fillRect(x-5+lean, y-16+bobY, 10, 6);
        ctx.fillRect(x-5+lean, y-13+bobY, 2, 3); ctx.fillRect(x+4+lean, y-13+bobY, 2, 3);
    } else if (charKey === 'dwight' && skinKey === 'default') {
        // DWIGHT - white shirt, tie, glasses, dark hair
        ctx.fillStyle = '#333333'; ctx.fillRect(x-7+lean, y-4+bobY, 14, 13);
        ctx.fillStyle = '#eeeeee'; ctx.fillRect(x-6+lean, y-2+bobY, 12, 9);
        ctx.fillStyle = '#cc2222'; ctx.fillRect(x+lean, y-2+bobY, 1, 7); // tie
        ctx.fillStyle = skinTone; ctx.fillRect(x-8+lean, y-1+bobY, 2, 7); ctx.fillRect(x+7+lean, y-1+bobY, 2, 7);
        ctx.fillStyle = skinTone; ctx.fillRect(x-4+lean, y-13+bobY, 8, 10);
        ctx.fillStyle = '#1a1a1a'; ctx.fillRect(x-5+lean, y-16+bobY, 10, 5);
        // Glasses
        ctx.fillStyle = '#444444'; ctx.fillRect(x-3+lean, y-10+bobY, 3, 2); ctx.fillRect(x+1+lean, y-10+bobY, 3, 2);
        ctx.fillStyle = '#aaddff'; ctx.fillRect(x-2+lean, y-10+bobY, 2, 2); ctx.fillRect(x+1+lean, y-10+bobY, 2, 2);
    } else if (charKey === 'nea' && skinKey === 'default') {
        // NEA - grey/blue hoodie, beanie, urban style
        ctx.fillStyle = '#333344'; ctx.fillRect(x-7+lean, y-4+bobY, 14, 13);
        ctx.fillStyle = '#556677'; ctx.fillRect(x-6+lean, y-2+bobY, 12, 9);
        ctx.fillStyle = '#556677'; ctx.fillRect(x-8+lean, y-2+bobY, 2, 7); ctx.fillRect(x+7+lean, y-2+bobY, 2, 7);
        ctx.fillStyle = skinTone; ctx.fillRect(x-4+lean, y-13+bobY, 8, 10);
        // Beanie
        ctx.fillStyle = '#222233'; ctx.fillRect(x-5+lean, y-16+bobY, 10, 4);
        ctx.fillStyle = '#333344'; ctx.fillRect(x-5+lean, y-13+bobY, 10, 1);
        // Purple streaks
        ctx.fillStyle = '#6644aa'; ctx.fillRect(x-4+lean, y-12+bobY, 2, 4); ctx.fillRect(x+3+lean, y-12+bobY, 2, 4);
    } else if (charKey === 'jake' && skinKey === 'default') {
        // JAKE PARK - green flannel, outdoorsy, black hair
        ctx.fillStyle = '#2a3a2a'; ctx.fillRect(x-7+lean, y-4+bobY, 14, 13);
        ctx.fillStyle = '#3a5a3a'; ctx.fillRect(x-6+lean, y-2+bobY, 12, 9);
        ctx.fillStyle = '#2a4a2a'; ctx.fillRect(x-5+lean, y-1+bobY, 1, 7); ctx.fillRect(x-2+lean, y-1+bobY, 1, 7); ctx.fillRect(x+1+lean, y-1+bobY, 1, 7); ctx.fillRect(x+4+lean, y-1+bobY, 1, 7);
        ctx.fillStyle = skinTone; ctx.fillRect(x-8+lean, y+0+bobY, 2, 7); ctx.fillRect(x+7+lean, y+0+bobY, 2, 7);
        ctx.fillStyle = '#eeccaa'; ctx.fillRect(x-4+lean, y-13+bobY, 8, 10);
        ctx.fillStyle = '#1a1a1a'; ctx.fillRect(x-5+lean, y-16+bobY, 10, 5);
        ctx.fillRect(x-5+lean, y-13+bobY, 2, 3); ctx.fillRect(x+4+lean, y-13+bobY, 2, 3);
    } else if (charKey === 'feng' && skinKey === 'default') {
        // FENG MIN - purple gamer hoodie, headphones, asian
        ctx.fillStyle = '#2a2a4a'; ctx.fillRect(x-7+lean, y-4+bobY, 14, 13);
        ctx.fillStyle = '#6644aa'; ctx.fillRect(x-6+lean, y-2+bobY, 12, 9);
        ctx.fillStyle = '#5533aa'; ctx.fillRect(x-8+lean, y-2+bobY, 2, 6); ctx.fillRect(x+7+lean, y-2+bobY, 2, 6);
        ctx.fillStyle = '#eeccaa'; ctx.fillRect(x-8+lean, y+4+bobY, 2, 4); ctx.fillRect(x+7+lean, y+4+bobY, 2, 4);
        ctx.fillStyle = '#eeccaa'; ctx.fillRect(x-4+lean, y-13+bobY, 8, 10);
        ctx.fillStyle = '#1a0a1a'; ctx.fillRect(x-5+lean, y-16+bobY, 10, 5);
        // Headphones
        ctx.fillStyle = '#cc44ff'; ctx.fillRect(x-6+lean, y-12+bobY, 2, 4); ctx.fillRect(x+5+lean, y-12+bobY, 2, 4);
        ctx.fillStyle = '#aa33dd'; ctx.fillRect(x-5+lean, y-15+bobY, 10, 2);
    } else {
        // Generic / skin body
        ctx.fillStyle = secCol; ctx.fillRect(x - 7 + lean, y - 4 + bobY, 14, 13);
        ctx.fillStyle = shirtCol; ctx.fillRect(x - 6 + lean, y - 2 + bobY, 12, 9);
        ctx.fillStyle = skinTone; ctx.fillRect(x - 8 + lean, y - 1 + bobY, 2, 8); ctx.fillRect(x + 7 + lean, y - 1 + bobY, 2, 8);
        ctx.fillStyle = skinTone; ctx.fillRect(x - 4 + lean, y - 13 + bobY, 8, 10);
        ctx.fillStyle = hairCol; ctx.fillRect(x - 5 + lean, y - 15 + bobY, 10, 4);
    }
    
    // ====== FACE DETAILS (default skins) ======
    if (skinKey === 'default') {
        // Eyes
        ctx.fillStyle = '#ffffff'; ctx.fillRect(x - 3 + lean, y - 9 + bobY, 3, 2); ctx.fillRect(x + 1 + lean, y - 9 + bobY, 3, 2);
        ctx.fillStyle = '#222222'; ctx.fillRect(x - 2 + lean, y - 9 + bobY, 2, 2); ctx.fillRect(x + 2 + lean, y - 9 + bobY, 2, 2);
        // Blink
        if (gameTimer % 200 > 196) { ctx.fillStyle = skinTone; ctx.fillRect(x - 3 + lean, y - 9 + bobY, 6, 2); }
        // Mouth
        ctx.fillStyle = '#aa7766'; ctx.fillRect(x - 1 + lean, y - 6 + bobY, 2, 1);
    }
    
    // ====== INJURED BLOOD ======
    if (p.injured) {
        ctx.fillStyle = '#990000aa'; ctx.fillRect(x - 4 + lean, y + 1 + bobY, 3, 4);
        ctx.fillStyle = '#66000066'; ctx.fillRect(x - 5 + lean, y + 3 + bobY, 2, 3);
        let drip = (gameTimer * 0.04) % 1;
        ctx.fillStyle = `rgba(150,0,0,${0.6 - drip * 0.6})`; ctx.fillRect(x - 3 + lean, y + 5 + bobY + drip * 8, 2, 2);
    }
    
    // ====== HELD ITEM on character ======
    if (p.heldItem === 'medkit') {
        ctx.fillStyle = '#ffffff'; ctx.fillRect(x + 8 + lean, y + 3 + bobY, 5, 4);
        ctx.fillStyle = '#ff0000'; ctx.fillRect(x + 9 + lean, y + 3 + bobY, 3, 4); ctx.fillRect(x + 8 + lean, y + 4 + bobY, 5, 2);
    } else if (p.heldItem === 'flashlight') {
        ctx.fillStyle = '#444444'; ctx.fillRect(x + 8 + lean, y + 1 + bobY, 2, 7);
        ctx.fillStyle = '#666666'; ctx.fillRect(x + 7 + lean, y + 0 + bobY, 4, 2);
        ctx.fillStyle = '#ffff4433'; ctx.beginPath(); ctx.arc(x + 9 + lean, y - 1 + bobY, 3, 0, Math.PI * 2); ctx.fill();
    }
    
    // Ability glow
    if (p.abilityActive > 0) {
        ctx.fillStyle = cd.glowColor + '18'; ctx.beginPath(); ctx.arc(x, y, 14, 0, Math.PI * 2); ctx.fill();
    }
}

function drawGameInfo() {
    const info = document.getElementById('game-info');
    let survivors = players.filter(p => p.role === 'survivor');
    let alive = survivors.filter(p => p.alive && !p.escaped).length;
    let escaped = survivors.filter(p => p.escaped).length;
    info.textContent = `Vivos: ${alive} | Escaparam: ${escaped} | Portões: ${gatesOpen ? 'ABERTOS' : 'Fechados'}`;
}

// ============================================================
// GAME LOOP
// ============================================================
function gameLoop() {
    update();
    render();
    requestAnimationFrame(gameLoop);
}

// ============================================================
// RESPONSIVE CANVAS
// ============================================================
function resizeCanvas() {
    if (gameState === GAME_STATES.PLAYING || gameState === GAME_STATES.ENDED) {
        const maxW = window.innerWidth;
        const maxH = window.innerHeight;
        const ratio = Math.min(maxW / VIEW_W, maxH / VIEW_H);
        canvas.style.width = (VIEW_W * ratio) + 'px';
        canvas.style.height = (VIEW_H * ratio) + 'px';
    }
    
    // Resize menu canvases
    const menuBg = document.getElementById('menu-bg-canvas');
    if (menuBg) { menuBg.width = window.innerWidth; menuBg.height = window.innerHeight; }
    const lobbyBg = document.getElementById('lobby-bg-canvas');
    if (lobbyBg) { lobbyBg.width = window.innerWidth; lobbyBg.height = window.innerHeight; }
}

window.addEventListener('resize', resizeCanvas);

// ============================================================
// INITIALIZATION
// ============================================================
window.addEventListener('DOMContentLoaded', () => {
    resizeCanvas();
    initMenuBackground();
    if (isMobile) initMobileControls();
    if (typeof updateProfileUI === 'function') updateProfileUI();
    gameLoop();
});
