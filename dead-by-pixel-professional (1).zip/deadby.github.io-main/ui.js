// ============================================================
// DEAD BY PIXEL - LOBBY SIDEBAR UI
// Icons on left side of lobby. Click to open panels.
// No separate fullscreen. Panels overlay on lobby.
// ============================================================

let csRole = 'survivor';
let csChar = 'meg';
let csItem = null;
let csActivePanel = null;
let csPreviewFrame = 0;
let csPreviewInterval = null;

const CS_ITEMS = [
    { key: null, icon: '—', name: 'Nenhum' },
    { key: 'medkit', icon: '🩹', name: 'Kit Médico' },
    { key: 'flashlight', icon: '🔦', name: 'Lanterna' }
];

function openCharSelect() {
    csRole = document.getElementById('my-role-select')?.value || 'survivor';
    csChar = document.getElementById('my-char-select')?.value || 'meg';
    if (!csActivePanel) csActivePanel = 'chars';
    let screen = document.getElementById('char-select-screen');
    if (screen) screen.style.display = 'block';
    renderLobbyUI();
}

function renderLobbyUI() {
    let screen = document.getElementById('char-select-screen');
    if (!screen) return;
    screen.style.display = 'block';
    
    let chars = csRole === 'killer' ? KILLERS : SURVIVORS;
    let perks = csRole === 'killer' ? KILLER_PERKS : SURVIVOR_PERKS;
    let unlocked = csRole === 'killer' ? (playerProfile?.unlockedKillers || Object.keys(chars)) : (playerProfile?.unlockedSurvivors || Object.keys(chars));
    let equipped = selectedPerks[csRole] || [];
    let charData = chars[csChar];

    // Show the overlay
    screen.style.display = 'block';

    screen.innerHTML = `
        <!-- Sidebar icons -->
        <div class="cs-sidebar">
            <div class="cs-sidebar-icon ${csActivePanel==='chars'?'active':''}" onclick="csToggle('chars')" title="Personagens">👤</div>
            <div class="cs-sidebar-icon ${csActivePanel==='loadout'?'active':''}" onclick="csToggle('loadout')" title="Loadout/Perks">⚔️</div>
            <div class="cs-sidebar-icon ${csActivePanel==='customize'?'active':''}" onclick="csToggle('customize')" title="Customizar">🎨</div>
            <div class="cs-sidebar-icon" onclick="csSwapRole()" title="Trocar Role">${csRole==='killer'?'🏃':'🔪'}</div>
            <div class="cs-sidebar-icon" onclick="closeLobbyUI()" title="Fechar" style="margin-top:auto;border-color:#660000;">✕</div>
        </div>

        ${csActivePanel === 'chars' ? `
        <div class="cs-panel open">
            <h3>${csRole==='killer'?'🔪 KILLERS':'🏃 SURVIVORS'}</h3>
            <div class="cs-char-grid">
                ${Object.entries(chars).map(([key, d]) => {
                    let ok = unlocked.includes(key);
                    let sel = key === csChar;
                    let cl = typeof getCharLevel === 'function' ? getCharLevel(key) : {level:1,xp:0};
                    return `<div class="cs-char-card ${sel?'selected':''} ${!ok?'locked':''}" onclick="${ok?`csPickC('${key}')`:''}" title="${d.name} - ${d.desc}">
                        <canvas id="csp-${key}" width="36" height="44"></canvas>
                        <div class="cs-card-name">${d.name}</div>
                        ${ok?`<div style="font-size:0.45em;color:#aa88ff;">Lv.${cl.level}</div>`:''}
                    </div>`;
                }).join('')}
            </div>
        </div>` : ''}

        ${csActivePanel === 'loadout' ? `
        <div class="cs-panel open">
            <h3>LOADOUT — ${charData?.name || ''}</h3>
            <div style="font-size:0.7em;color:#888;margin-bottom:8px;letter-spacing:1px;">ITEM PRA LEVAR</div>
            <div class="cs-loadout-row">
                ${CS_ITEMS.map(it => `<div class="cs-loadout-slot item-slot ${csItem===it.key?'filled':''}" onclick="csPickI(${it.key?`'${it.key}'`:'null'})"><span>${it.icon}</span></div>`).join('')}
            </div>
            <div style="font-size:0.7em;color:#888;margin:14px 0 8px;letter-spacing:1px;">PERKS (${equipped.length}/2)</div>
            <div class="cs-loadout-row" style="gap:14px;">
                ${[0,1].map(i => { let pk=equipped[i]; let p=pk?perks[pk]:null; return `<div class="cs-loadout-slot perk ${p?'filled':''}"><span>${p?p.icon:'+'}</span></div>`; }).join('')}
            </div>
            <div style="font-size:0.65em;color:#555;margin:12px 0 4px;letter-spacing:1px;">SELECIONAR PERK</div>
            <div class="cs-picker-grid">
                ${Object.entries(perks).map(([k,p]) => {
                    let r = typeof RARITY !== 'undefined' && p.rarity ? RARITY[p.rarity] : {color:'#888',border:'#444'};
                    let isEq = equipped.includes(k);
                    return `<div class="cs-picker-item ${isEq?'equipped':''}" onclick="csPerk('${k}')" title="${p.name}: ${p.desc}&#10;${r.name||''}" style="${!isEq?'border-color:'+r.border+';':''}"><span>${p.icon}</span></div>`;
                }).join('')}
            </div>
            <div style="margin-top:14px;padding:10px;background:#1a0a00;border:2px solid #2a1a08;">
                <div style="font-size:0.7em;color:#ffaa00;">⚡ ${charData?.ability?.toUpperCase()||'—'} (${Math.round((charData?.abilityCD||0)/60)}s)</div>
                <div style="font-size:0.65em;color:#666;margin-top:3px;">${charData?.desc||''}</div>
            </div>
        </div>` : ''}

        ${csActivePanel === 'customize' ? renderCustomizePanel() : ''}
    `;

    // Draw portraits
    if (csActivePanel === 'chars') {
        setTimeout(() => {
            for (let [key, d] of Object.entries(chars)) drawPort(key, d, key===csChar);
        }, 10);
    }
}

function csToggle(panel) { csActivePanel = (csActivePanel===panel) ? null : panel; renderLobbyUI(); if(panel==='customize'&&csActivePanel==='customize'){setTimeout(()=>{drawCustomizePreview();startCustomizePreview();renderSkinsRow();},30);} }
function csSwapRole() { csRole = csRole==='killer'?'survivor':'killer'; let chars=csRole==='killer'?KILLERS:SURVIVORS; let u=csRole==='killer'?(playerProfile?.unlockedKillers||Object.keys(chars)):(playerProfile?.unlockedSurvivors||Object.keys(chars)); csChar=u[0]||Object.keys(chars)[0]; document.getElementById('my-role-select').value=csRole; onRoleChange(); renderLobbyUI(); }

function switchToKiller() {
    csRole = 'killer';
    let chars = KILLERS;
    let u = playerProfile?.unlockedKillers || Object.keys(chars);
    csChar = u[0] || 'trapper';
    document.getElementById('my-role-select').value = 'killer';
    if (typeof onRoleChange === 'function') onRoleChange();
    // Visual feedback
    document.getElementById('lobby-killer-btn').style.borderColor = '#ff4444';
    document.getElementById('lobby-surv-btn').style.borderColor = '#004400';
    // Close char-select overlay if open
    closeLobbyUI();
}

function switchToSurvivor() {
    csRole = 'survivor';
    let chars = SURVIVORS;
    let u = playerProfile?.unlockedSurvivors || Object.keys(chars);
    csChar = u[0] || 'meg';
    document.getElementById('my-role-select').value = 'survivor';
    if (typeof onRoleChange === 'function') onRoleChange();
    // Visual feedback
    document.getElementById('lobby-surv-btn').style.borderColor = '#44ff44';
    document.getElementById('lobby-killer-btn').style.borderColor = '#660000';
    // Close char-select overlay if open
    closeLobbyUI();
}
function csPickC(key) { csChar=key; document.getElementById('my-char-select').value=key; onCharChange(); renderLobbyUI(); }
function csPickI(key) { csItem=key; renderLobbyUI(); }
function csPerk(key) { let p=selectedPerks[csRole]; if(p.includes(key)){selectedPerks[csRole]=p.filter(k=>k!==key);}else{if(p.length>=2)p.shift();p.push(key);} renderLobbyUI(); }

function closeLobbyUI() {
    document.getElementById('char-select-screen').style.display = 'none';
    csActivePanel = null;
}

function drawPort(key, data, selected) {
    let cv = document.getElementById(`csp-${key}`);
    if (!cv) return;
    let c = cv.getContext('2d');
    c.clearRect(0, 0, 36, 44);
    c.fillStyle = selected ? '#1a1508' : '#060604';
    c.fillRect(0, 0, 36, 44);

    if (csRole === 'killer') {
        drawKillerPortrait(c, key, data);
    } else {
        drawSurvivorPortrait(c, key, data);
    }
}

function drawKillerPortrait(c, key, data) {
    let mc = data.color || '#444';
    let sc = data.secondaryColor || '#222';
    let gc = data.glowColor || '#ff0000';
    let wc = data.weaponColor || '#888';
    
    // Body base
    c.fillStyle = sc; c.fillRect(8, 24, 20, 18);
    c.fillStyle = mc; c.fillRect(10, 26, 16, 14);
    
    switch(key) {
        case 'trapper':
            // Trapper mask with straps, broad shoulders
            c.fillStyle = '#6a5a38'; c.fillRect(9, 4, 18, 18);
            c.fillStyle = '#aa9966'; c.fillRect(11, 6, 14, 14);
            // Mask details - straps
            c.fillStyle = '#3a2a10'; c.fillRect(9, 10, 2, 8); c.fillRect(25, 10, 2, 8);
            // Eye holes (dark, angular)
            c.fillStyle = '#000'; c.fillRect(13, 11, 4, 4); c.fillRect(19, 11, 4, 4);
            // Glowing eyes inside
            c.fillStyle = gc; c.fillRect(14, 12, 2, 2); c.fillRect(20, 12, 2, 2);
            // Mouth area (grill/slits)
            c.fillStyle = '#2a2008'; c.fillRect(14, 17, 8, 3);
            c.fillStyle = '#000'; c.fillRect(15, 18, 2, 1); c.fillRect(18, 18, 2, 1); c.fillRect(21, 18, 1, 1);
            // Weapon: cleaver on side
            c.fillStyle = wc; c.fillRect(28, 14, 3, 12);
            c.fillStyle = '#bbb'; c.fillRect(28, 14, 1, 12);
            break;
        case 'wraith':
            // Wraith skull-like head, tattered robes, bell
            c.fillStyle = '#1a3344'; c.fillRect(8, 24, 20, 18); // dark robes
            c.fillStyle = '#224455'; c.fillRect(10, 26, 16, 14);
            // Elongated skull head
            c.fillStyle = '#2a4455'; c.fillRect(10, 2, 16, 20);
            c.fillStyle = '#3a5566'; c.fillRect(12, 4, 12, 16);
            // Sunken eye sockets
            c.fillStyle = '#000'; c.fillRect(13, 9, 4, 4); c.fillRect(19, 9, 4, 4);
            // Glowing cyan eyes
            c.fillStyle = '#44ccff'; c.fillRect(14, 10, 2, 2); c.fillRect(20, 10, 2, 2);
            // Jaw/teeth area
            c.fillStyle = '#1a3344'; c.fillRect(14, 16, 8, 4);
            c.fillStyle = '#446677'; c.fillRect(15, 16, 1, 2); c.fillRect(17, 16, 1, 2); c.fillRect(19, 16, 1, 2); c.fillRect(21, 16, 1, 2);
            // Bell in hand
            c.fillStyle = '#8899aa'; c.fillRect(28, 20, 4, 6);
            c.fillStyle = '#aabbcc'; c.fillRect(29, 18, 2, 3);
            break;
        case 'huntress':
            // Bunny mask with long ears, hatchet
            c.fillStyle = '#3a5a3a'; c.fillRect(8, 24, 20, 18);
            c.fillStyle = '#4a6a4a'; c.fillRect(10, 26, 16, 14);
            // Bunny mask - white with ears
            c.fillStyle = '#eeeedd'; c.fillRect(10, 8, 16, 14);
            c.fillStyle = '#ddddcc'; c.fillRect(12, 10, 12, 10);
            // EARS (tall, distinctive)
            c.fillStyle = '#eeeedd'; c.fillRect(12, 0, 4, 10); c.fillRect(20, 0, 4, 10);
            // Ear inner (pink)
            c.fillStyle = '#ffbbbb'; c.fillRect(13, 1, 2, 8); c.fillRect(21, 1, 2, 8);
            // Eye holes
            c.fillStyle = '#000'; c.fillRect(13, 13, 3, 3); c.fillRect(20, 13, 3, 3);
            c.fillStyle = gc; c.fillRect(14, 14, 1, 1); c.fillRect(21, 14, 1, 1);
            // Hatchet
            c.fillStyle = '#555'; c.fillRect(28, 10, 2, 10);
            c.fillStyle = '#888'; c.fillRect(26, 8, 6, 4);
            break;
        case 'nurse':
            // Cloth-wrapped head, nurse dress, bonesaw
            c.fillStyle = '#888'; c.fillRect(8, 24, 20, 18);
            c.fillStyle = '#999'; c.fillRect(10, 26, 16, 14);
            // Bandaged/veiled head
            c.fillStyle = '#ccccbb'; c.fillRect(10, 4, 16, 18);
            c.fillStyle = '#bbbbaa'; c.fillRect(12, 6, 12, 14);
            // Bandage wrap lines
            c.fillStyle = '#999988'; c.fillRect(11, 7, 14, 1); c.fillRect(11, 10, 14, 1); c.fillRect(11, 13, 14, 1); c.fillRect(11, 16, 14, 1);
            // One glowing eye visible through bandage
            c.fillStyle = '#88aaff'; c.fillRect(19, 11, 3, 2);
            // Bonesaw
            c.fillStyle = '#666'; c.fillRect(28, 16, 2, 12);
            break;
        case 'hillbilly':
            // Deformed face, overalls, chainsaw
            c.fillStyle = '#5a4422'; c.fillRect(8, 24, 20, 18);
            c.fillStyle = '#886644'; c.fillRect(10, 26, 16, 14);
            // Deformed head (asymmetrical)
            c.fillStyle = '#775544'; c.fillRect(10, 4, 16, 18);
            c.fillStyle = '#664433'; c.fillRect(12, 6, 12, 14);
            // Deformed bulge on right side
            c.fillStyle = '#554433'; c.fillRect(22, 6, 4, 8);
            // Eyes (one bigger, asymmetric)
            c.fillStyle = gc; c.fillRect(13, 12, 3, 2); c.fillRect(20, 11, 2, 3);
            // Teeth/grimace
            c.fillStyle = '#ddd'; c.fillRect(15, 17, 6, 2);
            c.fillStyle = '#000'; c.fillRect(16, 17, 1, 2); c.fillRect(18, 17, 1, 2); c.fillRect(20, 17, 1, 2);
            // Chainsaw
            c.fillStyle = '#777'; c.fillRect(27, 20, 5, 4);
            c.fillStyle = '#cc8800'; c.fillRect(27, 24, 5, 3);
            c.fillStyle = '#555'; c.fillRect(30, 26, 2, 8);
            break;
        case 'demogorgon':
            // Flower-petal head (open mouth), muscular body
            c.fillStyle = '#3a2525'; c.fillRect(8, 24, 20, 18);
            c.fillStyle = '#4a3535'; c.fillRect(10, 26, 16, 14);
            // Petal head (opens like flower)
            c.fillStyle = '#4a2a2a'; c.fillRect(10, 6, 16, 16);
            // Petals around head
            c.fillStyle = '#cc6666'; c.fillRect(10, 2, 4, 6); c.fillRect(16, 0, 4, 6); c.fillRect(22, 2, 4, 6);
            c.fillStyle = '#dd7777'; c.fillRect(8, 8, 3, 5); c.fillRect(25, 8, 3, 5);
            // Inner mouth (dark void with teeth)
            c.fillStyle = '#110000'; c.fillRect(13, 10, 10, 8);
            c.fillStyle = '#cc0000'; c.fillRect(14, 12, 8, 4);
            // Teeth
            c.fillStyle = '#ddd'; c.fillRect(14, 10, 1, 2); c.fillRect(16, 10, 1, 2); c.fillRect(18, 10, 1, 2); c.fillRect(20, 10, 1, 2); c.fillRect(22, 10, 1, 2);
            break;
        case 'alien':
            // Xenomorph elongated head, tail, dark
            c.fillStyle = '#0a0a18'; c.fillRect(8, 24, 20, 18);
            c.fillStyle = '#111125'; c.fillRect(10, 26, 16, 14);
            // Long elongated dome head
            c.fillStyle = '#0a0a18'; c.fillRect(12, 0, 12, 22);
            c.fillStyle = '#111125'; c.fillRect(13, 2, 10, 18);
            // Head extends back (dome)
            c.fillStyle = '#0a0a18'; c.fillRect(10, 4, 4, 8);
            // No visible eyes (smooth dome)
            // Inner jaw/mouth
            c.fillStyle = '#333355'; c.fillRect(14, 16, 8, 4);
            c.fillStyle = '#ccc'; c.fillRect(15, 16, 1, 2); c.fillRect(17, 16, 1, 2); c.fillRect(19, 16, 1, 2); c.fillRect(21, 16, 1, 2);
            // Tail curving
            c.fillStyle = '#111125'; c.fillRect(4, 30, 4, 2); c.fillRect(2, 32, 3, 2); c.fillRect(1, 34, 2, 2);
            break;
        case 'vecna':
            // Skeletal/decayed mage, one glowing hand, tendrils
            c.fillStyle = '#1a0a0a'; c.fillRect(8, 24, 20, 18);
            c.fillStyle = '#2a1515'; c.fillRect(10, 26, 16, 14);
            // Decayed skeletal head
            c.fillStyle = '#553322'; c.fillRect(10, 4, 16, 18);
            c.fillStyle = '#443322'; c.fillRect(12, 6, 12, 14);
            // Vine/tendrils on face
            c.fillStyle = '#334411'; c.fillRect(10, 8, 2, 10); c.fillRect(24, 7, 2, 12); c.fillRect(13, 4, 1, 5);
            // Glowing orange eyes
            c.fillStyle = '#ff6600'; c.fillRect(14, 11, 2, 2); c.fillRect(20, 11, 2, 2);
            // Skeletal mouth
            c.fillStyle = '#221100'; c.fillRect(15, 16, 6, 3);
            // Glowing hand
            c.fillStyle = '#ff6600'; c.fillRect(28, 26, 3, 3);
            c.fillStyle = '#ffaa00'; c.fillRect(29, 25, 1, 1);
            break;
        case 'chucky':
            // Small doll body, orange hair, overalls, knife
            c.fillStyle = '#2244aa'; c.fillRect(10, 26, 16, 16); // blue overalls
            c.fillStyle = '#3355bb'; c.fillRect(12, 28, 12, 12);
            c.fillStyle = '#cc3333'; c.fillRect(12, 24, 12, 4);
            c.fillStyle = '#eeccaa'; c.fillRect(12, 8, 12, 14);
            c.fillStyle = '#ddbb99'; c.fillRect(14, 10, 8, 10);
            c.fillStyle = '#ff5500'; c.fillRect(10, 2, 16, 8);
            c.fillStyle = '#ee4400'; c.fillRect(8, 5, 4, 5); c.fillRect(24, 5, 4, 5);
            c.fillStyle = '#aa8866'; c.fillRect(14, 16, 1, 1); c.fillRect(21, 16, 1, 1);
            c.fillStyle = '#4488ff'; c.fillRect(15, 13, 2, 2); c.fillRect(19, 13, 2, 2);
            c.fillStyle = '#cc0000'; c.fillRect(15, 18, 6, 2);
            c.fillStyle = '#fff'; c.fillRect(16, 18, 1, 1); c.fillRect(18, 18, 1, 1); c.fillRect(20, 18, 1, 1);
            c.fillStyle = '#ccc'; c.fillRect(28, 18, 2, 10);
            break;
        case 'pinhead':
            // Pale grey skin, black leather, pins/nails in grid on head, chains
            c.fillStyle = '#1a1a1a'; c.fillRect(8, 24, 20, 18); // black leather body
            c.fillStyle = '#222'; c.fillRect(10, 26, 16, 14);
            // Grid pattern on leather
            c.fillStyle = '#333'; c.fillRect(11, 28, 1, 12); c.fillRect(15, 28, 1, 12); c.fillRect(19, 28, 1, 12); c.fillRect(23, 28, 1, 12);
            // Pale grey head
            c.fillStyle = '#aaaaaa'; c.fillRect(10, 4, 16, 18);
            c.fillStyle = '#999'; c.fillRect(12, 6, 12, 14);
            // PINS in grid pattern on skull (iconic)
            c.fillStyle = '#444'; 
            c.fillRect(12, 5, 1, 3); c.fillRect(15, 5, 1, 3); c.fillRect(18, 5, 1, 3); c.fillRect(21, 5, 1, 3); c.fillRect(24, 5, 1, 3);
            c.fillRect(12, 9, 1, 3); c.fillRect(15, 9, 1, 3); c.fillRect(18, 9, 1, 3); c.fillRect(21, 9, 1, 3); c.fillRect(24, 9, 1, 3);
            c.fillRect(12, 13, 1, 3); c.fillRect(15, 13, 1, 3); c.fillRect(21, 13, 1, 3); c.fillRect(24, 13, 1, 3);
            // Eyes (sunken, dark)
            c.fillStyle = '#000'; c.fillRect(14, 12, 3, 3); c.fillRect(19, 12, 3, 3);
            c.fillStyle = gc; c.fillRect(15, 13, 1, 1); c.fillRect(20, 13, 1, 1);
            // Chains hanging
            c.fillStyle = '#777'; c.fillRect(5, 20, 1, 12); c.fillRect(30, 18, 1, 14);
            c.fillStyle = '#888'; c.fillRect(5, 22, 1, 2); c.fillRect(30, 20, 1, 2); c.fillRect(5, 26, 1, 2); c.fillRect(30, 24, 1, 2);
            break;
        case 'legion':
            // Hooded figure, mask with grin, multiple colored variants, knife
            c.fillStyle = sc; c.fillRect(8, 24, 20, 18);
            c.fillStyle = '#2a2a3a'; c.fillRect(10, 26, 16, 14);
            // Hood
            c.fillStyle = '#1a1a2a'; c.fillRect(8, 2, 20, 20);
            c.fillStyle = '#222233'; c.fillRect(10, 4, 16, 16);
            // Mask (white with smile/marks)
            c.fillStyle = '#ddd'; c.fillRect(12, 8, 12, 12);
            c.fillStyle = '#ccc'; c.fillRect(13, 9, 10, 10);
            // Dark eye holes
            c.fillStyle = '#000'; c.fillRect(14, 11, 3, 3); c.fillRect(19, 11, 3, 3);
            // Red/pink eyes
            c.fillStyle = gc; c.fillRect(15, 12, 1, 1); c.fillRect(20, 12, 1, 1);
            // Smile carved on mask
            c.fillStyle = '#880000'; c.fillRect(14, 16, 8, 1); c.fillRect(13, 15, 1, 1); c.fillRect(22, 15, 1, 1);
            // Knife
            c.fillStyle = '#ccc'; c.fillRect(28, 14, 2, 12);
            c.fillStyle = '#ddd'; c.fillRect(28, 14, 1, 12);
            break;
        case 'sirenhead':
            // Extremely tall thin body, two speaker heads on top, no face
            c.fillStyle = '#2a2a1a'; c.fillRect(14, 14, 8, 30); // thin long body/trunk
            c.fillStyle = '#3a3a2a'; c.fillRect(15, 16, 6, 26);
            // Thin arms (long, reaching down)
            c.fillStyle = '#2a2a1a'; c.fillRect(10, 20, 3, 18); c.fillRect(23, 20, 3, 18);
            // TWO SPEAKER HEADS (iconic)
            c.fillStyle = '#3a3a2a'; c.fillRect(10, 0, 8, 14); // left head
            c.fillRect(18, 0, 8, 14); // right head
            // Speaker cones (circles/rects)
            c.fillStyle = '#111'; c.fillRect(12, 3, 4, 8); c.fillRect(20, 3, 4, 8);
            c.fillStyle = '#333'; c.fillRect(13, 5, 2, 4); c.fillRect(21, 5, 2, 4);
            // Speaker glow when active
            c.fillStyle = gc; c.fillRect(13, 6, 2, 2); c.fillRect(21, 6, 2, 2);
            // Wires/exposed parts
            c.fillStyle = '#444'; c.fillRect(16, 10, 4, 4); // neck connector
            break;
        case 'springtrap':
            // Deteriorated animatronic bunny suit, yellow-green, exposed endoskeleton
            c.fillStyle = '#4a5a1a'; c.fillRect(8, 24, 20, 18); // damaged suit body
            c.fillStyle = '#6a7a2a'; c.fillRect(10, 26, 16, 14);
            // Exposed wires/endoskeleton patches
            c.fillStyle = '#444'; c.fillRect(12, 28, 3, 6); c.fillRect(21, 30, 3, 4);
            // Head (bunny ears, damaged)
            c.fillStyle = '#6a7a2a'; c.fillRect(10, 4, 16, 18);
            c.fillStyle = '#5a6a1a'; c.fillRect(12, 6, 12, 14);
            // Bunny ears (one broken/bent)
            c.fillStyle = '#6a7a2a'; c.fillRect(12, 0, 4, 6); // left ear (intact)
            c.fillRect(20, 0, 4, 5); // right ear (shorter, broken)
            c.fillStyle = '#333'; c.fillRect(21, 4, 3, 2); // broken ear endoskeleton showing
            // Eyes (silver/metallic animatronic)
            c.fillStyle = '#aaa'; c.fillRect(14, 10, 3, 3); c.fillRect(19, 10, 3, 3);
            c.fillStyle = gc; c.fillRect(15, 11, 1, 1); c.fillRect(20, 11, 1, 1);
            // Jaw (open, damaged, teeth visible)
            c.fillStyle = '#4a5a1a'; c.fillRect(13, 16, 10, 4);
            c.fillStyle = '#ddd'; c.fillRect(14, 16, 1, 2); c.fillRect(16, 16, 1, 2); c.fillRect(18, 16, 1, 2); c.fillRect(20, 16, 1, 2); c.fillRect(22, 16, 1, 2);
            // Purple/dark areas (interior showing)
            c.fillStyle = '#2a1a3a'; c.fillRect(14, 18, 8, 2);
            break;
        default:
            // Generic killer fallback
            c.fillStyle = mc; c.fillRect(9, 4, 18, 18);
            c.fillStyle = '#000'; c.fillRect(12, 10, 12, 8);
            c.fillStyle = gc; c.fillRect(14, 12, 3, 3); c.fillRect(20, 12, 3, 3);
            break;
    }
}

function drawSurvivorPortrait(c, key, data) {
    let shirt = data.shirtColor || '#888';
    let hair = data.color || '#332211';
    let sec = data.secondaryColor || '#444';
    let skin = '#ddb088';
    if (key === 'claudette') skin = '#8a6644';
    if (key === 'feng') skin = '#eeccaa';
    
    // Body
    c.fillStyle = sec; c.fillRect(8, 26, 20, 16);
    c.fillStyle = shirt; c.fillRect(10, 28, 16, 12);
    
    // Head base
    c.fillStyle = skin; c.fillRect(12, 8, 12, 14);
    
    switch(key) {
        case 'meg':
            // Ponytail going right, athletic look
            c.fillStyle = hair; c.fillRect(10, 4, 16, 6); c.fillRect(10, 8, 3, 5); c.fillRect(23, 8, 3, 5);
            // Ponytail (flowing to right)
            c.fillStyle = hair; c.fillRect(24, 8, 3, 10); c.fillRect(26, 12, 2, 6);
            // Determined eyes
            c.fillStyle = '#fff'; c.fillRect(14, 13, 3, 2); c.fillRect(19, 13, 3, 2);
            c.fillStyle = '#543'; c.fillRect(15, 13, 2, 2); c.fillRect(20, 13, 2, 2);
            // Athletic headband hint
            c.fillStyle = '#cc4455'; c.fillRect(11, 7, 14, 2);
            break;
        case 'claudette':
            // Voluminous natural dark hair, glasses hint, botanical
            c.fillStyle = hair; c.fillRect(9, 2, 18, 8); c.fillRect(9, 8, 4, 8); c.fillRect(23, 8, 4, 8);
            // Full volume top
            c.fillStyle = '#111'; c.fillRect(10, 3, 16, 5);
            // Glasses
            c.fillStyle = '#888'; c.fillRect(13, 13, 4, 3); c.fillRect(19, 13, 4, 3);
            c.fillStyle = '#fff'; c.fillRect(14, 14, 2, 1); c.fillRect(20, 14, 2, 1);
            c.fillStyle = '#888'; c.fillRect(17, 14, 2, 1); // bridge
            // Gentle smile
            c.fillStyle = '#664'; c.fillRect(16, 18, 4, 1);
            break;
        case 'dwight':
            // Neat short hair, thick glasses, tie
            c.fillStyle = hair; c.fillRect(10, 4, 16, 5); c.fillRect(10, 7, 3, 3); c.fillRect(23, 7, 3, 3);
            // BIG glasses (nerd)
            c.fillStyle = '#333'; c.fillRect(12, 12, 5, 4); c.fillRect(19, 12, 5, 4);
            c.fillStyle = '#aaddff'; c.fillRect(13, 13, 3, 2); c.fillRect(20, 13, 3, 2);
            c.fillStyle = '#333'; c.fillRect(17, 13, 2, 1); // bridge
            // Red tie
            c.fillStyle = '#cc2222'; c.fillRect(17, 22, 2, 8);
            c.fillStyle = '#aa1111'; c.fillRect(16, 22, 4, 2); // knot
            break;
        case 'nea':
            // Beanie/cap, graffiti style, edgy
            c.fillStyle = '#333344'; c.fillRect(10, 2, 16, 7); // beanie
            c.fillStyle = '#444455'; c.fillRect(11, 3, 14, 4);
            c.fillStyle = hair; c.fillRect(10, 8, 3, 6); c.fillRect(23, 8, 3, 6); // hair sides (purple-ish)
            // Eyeliner/dark eyes
            c.fillStyle = '#222'; c.fillRect(13, 12, 4, 3); c.fillRect(19, 12, 4, 3);
            c.fillStyle = '#aaf'; c.fillRect(14, 13, 2, 1); c.fillRect(20, 13, 2, 1);
            // Smirk
            c.fillStyle = '#664'; c.fillRect(16, 18, 5, 1);
            break;
        case 'jake':
            // Rugged look, stubble, outdoor gear, scarf
            c.fillStyle = hair; c.fillRect(10, 3, 16, 6); c.fillRect(10, 7, 3, 5); c.fillRect(23, 7, 3, 5);
            // Stubble/5 o'clock shadow
            c.fillStyle = '#8a7a6a'; c.fillRect(13, 17, 10, 3);
            // Eyes
            c.fillStyle = '#fff'; c.fillRect(14, 13, 3, 2); c.fillRect(19, 13, 3, 2);
            c.fillStyle = '#342'; c.fillRect(15, 13, 2, 2); c.fillRect(20, 13, 2, 2);
            // Scarf/bandana
            c.fillStyle = '#1a3a1a'; c.fillRect(10, 22, 16, 4);
            c.fillStyle = '#2a4a2a'; c.fillRect(11, 23, 14, 2);
            break;
        case 'feng':
            // Asian features, gaming headset, bright highlights in hair
            c.fillStyle = hair; c.fillRect(10, 3, 16, 6); c.fillRect(10, 7, 3, 7); c.fillRect(23, 7, 3, 7);
            // Colored streak in hair
            c.fillStyle = '#cc44ff'; c.fillRect(11, 4, 3, 5);
            // Headset
            c.fillStyle = '#444'; c.fillRect(9, 10, 3, 6); c.fillRect(24, 10, 3, 6);
            c.fillStyle = '#666'; c.fillRect(10, 3, 16, 2); // headband
            // Eyes
            c.fillStyle = '#fff'; c.fillRect(14, 13, 3, 2); c.fillRect(19, 13, 3, 2);
            c.fillStyle = '#321'; c.fillRect(15, 13, 2, 2); c.fillRect(20, 13, 2, 2);
            break;
        default:
            // Generic survivor
            c.fillStyle = hair; c.fillRect(10, 3, 16, 6); c.fillRect(10, 7, 3, 5); c.fillRect(23, 7, 3, 5);
            c.fillStyle = '#fff'; c.fillRect(14, 13, 3, 2); c.fillRect(19, 13, 3, 2);
            c.fillStyle = '#222'; c.fillRect(15, 13, 2, 2); c.fillRect(20, 13, 2, 2);
            break;
    }
}

// ESC closes
document.addEventListener('keydown', e => { if (e.key==='Escape') closeLobbyUI(); });

// =============================================================
// CUSTOMIZE PANEL - Character cosmetics with live sprite preview
// =============================================================
function renderCustomizePanel() {
    let cosmetics = typeof CHAR_COSMETICS !== 'undefined' ? CHAR_COSMETICS[csChar] : null;
    let charLv = typeof getCharLevel === 'function' ? getCharLevel(csChar) : {level:1, xp:0};
    let equipped = typeof getEquippedCosmetics === 'function' ? getEquippedCosmetics(csChar) : {head:'default',body:'default',weapon:'default'};
    let unlocked = typeof getUnlockedCosmetics === 'function' ? getUnlockedCosmetics(csChar) : ['default'];
    let chars = csRole === 'killer' ? KILLERS : SURVIVORS;
    let charData = chars[csChar];
    
    let xpBar = charLv.xp / (typeof CHAR_LEVEL_XP !== 'undefined' ? CHAR_LEVEL_XP : 200);
    
    // Build cosmetic slots HTML
    let slotsHtml = '';
    if (cosmetics) {
        let slotTypes = csRole === 'killer' ? ['head', 'body', 'weapon'] : ['head', 'body'];
        let slotNames = { head: '🎭 CABEÇA', body: '👕 CORPO', weapon: '🔪 ARMA' };
        
        for (let slot of slotTypes) {
            if (!cosmetics[slot] || cosmetics[slot].length === 0) continue;
            slotsHtml += `<div style="margin-bottom:10px;">
                <div style="font-size:0.65em;color:#888;letter-spacing:1px;margin-bottom:5px;">${slotNames[slot]}</div>
                <div style="display:flex;flex-wrap:wrap;gap:4px;">`;
            
            for (let item of cosmetics[slot]) {
                let isEquipped = equipped[slot] === item.key;
                let isUnlocked = item.price === 0 || unlocked.includes(item.key);
                let canBuy = !isUnlocked && charLv.level >= item.level && playerProfile.bloodpoints >= item.price;
                let levelLocked = !isUnlocked && charLv.level < item.level;
                let rarity = item.price > 3500 ? 'ultra_rare' : item.price > 2000 ? 'very_rare' : item.price > 1000 ? 'rare' : item.price > 0 ? 'uncommon' : 'common';
                let r = typeof RARITY !== 'undefined' ? RARITY[rarity] : {color:'#888',border:'#444',bg:'#111'};
                
                let borderCol = isEquipped ? '#ffaa00' : isUnlocked ? r.border : levelLocked ? '#1a1a1a' : '#664400';
                let bgCol = isEquipped ? '#1a1400' : isUnlocked ? r.bg : '#050505';
                let opacity = isUnlocked || canBuy ? '1' : '0.45';
                
                let onclick = isEquipped ? '' : isUnlocked ? `csEquipCosmetic('${slot}','${item.key}')` : canBuy ? `csBuyCosmetic('${item.key}')` : '';
                
                slotsHtml += `<div onclick="${onclick}" style="width:50px;padding:3px;background:${bgCol};border:2px solid ${borderCol};cursor:${onclick?'pointer':'default'};opacity:${opacity};text-align:center;position:relative;" title="${item.name}${!isUnlocked?' ('+item.price+' BP, Lv.'+item.level+')':''}&#10;${typeof RARITY!=='undefined'?RARITY[rarity].name:''}">
                    <div style="font-size:1.2em;">${item.icon}</div>
                    <div style="font-size:0.45em;color:${r.color};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${item.name.split(' ')[0]}</div>
                    ${isEquipped ? '<div style="position:absolute;top:0px;right:1px;font-size:0.5em;color:#ffaa00;">✓</div>' : ''}
                    ${!isUnlocked && !levelLocked ? `<div style="font-size:0.4em;color:#ffaa00;">${item.price}BP</div>` : ''}
                    ${levelLocked ? `<div style="font-size:0.4em;color:#555;">🔒Lv.${item.level}</div>` : ''}
                </div>`;
            }
            slotsHtml += `</div></div>`;
        }
    } else {
        slotsHtml = `<div style="color:#555;font-size:0.75em;">Cosméticos não disponíveis para este personagem.</div>`;
    }
    
    // Bloodweb
    let bloodwebHtml = '';
    if (typeof renderBloodweb === 'function') {
        bloodwebHtml = renderBloodweb(csChar);
    }
    
    return `<div class="cs-panel open" style="width:400px;">
        <h3>🎨 CUSTOMIZAR — ${charData?.name || csChar}</h3>
        
        <!-- Character Level -->
        <div style="padding:8px;background:#0a0604;border:2px solid #2a1a0a;margin-bottom:10px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px;">
                <span style="font-size:0.75em;color:#aa88ff;">⭐ Nível ${charLv.level}/${typeof CHAR_MAX_LEVEL!=='undefined'?CHAR_MAX_LEVEL:25}</span>
                <span style="font-size:0.6em;color:#ffcc00;">💰 ${playerProfile.bloodpoints} BP</span>
            </div>
            <div style="width:100%;height:8px;background:#111;border:1px solid #333;overflow:hidden;">
                <div style="height:100%;width:${xpBar*100}%;background:linear-gradient(90deg,#6644aa,#9955ff);"></div>
            </div>
            <div style="font-size:0.55em;color:#555;margin-top:3px;text-align:right;">${charLv.xp}/${typeof CHAR_LEVEL_XP!=='undefined'?CHAR_LEVEL_XP:200} XP</div>
        </div>
        
        <!-- Sprite Preview -->
        <div style="text-align:center;margin-bottom:10px;padding:8px;background:#030303;border:2px solid #1a1a1a;">
            <canvas id="cs-preview-canvas" width="80" height="100" style="image-rendering:pixelated;width:100px;height:125px;"></canvas>
        </div>
        
        <!-- Cosmetic Slots -->
        ${slotsHtml}
        
        <!-- Skins (full character skins like Leon, Ghostface, etc.) -->
        <div style="margin-top:10px;border-top:1px solid #2a1a0a;padding-top:8px;">
            <div style="font-size:0.65em;color:#888;letter-spacing:1px;margin-bottom:6px;">🎭 SKINS COMPLETAS</div>
            <div id="cs-skins-row" style="display:flex;flex-wrap:wrap;gap:4px;"></div>
        </div>
        
        <!-- Bloodweb -->
        <div style="margin-top:12px;border-top:1px solid #2a1a0a;padding-top:10px;">
            <div style="font-size:0.7em;color:#cc4444;letter-spacing:1px;margin-bottom:8px;text-align:center;">🕸️ TEIA DE SANGUE</div>
            ${bloodwebHtml}
        </div>
    </div>`;
}

function csEquipCosmetic(slot, key) {
    if (typeof equipCosmetic === 'function') {
        equipCosmetic(csChar, slot, key);
    }
    renderLobbyUI();
    setTimeout(drawCustomizePreview, 20);
}

function csSelectSkin(skinKey) {
    let skinSelect = document.getElementById('my-skin-select');
    if (skinSelect) skinSelect.value = skinKey;
    if (typeof onCharChange === 'function') onCharChange();
    renderLobbyUI();
    setTimeout(() => { drawCustomizePreview(); renderSkinsRow(); }, 20);
}

function renderSkinsRow() {
    let container = document.getElementById('cs-skins-row');
    if (!container) return;
    let skins = typeof SKINS !== 'undefined' ? SKINS[csRole] : {};
    let unlockedSkins = playerProfile.unlockedSkins?.[csRole] || ['default'];
    let currentSkin = document.getElementById('my-skin-select')?.value || 'default';
    let html = '';
    for (let [key, sk] of Object.entries(skins)) {
        let owned = unlockedSkins.includes(key);
        let selected = key === currentSkin;
        let border = selected ? '#ffaa00' : owned ? '#444' : '#1a1a1a';
        let bg = selected ? '#1a1400' : owned ? '#0a0a06' : '#050505';
        let click = owned ? "csSelectSkin('" + key + "')" : '';
        html += '<div onclick="' + click + '" style="width:48px;padding:3px;background:' + bg + ';border:2px solid ' + border + ';cursor:' + (owned ? 'pointer' : 'default') + ';opacity:' + (owned ? '1' : '0.4') + ';text-align:center;" title="' + sk.name + (owned ? '' : ' (bloqueado)') + '">';
        html += '<div style="font-size:1.1em;">' + sk.icon + '</div>';
        html += '<div style="font-size:0.4em;color:#aaa;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;">' + sk.name.split(' ')[0] + '</div>';
        if (selected) html += '<div style="font-size:0.4em;color:#ffaa00;">ATIVO</div>';
        if (!owned) html += '<div style="font-size:0.4em;color:#555;">🔒</div>';
        html += '</div>';
    }
    container.innerHTML = html;
}

function csBuyCosmetic(key) {
    if (typeof buyCosmetic === 'function') {
        if (buyCosmetic(csChar, key)) {
            renderLobbyUI();
            setTimeout(drawCustomizePreview, 20);
        }
    }
}

function drawCustomizePreview() {
    let cv = document.getElementById('cs-preview-canvas');
    if (!cv) return;
    let c = cv.getContext('2d');
    c.clearRect(0, 0, 80, 100);
    
    let chars = csRole === 'killer' ? KILLERS : SURVIVORS;
    let charData = chars[csChar];
    if (!charData) return;
    
    let equipped = typeof getEquippedCosmetics === 'function' ? getEquippedCosmetics(csChar) : {head:'default',body:'default',weapon:'default'};
    let cosmetics = typeof CHAR_COSMETICS !== 'undefined' ? CHAR_COSMETICS[csChar] : null;
    
    // Get colors from cosmetics
    let headColor = charData.color;
    let bodyColor = csRole === 'killer' ? charData.color : (charData.shirtColor || '#888');
    let weaponColor = charData.weaponColor || '#888';
    
    if (cosmetics) {
        let headItem = cosmetics.head?.find(c2 => c2.key === equipped.head);
        let bodyItem = cosmetics.body?.find(c2 => c2.key === equipped.body);
        let weapItem = cosmetics.weapon?.find(c2 => c2.key === equipped.weapon);
        if (headItem && headItem.key !== 'default') headColor = headItem.color;
        if (bodyItem && bodyItem.key !== 'default') bodyColor = bodyItem.color;
        if (weapItem && weapItem.key !== 'default') weaponColor = weapItem.color;
    }
    
    let x = 40, y = 60;
    let bob = Math.sin(csPreviewFrame * 0.04) * 1.5;
    csPreviewFrame++;
    
    // Shadow
    c.fillStyle = '#00000044';
    c.fillRect(x-12, y+24, 24, 4);
    
    if (csRole === 'killer') {
        // Killer sprite with custom colors
        let secColor = charData.secondaryColor || '#222';
        let glowCol = charData.glowColor || '#ff0000';
        
        // Glow
        c.fillStyle = glowCol + '15';
        c.fillRect(x-16, y-4, 32, 28);
        
        // Boots
        c.fillStyle = '#111'; c.fillRect(x-8, y+20+bob, 6, 4); c.fillRect(x+3, y+20+bob, 6, 4);
        // Legs
        c.fillStyle = '#1a1a1a'; c.fillRect(x-7, y+12+bob, 5, 9); c.fillRect(x+3, y+12+bob, 5, 9);
        // Body
        c.fillStyle = secColor; c.fillRect(x-11, y-4+bob, 22, 18);
        c.fillStyle = bodyColor; c.fillRect(x-10, y-2+bob, 20, 14);
        // Arms
        c.fillStyle = bodyColor; c.fillRect(x-14, y-1+bob, 3, 14); c.fillRect(x+12, y-1+bob, 3, 14);
        // Head
        c.fillStyle = headColor; c.fillRect(x-8, y-18+bob, 16, 14);
        c.fillStyle = '#000'; c.fillRect(x-6, y-14+bob, 12, 8);
        // Eyes
        c.fillStyle = glowCol; c.fillRect(x-4, y-12+bob, 3, 3); c.fillRect(x+2, y-12+bob, 3, 3);
        // Weapon (right hand)
        c.fillStyle = weaponColor; c.fillRect(x+12, y+2+bob, 3, 16);
        c.fillStyle = weaponColor; c.fillRect(x+11, y+0+bob, 5, 3);
    } else {
        // Survivor sprite with custom colors
        let skinTone = '#ddb088';
        if (csChar === 'claudette') skinTone = '#8a6644';
        if (csChar === 'feng') skinTone = '#eeccaa';
        
        // Shoes
        c.fillStyle = '#1a1a1a'; c.fillRect(x-7, y+20+bob, 5, 3); c.fillRect(x+2, y+20+bob, 5, 3);
        // Legs (jeans)
        c.fillStyle = '#222244'; c.fillRect(x-6, y+11+bob, 4, 10); c.fillRect(x+2, y+11+bob, 4, 10);
        // Body
        c.fillStyle = bodyColor; c.fillRect(x-9, y-3+bob, 18, 15);
        // Arms
        c.fillStyle = skinTone; c.fillRect(x-11, y+0+bob, 3, 12); c.fillRect(x+9, y+0+bob, 3, 12);
        // Head
        c.fillStyle = skinTone; c.fillRect(x-6, y-16+bob, 12, 13);
        // Hair
        c.fillStyle = headColor; c.fillRect(x-7, y-20+bob, 14, 7);
        c.fillRect(x-7, y-15+bob, 3, 5); c.fillRect(x+5, y-15+bob, 3, 5);
        // Eyes
        c.fillStyle = '#fff'; c.fillRect(x-4, y-11+bob, 3, 3); c.fillRect(x+2, y-11+bob, 3, 3);
        c.fillStyle = '#222'; c.fillRect(x-3, y-11+bob, 2, 3); c.fillRect(x+3, y-11+bob, 2, 3);
    }
}

// Start preview animation when customize panel is open
function startCustomizePreview() {
    if (csPreviewInterval) clearInterval(csPreviewInterval);
    csPreviewInterval = setInterval(() => {
        if (csActivePanel === 'customize') drawCustomizePreview();
        else { clearInterval(csPreviewInterval); csPreviewInterval = null; }
    }, 50);
}
