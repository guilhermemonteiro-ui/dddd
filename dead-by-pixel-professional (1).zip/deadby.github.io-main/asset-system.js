// DEAD BY PIXEL — original PNG atlas renderer (28px world grid)
(() => {
  const original = {
    map: window.drawMapEnhanced,
    killer: window.drawKillerDetailed,
    survivor: window.drawSurvivorDetailed,
    crawl: window.drawCrawlingSurvivor,
    pallet: window.drawPallet,
    locker: window.drawLocker,
    hook: window.drawHook,
    generator: window.drawGenerator,
    chest: window.drawChest,
    gate: window.drawExitGate,
    trap: window.drawTrap
  };
  const images = new Map();
  const image = src => {
    if (!images.has(src)) { const img = new Image(); img.src = `${src}?v=4`; images.set(src,img); }
    return images.get(src);
  };
  const ready = img => img && img.complete && img.naturalWidth > 0;
  const tileAtlas = image('assets/tiles/world-tiles.png');
  const propAtlas = image('assets/props/world-props.png');
  const biomeRow = { asylum:0, forest:1, factory:2, catacombs:3, hospital:4 };
  const drawProp = (column, x, y) => {
    if (!ready(propAtlas)) return false;
    ctx.drawImage(propAtlas, column*32, 0, 32, 40, Math.round(x-2), Math.round(y-8), 32, 40);
    return true;
  };

  window.drawMapEnhanced = function() {
    if (!ready(tileAtlas) || !currentMap) return original.map();
    const row = biomeRow[currentMapKey] ?? 0;
    for (let y=0; y<currentMap.height; y++) for (let x=0; x<currentMap.width; x++) {
      const value=currentMap.grid[y][x], wall=value===1;
      const variant=((x*11+y*7+(wall?3:0))&1);
      const col=(wall?2:0)+variant;
      ctx.drawImage(tileAtlas,col*28,row*28,28,28,x*TILE,y*TILE,TILE,TILE);
      if (!wall && y>0 && currentMap.grid[y-1][x]===1) { ctx.fillStyle='#0006'; ctx.fillRect(x*TILE,y*TILE,TILE,7); }
      if (value===8) { ctx.fillStyle='#b08a5738'; ctx.fillRect(x*TILE,y*TILE+12,TILE,4); }
    }
  };

  function drawCharacter(p,x,y,role) {
    const namedSkin=p.skin && p.skin!=='default' && p.skin!=='prestige';
    const src=namedSkin ? `assets/characters/skins/${role}-${p.skin}.png` : `assets/characters/${role}-${p.charKey}.png`;
    const img=image(src);
    if (!ready(img)) return false;
    let state;
    if (role==='survivor' && p.dying) state=7;
    else if (role==='killer' && p.attacking) {
      const duration=Math.max(1,p.charData.attackDuration||15);
      state=5+Math.min(2,Math.floor((1-p.attackTimer/duration)*3));
    } else if (role==='survivor' && (p._searchProgress>0 || p._interactAnim>0)) {
      state=5+(Math.floor(gameTimer/7)%2);
    } else if (role==='survivor' && p.injured && !p.isRunning) state=7;
    else if (p.isRunning) state=2+(Math.floor(gameTimer/6)%3);
    else state=Math.floor(gameTimer/28)%2;
    const dir=Math.max(0,Math.min(3,p.facing||0));
    ctx.save();
    ctx.imageSmoothingEnabled=false;
    ctx.fillStyle='#0007'; ctx.beginPath(); ctx.ellipse(x,y+11,10,4,0,0,Math.PI*2); ctx.fill();
    ctx.drawImage(img,state*128,dir*160,128,160,Math.round(x-24),Math.round(y-48),48,60);
    if(p.skin==='prestige') {
      ctx.fillStyle='#7e1010';
      ctx.fillRect(Math.round(x-7),Math.round(y-12),3,7);
      ctx.fillRect(Math.round(x+4),Math.round(y-2),2,6);
      ctx.fillRect(Math.round(x-2),Math.round(y+5),4,2);
    }
    ctx.restore();
    return true;
  }
  window.drawKillerDetailed=function(p,x,y){ if(!drawCharacter(p,x,y,'killer')) original.killer(p,x,y,0,0); };
  window.drawSurvivorDetailed=function(p,x,y){ if(!drawCharacter(p,x,y,'survivor')) original.survivor(p,x,y,0,0); };
  window.drawCrawlingSurvivor=function(p,x,y){ if(!drawCharacter(p,x,y,'survivor')) original.crawl(p,x,y); };

  window.drawPallet=function(p){ if(!drawProp(p.broken?1:(p.dropped?1:0),p.x,p.y)) original.pallet(p); };
  window.drawLocker=function(o){ if(!drawProp(2,o.x,o.y)) original.locker(o); };
  window.drawHook=function(o){ if(!drawProp(4,o.x,o.y)) original.hook(o); };
  window.drawGenerator=function(o){ if(!drawProp(o.completed?9:(o.progress>0?3:8),o.x,o.y)) original.generator(o); };
  window.drawChest=function(o){ if(!drawProp(o.opened?11:5,o.x,o.y)) original.chest(o); };
  window.drawExitGate=function(o){ if(!drawProp(o.open?7:6,o.x,o.y)) original.gate(o); };
  window.drawTrap=function(o){ if(!drawProp(10,o.x,o.y)) original.trap(o); };

  window.DBP_ASSETS={ images, manifest:'assets/manifest.json', version:4 };
})();
