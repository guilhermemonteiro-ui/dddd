# Character Asset Index — Compact Roster

O jogo possui somente seis personagens nesta versão: três killers e três sobreviventes.

## Killers

`ghostface` (Pânico), `trapper`, `huntress`

Estados: `idle-a`, `idle-b`, `walk-a`, `walk-b`, `walk-c`, `attack-windup`, `attack-strike`, `attack-recovery`.

## Sobreviventes

`meg`, `claudette`, `dwight`

Estados: `idle-a`, `idle-b`, `walk-a`, `walk-b`, `walk-c`, `pickup-reach`, `pickup-hold`, `injured`.

## Formato

- PNG com transparência real.
- Atlas de execução: 1024×640 px.
- Célula: 128×160 px.
- Quatro direções: baixo, cima, esquerda e direita.
- Âncora comum nos pés.
- Artes-fonte em alta resolução preservadas em `characters/source-hires/`.
