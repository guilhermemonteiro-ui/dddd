// ============================================================
// DEAD BY PIXEL - FULL SPRITE SYSTEM
// All killers & survivors with facing directions + ability anims
// px(x,y,w,h,color) draws a pixel block
// facing: 0=front/down, 1=back/up, 2=left, 3=right
// ============================================================

function px(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),w,h);}

function drawKillerDetailed(p,x,y,bobY,lean){
    let cd=p.charData,f=gameTimer,b=bobY,L=lean;
    let leg=Math.sin(f*0.18)*(p.isRunning?5:0);
    let arm=Math.sin(f*0.15)*(p.isRunning?4:1.5);
    let br=Math.sin(f*0.05);
    let fc=p.facing,abil=p.abilityActive>0;
    let back=fc===1,side=fc===2||fc===3,fl=fc===2?-1:1;
    // Glow
    ctx.fillStyle=(cd.glowColor||'#f00')+'0c';ctx.beginPath();ctx.arc(x,y+12,18,0,Math.PI*2);ctx.fill();
    
    // Check if player has custom skin/cosmetic — use generic renderer to show custom colors
    let hasCustomLook = (p.skin && p.skin !== 'default');
    if (!hasCustomLook && typeof getEquippedCosmetics === 'function' && typeof CHAR_COSMETICS !== 'undefined' && CHAR_COSMETICS[p.charKey]) {
        let eq = getEquippedCosmetics(p.charKey);
        if (eq.head !== 'default' || eq.body !== 'default' || eq.weapon !== 'default') hasCustomLook = true;
    }
    
    if (hasCustomLook) {
        // Dispatch to skin-specific renderer if available
        if(p.skin==='ghostface') dkSkinGhostface(x,y,b,L,leg,arm,br,fc,back,fl,p,f);
        else if(p.skin==='michael') dkSkinMichael(x,y,b,L,leg,arm,br,fc,back,fl,p,f);
        else if(p.skin==='freddy') dkSkinFreddy(x,y,b,L,leg,arm,br,fc,back,fl,p,f);
        else if(p.skin==='jason') dkSkinJason(x,y,b,L,leg,arm,br,fc,back,fl,p,f);
        else if(p.skin==='pyramid') dkSkinPyramid(x,y,b,L,leg,arm,br,fc,back,fl,p,f);
        else if(p.skin==='pennywise') dkSkinPennywise(x,y,b,L,leg,arm,br,fc,back,fl,p,f);
        else dkGeneric(x,y,b,L,leg,arm,br,fc,back,fl,p,f,cd);
    } else {
        // Dispatch to character-specific renderer
        if(p.charKey==='trapper')dkTrapper(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f);
        else if(p.charKey==='wraith')dkWraith(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f);
        else if(p.charKey==='huntress')dkHuntress(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f);
        else if(p.charKey==='nurse')dkNurse(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f);
        else if(p.charKey==='hillbilly')dkHillbilly(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f);
        else if(p.charKey==='demogorgon')dkDemo(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f);
        else if(p.charKey==='alien')dkAlien(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f);
        else if(p.charKey==='vecna')dkVecna(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f);
        else if(p.charKey==='chucky')dkChucky(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f);
        else dkGeneric(x,y,b,L,leg,arm,br,fc,back,fl,p,f,cd);
    }
    // Attack swing
    if(p.attacking){let sw=p.attackTimer/cd.attackDuration;ctx.fillStyle=cd.weaponColor;ctx.shadowColor=cd.weaponColor;ctx.shadowBlur=6;switch(fc){case 0:ctx.fillRect(x-2,y+14,4,12+sw*6);break;case 1:ctx.fillRect(x-2,y-26-sw*6,4,12);break;case 2:ctx.fillRect(x-18-sw*5,y-1+b,12+sw*5,3);break;case 3:ctx.fillRect(x+8,y-1+b,12+sw*5,3);break;}ctx.shadowBlur=0;}
    if(p.stealthActive){ctx.fillStyle=(cd.glowColor||'#44f')+'12';ctx.fillRect(x-14,y-22,28,38);}
}

// === TRAPPER ===
function dkTrapper(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f){
    if(abil){// Crouching to place trap
        let c=6;px(x-5,y+10+c,4,3,'#1a1008');px(x+1,y+10+c,4,3,'#1a1008');
        px(x-4,y+4+c,4,7,'#3a2a10');px(x+1,y+4+c,4,7,'#3a2a10');
        px(x-8,y-1+c+br,16,9,'#6a5a38');px(x-6,y-1+c,2,8,'#2a2008');px(x+5,y-1+c,2,8,'#2a2008');
        px(x-9,y+4+c,3,7,'#9a7755');px(x+7,y+4+c,3,7,'#9a7755');// arms down
        px(x-3,y+10+c,6,3,'#887744');px(x-2,y+11+c,4,2,'#aaa');// trap
        px(x-5,y-8+c,10,7,'#aa9966');px(x-3,y-6+c,2,2,'#110800');px(x+2,y-6+c,2,2,'#110800');return;}
    // Normal
    px(x-6+L,y+14+b+leg,5,3,'#1a1008');px(x+1+L,y+14+b-leg,5,3,'#1a1008');
    px(x-5+L,y+6+b,4,9+leg,'#3a2a10');px(x+2+L,y+6+b,4,9-leg,'#3a2a10');
    px(x-9+L,y-6+b+br,18,14,'#5a4a28');px(x-8+L,y-4+b+br,16,10,'#6a5a38');
    px(x-6+L,y-6+b+br,2,12,'#2a2008');px(x+5+L,y-6+b+br,2,12,'#2a2008');
    px(x-3+L,y-2+b+br,3,4,'#6a2010');px(x+2+L,y+1+b+br,2,3,'#5a1808');
    px(x-8+L,y+5+b+br,16,2,'#332810');
    px(x-11+L,y-3+b+arm,3,11,'#9a7755');px(x+9+L,y-3+b-arm,3,11,'#9a7755');
    if(back){px(x-6+L,y-17+b,12,12,'#8a7744');px(x+L,y-16+b,1,10,'#443322');}
    else{px(x-6+L,y-17+b,12,12,'#8a6644');px(x-5+L,y-15+b,10,8,'#aa9966');px(x-4+L,y-14+b,8,6,'#998855');px(x-3+L,y-13+b,2,2,'#110800');px(x+2+L,y-13+b,2,2,'#110800');px(x+L,y-11+b,1,3,'#554422');px(x-2+L,y-12+b,1,1,'#ffaa00');px(x+2+L,y-12+b,1,1,'#ffaa00');}
    if(!p.attacking){if(fc===2)px(x-12+L,y-6+b+arm,2,14,'#999');else{px(x+10+L,y-6+b-arm,2,14,'#999');px(x+10+L,y-6+b-arm,2,2,'#bbb');px(x+10+L,y+6+b-arm,2,3,'#553311');}}
}

// === WRAITH ===
function dkWraith(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f){
    if(abil)ctx.globalAlpha=0.35;
    px(x-4+L,y+14+b+leg,3,2,'#1a2a33');px(x+2+L,y+14+b-leg,3,2,'#1a2a33');
    px(x-4+L,y+6+b,3,9+leg,'#112233');px(x+2+L,y+6+b,3,9-leg,'#112233');
    px(x-7+L,y-7+b+br,14,15,'#1a3344');px(x-6+L,y-5+b+br,12,11,'#224455');
    for(let i=0;i<4;i++)px(x-5+L,y-4+b+br+i*3,10,1,'#446677');
    px(x-9+L,y-3+b+arm,2,12,'#1a3344');px(x+8+L,y-3+b-arm,2,12,'#1a3344');
    if(back){px(x-4+L,y-22+b,8,16,'#2a4455');px(x-3+L,y-20+b,6,12,'#1a3344');}
    else{px(x-4+L,y-22+b,8,16,'#3a5566');px(x-3+L,y-20+b,6,12,'#2a4455');px(x-2+L,y-16+b,2,3,'#000');px(x+1+L,y-16+b,2,3,'#000');ctx.fillStyle='#44ccff';ctx.shadowColor='#44ccff';ctx.shadowBlur=4;px(x-1+L,y-15+b,1,1,'#44ccff');px(x+1+L,y-15+b,1,1,'#44ccff');ctx.shadowBlur=0;px(x-2+L,y-10+b,4,2,'#2a4455');}
    if(!p.attacking){px(x+8+L,y-10+b-arm,2,14,'#556677');px(x+7+L,y-10+b-arm,4,3,'#8899aa');}
    if(abil){ctx.globalAlpha=1;ctx.fillStyle='#44ccff08';ctx.fillRect(x-12,y-22,24,38);}
}

// === HUNTRESS ===
function dkHuntress(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f){
    if(abil){// Winding up hatchet throw - arm raised
        px(x-5+L,y+14+b,5,3,'#1a2a1a');px(x+1+L,y+14+b,5,3,'#1a2a1a');
        px(x-5+L,y+6+b,4,9,'#2a4a2a');px(x+2+L,y+6+b,4,9,'#2a4a2a');
        px(x-9+L,y-7+b,18,15,'#3a5a3a');px(x-7+L,y-7+b,14,3,'#5a4a3a');
        px(x-11+L,y-4+b,3,11,'#2a4a2a');// left arm normal
        px(x+9+L,y-12+b,3,8,'#2a4a2a');// right arm RAISED
        px(x+8+L,y-14+b,4,4,'#888');// hatchet raised
        // Bunny mask
        px(x-5+L,y-17+b,10,11,'#eeeedd');px(x-3+L,y-27+b,3,11,'#eeeedd');px(x+1+L,y-27+b,3,11,'#eeeedd');
        px(x-2+L,y-26+b,1,9,'#ffbbbb');px(x+2+L,y-26+b,1,9,'#ffbbbb');
        px(x-3+L,y-13+b,2,3,'#000');px(x+2+L,y-13+b,2,3,'#000');return;}
    px(x-5+L,y+14+b+leg,5,3,'#1a2a1a');px(x+1+L,y+14+b-leg,5,3,'#1a2a1a');
    px(x-5+L,y+6+b,4,9+leg,'#2a4a2a');px(x+2+L,y+6+b,4,9-leg,'#2a4a2a');
    px(x-9+L,y-7+b+br,18,15,'#2a4a2a');px(x-8+L,y-5+b+br,16,11,'#3a5a3a');
    px(x-7+L,y-7+b+br,14,3,'#5a4a3a');px(x-6+L,y-6+b+br,12,2,'#6a5a4a');
    px(x-11+L,y-4+b+arm,3,11,'#2a4a2a');px(x+9+L,y-4+b-arm,3,11,'#2a4a2a');
    if(back){px(x-5+L,y-17+b,10,11,'#ddddcc');px(x-3+L,y-27+b,3,11,'#ddddcc');px(x+1+L,y-27+b,3,11,'#ddddcc');}
    else{px(x-5+L,y-17+b,10,11,'#eeeedd');px(x-4+L,y-15+b,8,8,'#ddddcc');px(x-3+L,y-27+b,3,11,'#eeeedd');px(x+1+L,y-27+b,3,11,'#eeeedd');px(x-2+L,y-26+b,1,9,'#ffbbbb');px(x+2+L,y-26+b,1,9,'#ffbbbb');px(x-3+L,y-13+b,2,3,'#000');px(x+2+L,y-13+b,2,3,'#000');}
    if(!p.attacking){px(x+9+L,y-3+b-arm,2,10,'#554422');px(x+8+L,y-5+b-arm,4,4,'#888');}
}

// === NURSE ===
function dkNurse(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f){
    if(abil){// Blink - body fading/teleporting
        ctx.globalAlpha=0.4+Math.sin(f*0.3)*0.3;
        for(let i=0;i<3;i++){ctx.fillStyle='#88aaff22';ctx.fillRect(x-8+i*4,y-18+(i*6),16,34);}
    }
    px(x-8+L,y+4+b,16,12,'#777');px(x-7+L,y+6+b,14,8,'#888');
    px(x-8+L,y-7+b+br,16,16,'#888');px(x-7+L,y-5+b+br,14,12,'#999');
    px(x-4+L,y+0+b+br,3,4,'#663333');px(x+2+L,y+3+b+br,3,3,'#553322');
    px(x-10+L,y-3+b+arm,2,10,'#999');px(x+9+L,y-3+b-arm,2,10,'#999');
    if(back){px(x-5+L,y-18+b,10,12,'#bbbbaa');px(x-4+L,y-17+b,8,1,'#999988');px(x-4+L,y-14+b,8,1,'#999988');px(x-4+L,y-11+b,8,1,'#999988');}
    else{px(x-5+L,y-18+b,10,12,'#ccccbb');px(x-4+L,y-16+b,8,8,'#bbbbaa');px(x-4+L,y-17+b,8,1,'#999988');px(x-4+L,y-14+b,8,1,'#999988');px(x-4+L,y-11+b,8,1,'#999988');ctx.fillStyle='#88aaff';ctx.shadowColor='#88aaff';ctx.shadowBlur=4;px(x+1+L,y-13+b,2,2,'#88aaff');ctx.shadowBlur=0;}
    if(!p.attacking)px(x+9+L,y-2+b-arm,2,10,'#666');
    if(abil)ctx.globalAlpha=1;
}

// === HILLBILLY ===
function dkHillbilly(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f){
    let chainsaw=p._chainsawActive;
    if(chainsaw){// Sprinting with chainsaw - leaning forward
        let tilt=3;
        px(x-6+L,y+14+b+leg*1.5,5,3,'#1a1008');px(x+1+L,y+14+b-leg*1.5,5,3,'#1a1008');
        px(x-5+L,y+6+b,4,9+leg*1.5,'#3a2a10');px(x+2+L,y+6+b,4,9-leg*1.5,'#3a2a10');
        px(x-9+L-tilt,y-6+b,18,14,'#5a4422');px(x-6+L-tilt,y-5+b,12,8,'#886644');
        px(x-6+L-tilt,y-6+b,2,13,'#332a11');px(x+5+L-tilt,y-6+b,2,13,'#332a11');
        px(x-11+L-tilt,y-3+b,3,11,'#886644');
        // Chainsaw thrust forward
        px(x+9+L,y-3+b,6,5,'#777');px(x+13+L,y-2+b,4,3,'#cc8800');px(x+15+L,y-1+b,8,2,'#555');
        // Head
        px(x-6+L-tilt,y-18+b,12,12,'#775544');px(x+3+L-tilt,y-17+b,4,5,'#554433');
        ctx.fillStyle='#ffcc00';ctx.shadowColor='#ffcc00';ctx.shadowBlur=3;px(x-3+L-tilt,y-13+b,2,2,'#ffcc00');px(x+2+L-tilt,y-14+b,2,2,'#ffcc00');ctx.shadowBlur=0;
        ctx.fillStyle='#ffcc0018';ctx.fillRect(x-14,y-20,28,36);return;}
    // Normal
    px(x-6+L,y+14+b+leg,5,3,'#1a1008');px(x+1+L,y+14+b-leg,5,3,'#1a1008');
    px(x-5+L,y+6+b,4,9+leg,'#3a2a10');px(x+2+L,y+6+b,4,9-leg,'#3a2a10');
    px(x-9+L,y-6+b+br,18,14,'#5a4422');px(x-6+L,y-5+b+br,12,8,'#886644');
    px(x-3+L,y-3+b+br,1,4,'#664422');px(x+L,y-4+b+br,1,5,'#664422');px(x+3+L,y-2+b+br,1,3,'#664422');
    px(x-6+L,y-6+b+br,2,13,'#332a11');px(x+5+L,y-6+b+br,2,13,'#332a11');
    px(x-11+L,y-3+b+arm,3,11,'#886644');px(x+9+L,y-3+b-arm,3,11,'#886644');
    if(back){px(x-6+L,y-18+b,12,12,'#664433');px(x+3+L,y-16+b,3,4,'#554433');}
    else{px(x-6+L,y-18+b,12,12,'#775544');px(x-5+L,y-16+b,10,8,'#664433');px(x+3+L,y-17+b,4,5,'#554433');ctx.fillStyle='#ffcc00';ctx.shadowColor='#ffcc00';ctx.shadowBlur=3;px(x-3+L,y-13+b,2,2,'#ffcc00');px(x+2+L,y-14+b,2,2,'#ffcc00');ctx.shadowBlur=0;}
    if(!p.attacking){px(x+9+L,y-5+b-arm,4,12,'#777');px(x+9+L,y-1+b-arm,4,4,'#cc8800');px(x+10+L,y+5+b-arm,2,5,'#555');px(x+9+L,y-5+b-arm,4,2,'#aaa');}
}

// === DEMOGORGON ===
function dkDemo(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f){
    if(abil){// Shred - lunging forward, mouth wide open
        let lunge=8;
        px(x-4+L+lunge*fl,y+14+b,3,3,'#2a1818');px(x+2+L+lunge*fl,y+14+b,3,3,'#2a1818');
        px(x-4+L+lunge*fl,y+6+b,3,9,'#3a2222');px(x+2+L+lunge*fl,y+6+b,3,9,'#3a2222');
        px(x-8+L+lunge*fl,y-6+b,16,14,'#4a3535');
        px(x-11+L+lunge*fl,y-3+b,3,14,'#3a2525');px(x+9+L+lunge*fl,y-3+b,3,14,'#3a2525');
        px(x-11+L+lunge*fl,y+9+b,3,3,'#ccaaaa');px(x+9+L+lunge*fl,y+9+b,3,3,'#ccaaaa');
        // Head with mouth WIDE open
        px(x-5+L+lunge*fl,y-18+b,10,12,'#4a2a2a');
        px(x-5+L+lunge*fl,y-26+b,3,9,'#dd7777');px(x+3+L+lunge*fl,y-26+b,3,9,'#dd7777');px(x-1+L+lunge*fl,y-28+b,3,7,'#ee8888');
        px(x-4+L+lunge*fl,y-15+b,8,8,'#110000');px(x-3+L+lunge*fl,y-13+b,6,4,'#ff0000');
        return;}
    px(x-5+L,y+14+b+leg,4,3,'#2a1818');px(x+2+L,y+14+b-leg,4,3,'#2a1818');
    px(x-4+L,y+6+b,3,9+leg,'#3a2222');px(x+2+L,y+6+b,3,9-leg,'#3a2222');
    px(x-8+L,y-6+b+br,16,14,'#3a2525');px(x-7+L,y-4+b+br,14,10,'#4a3535');
    px(x-11+L,y-3+b+arm,3,14,'#3a2525');px(x+9+L,y-3+b-arm,3,14,'#3a2525');
    px(x-11+L,y+9+b+arm,3,3,'#ccaaaa');px(x+9+L,y+9+b-arm,3,3,'#ccaaaa');
    if(back){px(x-5+L,y-18+b,10,12,'#3a2020');px(x-4+L,y-22+b,3,5,'#aa5555');px(x+2+L,y-22+b,3,5,'#aa5555');px(x-1+L,y-24+b,3,4,'#bb6666');}
    else{px(x-5+L,y-18+b,10,12,'#4a2a2a');px(x-4+L,y-24+b,3,7,'#cc6666');px(x+2+L,y-24+b,3,7,'#cc6666');px(x-1+L,y-26+b,3,5,'#dd7777');px(x-5+L,y-21+b,2,5,'#bb5555');px(x+4+L,y-21+b,2,5,'#bb5555');px(x-3+L,y-24+b,1,3,'#ff9999');px(x+3+L,y-24+b,1,3,'#ff9999');px(x-3+L,y-15+b,6,6,'#110000');px(x-2+L,y-13+b,4,3,'#cc0000');px(x-2+L,y-15+b,1,2,'#ddd');px(x+2+L,y-15+b,1,2,'#ddd');}
}

// === XENOMORPH ===
function dkAlien(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f){
    if(abil){// Tail strike - tail whips forward
        px(x-4+L,y+14+b,3,3,'#080810');px(x+2+L,y+14+b,3,3,'#080810');
        px(x-4+L,y+6+b,3,9,'#0a0a18');px(x+2+L,y+6+b,3,9,'#0a0a18');
        px(x-7+L,y-6+b,14,14,'#0a0a18');px(x-6+L,y-4+b,12,10,'#111125');
        px(x-10+L,y-3+b,2,14,'#0a0a18');px(x+9+L,y-3+b,2,14,'#0a0a18');
        px(x-3+L,y-26+b,6,20,'#0a0a18');
        // Tail forward!
        let tx=fc===3?1:fc===2?-1:0,ty=fc===0?1:fc===1?-1:0;
        for(let i=0;i<5;i++){px(x+tx*(10+i*5),y+ty*(10+i*5)+b,3,3,'#111125');}
        px(x+tx*30,y+ty*30+b,2,2,'#333355');// blade tip
        return;}
    px(x-4+L,y+14+b+leg,3,3,'#080810');px(x+2+L,y+14+b-leg,3,3,'#080810');
    px(x-4+L,y+6+b,3,9+leg,'#0a0a18');px(x+2+L,y+6+b,3,9-leg,'#0a0a18');
    px(x-7+L,y-6+b+br,14,14,'#0a0a18');px(x-6+L,y-4+b+br,12,10,'#111125');
    for(let i=0;i<4;i++)px(x-4+L,y-3+b+br+i*3,8,1,'#1a1a33');
    px(x-10+L,y-3+b+arm,2,14,'#0a0a18');px(x+9+L,y-3+b-arm,2,14,'#0a0a18');
    if(back){px(x-3+L,y-26+b,6,20,'#0a0a18');px(x-2+L,y-24+b,4,16,'#111125');}
    else{px(x-3+L,y-26+b,6,20,'#0a0a18');px(x-2+L,y-24+b,4,16,'#111125');px(x-1+L,y-24+b,2,1,'#1a1a33');px(x-1+L,y-21+b,2,1,'#1a1a33');px(x-1+L,y-8+b,1,2,'#ccc');px(x+1+L,y-8+b,1,2,'#ccc');}
    // Tail (animated)
    let tw=Math.sin(f*0.07)*3;
    px(x-10+L+tw,y+4+b,4,2,'#0a0a18');px(x-13+L+tw,y+2+b,3,2,'#0a0a18');px(x-15+L+tw,y+0+b,2,2,'#111125');px(x-16+L+tw,y-1+b,2,2,'#222244');
}

// === VECNA ===
function dkVecna(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f){
    if(abil){// Mage Hand - arm extended with magic glow
        px(x-8+L,y+6+b,5,10,'#110505');px(x+4+L,y+6+b,5,10,'#110505');
        px(x-9+L,y-8+b,18,18,'#1a0a0a');px(x-8+L,y-6+b,16,14,'#2a1515');
        px(x-11+L,y-3+b,2,12,'#886644');
        // Right arm EXTENDED far with magic
        px(x+10+L,y-5+b,2,4,'#886644');px(x+12+L,y-4+b,4,3,'#886644');px(x+16+L,y-3+b,3,2,'#aa8866');
        // Magic particles
        ctx.fillStyle='#ff6600';ctx.shadowColor='#ff6600';ctx.shadowBlur=8;
        px(x+18+L,y-4+b+Math.sin(f*0.2)*3,3,3,'#ff6600');px(x+20+L,y-2+b+Math.cos(f*0.15)*2,2,2,'#ffaa00');
        ctx.shadowBlur=0;
        // Head
        px(x-5+L,y-18+b,10,12,'#553322');px(x+3+L,y-17+b,2,9,'#334411');px(x-4+L,y-15+b,1,7,'#334411');
        ctx.fillStyle='#ff6600';ctx.shadowColor='#ff6600';ctx.shadowBlur=5;px(x-3+L,y-14+b,2,2,'#ff6600');px(x+2+L,y-14+b,2,2,'#ff6600');ctx.shadowBlur=0;
        return;}
    px(x-8+L,y+6+b,5,10,'#110505');px(x+4+L,y+6+b,5,10,'#110505');
    px(x-9+L,y-8+b+br,18,18,'#1a0a0a');px(x-8+L,y-6+b+br,16,14,'#2a1515');
    px(x-9+L,y+6+b,3,4,'#0a0303');px(x+7+L,y+6+b,3,4,'#0a0303');
    px(x-11+L,y-3+b+arm,2,12,'#886644');px(x+10+L,y-3+b-arm,2,12,'#886644');
    px(x-11+L,y+7+b+arm,2,3,'#aa8866');px(x+10+L,y+7+b-arm,2,3,'#aa8866');
    if(back){px(x-5+L,y-18+b,10,12,'#443322');px(x+L,y-17+b,1,8,'#334411');}
    else{px(x-5+L,y-18+b,10,12,'#553322');px(x-4+L,y-16+b,8,8,'#443322');px(x+3+L,y-17+b,2,9,'#334411');px(x-4+L,y-15+b,1,7,'#334411');px(x+L,y-18+b,1,5,'#2a3a0a');px(x-2+L,y-12+b,1,4,'#334411');ctx.fillStyle='#ff6600';ctx.shadowColor='#ff6600';ctx.shadowBlur=5;px(x-3+L,y-14+b,2,2,'#ff6600');px(x+2+L,y-14+b,2,2,'#ff6600');ctx.shadowBlur=0;}
}

// === CHUCKY ===
function dkChucky(x,y,b,L,leg,arm,br,fc,back,fl,abil,p,f){
    let cy=5;// shorter offset
    if(abil){// Hiding (crouched, sneaking) - very low
        ctx.globalAlpha=0.6;
        px(x-3+L,y+8+cy,3,4,'#2244aa');px(x+1+L,y+8+cy,3,4,'#2244aa');
        px(x-5+L,y+2+cy,10,7,'#3355bb');px(x-4+L,y-1+cy,8,4,'#cc3333');
        px(x-6+L,y+1+cy,2,5,'#eeccaa');px(x+5+L,y+1+cy,2,5,'#eeccaa');
        px(x-4+L,y-6+cy,8,6,'#eeccaa');px(x-5+L,y-9+cy,10,4,'#ff5500');
        ctx.fillStyle='#4488ff';ctx.shadowColor='#4488ff';ctx.shadowBlur=2;px(x-2+L,y-5+cy,2,2,'#4488ff');px(x+1+L,y-5+cy,2,2,'#4488ff');ctx.shadowBlur=0;
        ctx.globalAlpha=1;return;}
    b+=cy;
    px(x-4+L,y+10+b+leg*0.7,3,2,'#111133');px(x+1+L,y+10+b-leg*0.7,3,2,'#111133');
    px(x-3+L,y+4+b,3,7+leg*0.7,'#2244aa');px(x+1+L,y+4+b,3,7-leg*0.7,'#2244aa');
    px(x-6+L,y-3+b+br,12,9,'#2244aa');px(x-5+L,y-1+b+br,10,6,'#3355bb');
    px(x-5+L,y-6+b+br,10,4,'#cc3333');px(x-5+L,y-5+b+br,10,1,'#992222');px(x-5+L,y-3+b+br,10,1,'#992222');
    px(x-4+L,y-3+b+br,1,7,'#1a3388');px(x+4+L,y-3+b+br,1,7,'#1a3388');
    px(x-7+L,y-3+b+arm*0.7,2,8,'#eeccaa');px(x+6+L,y-3+b-arm*0.7,2,8,'#eeccaa');
    if(back){px(x-5+L,y-14+b,10,9,'#eeccaa');px(x-6+L,y-18+b,12,6,'#ff5500');px(x-4+L,y-19+b,2,2,'#ff6611');px(x+L,y-20+b,2,2,'#ff6611');px(x+3+L,y-19+b,2,2,'#ff6611');}
    else{px(x-5+L,y-14+b,10,9,'#eeccaa');px(x-4+L,y-12+b,8,6,'#ddbb99');px(x-6+L,y-18+b,12,6,'#ff5500');px(x-6+L,y-14+b,2,4,'#ee4400');px(x+5+L,y-14+b,2,4,'#ee4400');px(x-4+L,y-19+b,2,2,'#ff6611');px(x+L,y-20+b,2,2,'#ff6611');px(x+3+L,y-19+b,2,2,'#ff6611');px(x-3+L,y-11+b,6,1,'#884444');ctx.fillStyle='#4488ff';ctx.shadowColor='#4488ff';ctx.shadowBlur=2;px(x-3+L,y-12+b,2,2,'#4488ff');px(x+2+L,y-12+b,2,2,'#4488ff');ctx.shadowBlur=0;px(x-3+L,y-9+b,6,1,'#cc0000');px(x-2+L,y-9+b,1,1,'#fff');px(x+L,y-9+b,1,1,'#fff');px(x+2+L,y-9+b,1,1,'#fff');}
    if(!p.attacking){px(x+6+L,y-1+b-arm*0.7,2,9,'#ccc');px(x+6+L,y+6+b-arm*0.7,2,3,'#333');}
}

// === GENERIC ===
function dkGeneric(x,y,b,L,leg,arm,br,fc,back,fl,p,f,cd){
    let mc=cd.color,sc=cd.secondaryColor;
    px(x-5+L,y+14+b+leg,4,3,'#111');px(x+1+L,y+14+b-leg,4,3,'#111');
    px(x-5+L,y+6+b,4,9+leg,'#0a0a0a');px(x+2+L,y+6+b,4,9-leg,'#0a0a0a');
    px(x-9+L,y-6+b+br,18,14,sc);px(x-8+L,y-4+b+br,16,10,mc);
    px(x-11+L,y-3+b+arm,3,11,mc);px(x+9+L,y-3+b-arm,3,11,mc);
    if(back){px(x-6+L,y-17+b,12,12,mc);}
    else{px(x-6+L,y-17+b,12,12,mc);px(x-5+L,y-14+b,10,7,'#000');ctx.fillStyle='#f00';ctx.shadowColor='#f00';ctx.shadowBlur=4;px(x-2+L,y-12+b,2,2,'#f00');px(x+1+L,y-12+b,2,2,'#f00');ctx.shadowBlur=0;}
    if(!p.attacking){px(x+9+L,y-6+b-arm,2,13,cd.weaponColor);}
}

// =================================================================
// SURVIVORS
// =================================================================
function drawSurvivorDetailed(p,x,y,bobY,lean){
    let cd=p.charData,f=gameTimer,b=bobY,L=lean;
    let leg=Math.sin(f*0.22)*(p.isRunning?4:0);
    let arm=Math.sin(f*0.2)*(p.isRunning?3:1);
    let br=Math.sin(f*0.05);
    let fc=p.facing,back=fc===1;
    
    // Check if skin is active — use skin-specific renderer
    if (p.skin && p.skin !== 'default') {
        drawSurvivorSkin(p,x,y,b,L,leg,arm,br,fc,back,p.skin);
        // Injured/item effects still apply after
        if(p.injured){px(x-3+L,y+0+b+br,3,3,'#990000aa');let d=(f*0.04)%1;ctx.fillStyle=`rgba(150,0,0,${0.5-d*0.5})`;ctx.fillRect(x-2+L,y+3+b+d*6,2,2);}
        if(p.heldItem==='medkit'){px(x+7+L,y+4+b-arm,4,3,'#fff');px(x+8+L,y+4+b-arm,2,3,'#f00');px(x+7+L,y+5+b-arm,4,1,'#f00');}
        if(p.heldItem==='flashlight'){px(x+7+L,y+2+b-arm,2,6,'#444');px(x+6+L,y+1+b-arm,4,2,'#666');}
        if(p.abilityActive>0){ctx.fillStyle=cd.glowColor+'12';ctx.beginPath();ctx.arc(x,y,14,0,Math.PI*2);ctx.fill();}
        return;
    }
    let skinTone='#ddb088';
    if(p.charKey==='claudette')skinTone='#8a6644';
    if(p.charKey==='feng')skinTone='#eeccaa';
    let shirt=cd.shirtColor||'#888',hair=cd.color||'#332211',sec=cd.secondaryColor||'#444';

    // Shoes
    px(x-5+L,y+14+b+leg,4,3,'#1a1a1a');px(x+1+L,y+14+b-leg,4,3,'#1a1a1a');
    // Jeans
    px(x-4+L,y+6+b,3,9+leg,'#222244');px(x+1+L,y+6+b,3,9-leg,'#222244');
    // Body
    px(x-7+L,y-5+b+br,14,12,sec);px(x-6+L,y-3+b+br,12,9,shirt);
    // Arms (facing-aware)
    if(back){
        px(x-8+L,y-2+b+arm,2,5,shirt);px(x+7+L,y-2+b-arm,2,5,shirt);
        px(x-8+L,y+3+b+arm,2,5,skinTone);px(x+7+L,y+3+b-arm,2,5,skinTone);
    }else if(fc===2){
        px(x-8+L,y-2+b+arm,2,10,skinTone);px(x+5+L,y-1+b-arm,2,7,skinTone);
    }else if(fc===3){
        px(x+7+L,y-2+b-arm,2,10,skinTone);px(x-6+L,y-1+b+arm,2,7,skinTone);
    }else{
        px(x-8+L,y-2+b+arm,2,5,shirt);px(x+7+L,y-2+b-arm,2,5,shirt);
        px(x-8+L,y+3+b+arm,2,5,skinTone);px(x+7+L,y+3+b-arm,2,5,skinTone);
    }
    // Head
    px(x-4+L,y-14+b,8,10,skinTone);
    // Hair
    px(x-5+L,y-17+b,10,5,hair);px(x-5+L,y-14+b,2,4,hair);px(x+4+L,y-14+b,2,4,hair);
    
    if(back){
        // Back view - no face, just hair back
        px(x-4+L,y-14+b,8,8,hair);// hair covers back of head
    }else{
        // Front/side - face details
        px(x-2+L,y-10+b,2,2,'#fff');px(x+1+L,y-10+b,2,2,'#fff');
        px(x-1+L,y-10+b,1,2,'#222');px(x+2+L,y-10+b,1,2,'#222');
        if(f%180>176){px(x-2+L,y-10+b,5,2,skinTone);}// blink
        px(x-1+L,y-7+b,2,1,'#aa7766');// mouth
    }
    
    // Character-specific details
    if(p.charKey==='meg')px(x+4+L,y-14+b,2,7,hair);// ponytail
    if(p.charKey==='dwight'&&!back){px(x-2+L,y-10+b,5,2,'#444');px(x-1+L,y-10+b,1,2,'#aaddff');px(x+2+L,y-10+b,1,2,'#aaddff');px(x+L,y-3+b+br,1,6,'#cc2222');}
    if(p.charKey==='nea'){px(x-4+L,y-13+b,2,4,'#7744cc');px(x+3+L,y-13+b,2,4,'#7744cc');px(x-5+L,y-17+b,10,3,'#333344');}
    if(p.charKey==='feng'){px(x-6+L,y-12+b,2,3,'#cc44ff');px(x+5+L,y-12+b,2,3,'#cc44ff');px(x-5+L,y-15+b,10,1,'#aa33dd');}
    if(p.charKey==='jake')for(let i=0;i<3;i++)px(x-4+L+i*3,y-2+b+br,1,6,'#1a3a1a');

    // Injured
    if(p.injured){px(x-3+L,y+0+b+br,3,3,'#990000aa');let d=(f*0.04)%1;ctx.fillStyle=`rgba(150,0,0,${0.5-d*0.5})`;ctx.fillRect(x-2+L,y+3+b+d*6,2,2);}
    // Held item
    if(p.heldItem==='medkit'){px(x+7+L,y+4+b-arm,4,3,'#fff');px(x+8+L,y+4+b-arm,2,3,'#f00');px(x+7+L,y+5+b-arm,4,1,'#f00');}
    if(p.heldItem==='flashlight'){px(x+7+L,y+2+b-arm,2,6,'#444');px(x+6+L,y+1+b-arm,4,2,'#666');}
    if(p.abilityActive>0){ctx.fillStyle=cd.glowColor+'12';ctx.beginPath();ctx.arc(x,y,14,0,Math.PI*2);ctx.fill();}
}

// === CRAWLING ===
function drawCrawlingSurvivor(p,x,y){
    let cd=p.charData,f=gameTimer,hair=cd.color||'#332211',shirt=cd.shirtColor||'#888';
    let skinTone='#ddb088';if(p.charKey==='claudette')skinTone='#8a6644';if(p.charKey==='feng')skinTone='#eeccaa';
    let crawl=Math.sin(f*0.12)*(p.isRunning?3:0),br=Math.sin(f*0.08)*0.5;
    let dir=(p.facing===3||p.facing===0)?1:-1;
    ctx.fillStyle='#00000033';ctx.beginPath();ctx.ellipse(x,y+4,14,4,0,0,Math.PI*2);ctx.fill();
    px(x-7*dir,y+2,4,3,'#222244');px(x-10*dir,y+3+crawl*0.3,3,3,'#222244');px(x-11*dir,y+3,3,2,'#1a1a1a');
    px(x-4,y-3+br,10,7,shirt);px(x-5,y-4+br,12,2,cd.secondaryColor||'#444');
    px(x+5*dir+crawl*dir,y-4,5,2,skinTone);px(x+2*dir-crawl*dir*0.5,y-2,4,2,skinTone);
    px(x+6*dir,y-7,6,5,skinTone);px(x+6*dir,y-9,6,3,hair);
    px(x-2,y-1+br,3,3,'#99000099');
    let ratio=1-(p.dyingTimer/2700);px(x-12,y-13,24,4,'#110000aa');ctx.fillStyle=ratio>0.5?'#ff4400':'#ff0000';ctx.fillRect(x-12,y-13,24*ratio,4);
    if(p.dyingTimer<0){let r=Math.abs(p.dyingTimer)/90;px(x-10,y-17,20,3,'#002200');ctx.fillStyle='#44ff44';ctx.fillRect(x-10,y-17,20*r,3);}
    ctx.fillStyle='#ff6644';ctx.font='bold 8px monospace';ctx.textAlign='center';ctx.fillText(`J${p.id+1}`,x,y-19);
}


// =================================================================
// SKIN-SPECIFIC SPRITE RENDERERS
// Detailed pixel art for each iconic character skin
// =================================================================

// === GHOSTFACE — Black robe, white ghost mask, hunting knife ===
function dkSkinGhostface(x,y,b,L,leg,arm,br,fc,back,fl,p,f){
    // Boots
    px(x-5+L,y+14+b+leg,4,3,'#0a0a0a');px(x+1+L,y+14+b-leg,4,3,'#0a0a0a');
    // Long black robe (legs hidden by fabric)
    px(x-6+L,y+4+b,5,11+leg,'#050505');px(x+2+L,y+4+b,5,11-leg,'#050505');
    // Robe flowing edges
    px(x-8+L,y+8+b,2,6,'#0a0a0a');px(x+7+L,y+8+b,2,6,'#0a0a0a');
    // Body/torso - black flowing robe
    px(x-9+L,y-7+b+br,18,15,'#050505');px(x-8+L,y-5+b+br,16,11,'#0a0a0a');
    // Robe folds (vertical lines for fabric texture)
    px(x-5+L,y-4+b+br,1,10,'#111');px(x+L,y-5+b+br,1,11,'#111');px(x+4+L,y-4+b+br,1,10,'#111');
    // Hood (frames the mask)
    px(x-7+L,y-18+b,14,14,'#050505');px(x-6+L,y-16+b,12,10,'#0a0a0a');
    // Hood inner shadow
    px(x-5+L,y-15+b,10,8,'#020202');
    // White ghost mask (iconic elongated scream shape)
    if(!back){
        px(x-4+L,y-16+b,8,11,'#e8e8e8');px(x-3+L,y-15+b,6,9,'#f5f5f5');
        // Mask eye holes (long oval black pits)
        px(x-3+L,y-13+b,2,4,'#000');px(x+2+L,y-13+b,2,4,'#000');
        // Mouth (elongated O shape)
        px(x-2+L,y-8+b,4,3,'#000');px(x-1+L,y-7+b,2,2,'#111');
        // Mask forehead highlight
        px(x-2+L,y-16+b,4,1,'#fff');
    } else {
        px(x-5+L,y-17+b,10,12,'#050505');// back of hood
    }
    // Arms (black sleeves)
    px(x-11+L,y-3+b+arm,3,12,'#0a0a0a');px(x+9+L,y-3+b-arm,3,12,'#0a0a0a');
    // Knife (right hand - large hunting knife)
    if(!p.attacking){
        px(x+9+L,y-4+b-arm,2,3,'#333');// handle
        px(x+9+L,y-7+b-arm,2,6,'#cccccc');// blade
        px(x+9+L,y-8+b-arm,1,2,'#ffffff');// tip shine
    }
}

// === MICHAEL MYERS — Blue jumpsuit, white featureless mask, kitchen knife ===
function dkSkinMichael(x,y,b,L,leg,arm,br,fc,back,fl,p,f){
    // Boots (black work boots)
    px(x-6+L,y+14+b+leg,5,3,'#111');px(x+1+L,y+14+b-leg,5,3,'#111');
    // Legs (dark blue jumpsuit)
    px(x-5+L,y+6+b,4,9+leg,'#0a0a2a');px(x+2+L,y+6+b,4,9-leg,'#0a0a2a');
    // Torso (mechanic jumpsuit - navy blue)
    px(x-9+L,y-6+b+br,18,14,'#0a0a2a');px(x-8+L,y-4+b+br,16,10,'#101035');
    // Jumpsuit collar
    px(x-4+L,y-6+b+br,8,2,'#0a0a28');
    // Jumpsuit pocket detail
    px(x-6+L,y-1+b+br,4,3,'#080828');px(x+3+L,y-1+b+br,4,3,'#080828');
    // Name tag (tiny detail)
    px(x+3+L,y-4+b+br,3,2,'#333');
    // Arms (blue jumpsuit sleeves)
    px(x-11+L,y-3+b+arm,3,12,'#0a0a2a');px(x+9+L,y-3+b-arm,3,12,'#0a0a2a');
    // Head - the iconic white mask (emotionless, slightly tilted)
    if(back){
        px(x-6+L,y-18+b,12,12,'#1a1a1a');// dark hair from behind
        px(x-5+L,y-17+b,10,10,'#111');
    } else {
        // White mask - featureless, unsettling
        px(x-6+L,y-18+b,12,13,'#d4d4cc');px(x-5+L,y-16+b,10,10,'#e0e0d8');
        // Dark hair visible on sides
        px(x-6+L,y-18+b,2,6,'#1a1a1a');px(x+5+L,y-18+b,2,6,'#1a1a1a');
        px(x-4+L,y-19+b,8,2,'#1a1a1a');// hair on top
        // Eye holes (black, empty, soulless)
        px(x-3+L,y-13+b,2,2,'#000');px(x+2+L,y-13+b,2,2,'#000');
        // Nose shadow
        px(x+L,y-11+b,1,2,'#bbb');
        // Mouth area (slightly dark line)
        px(x-2+L,y-9+b,4,1,'#c0c0b8');
    }
    // Kitchen knife (long, thin blade)
    if(!p.attacking){
        px(x+10+L,y-6+b-arm,2,4,'#3a2a1a');// wooden handle
        px(x+10+L,y-10+b-arm,2,8,'#bbbbbb');// long blade
        px(x+10+L,y-12+b-arm,1,3,'#dddddd');// blade tip/shine
    }
}

// === FREDDY KRUEGER — Burnt skin, striped sweater, fedora, claw glove ===
function dkSkinFreddy(x,y,b,L,leg,arm,br,fc,back,fl,p,f){
    // Boots
    px(x-5+L,y+14+b+leg,4,3,'#1a1008');px(x+1+L,y+14+b-leg,4,3,'#1a1008');
    // Dark pants
    px(x-5+L,y+6+b,4,9+leg,'#1a1a1a');px(x+2+L,y+6+b,4,9-leg,'#1a1a1a');
    // Torso - RED AND GREEN STRIPED SWEATER (iconic)
    px(x-9+L,y-7+b+br,18,14,'#2a4422');// green base
    // Red stripes
    px(x-8+L,y-5+b+br,16,2,'#882222');px(x-8+L,y-1+b+br,16,2,'#882222');px(x-8+L,y+3+b+br,16,2,'#882222');
    // Green stripes between
    px(x-8+L,y-3+b+br,16,2,'#2a4422');px(x-8+L,y+1+b+br,16,2,'#2a4422');px(x-8+L,y+5+b+br,16,2,'#2a4422');
    // Arms (striped sleeves)
    px(x-11+L,y-3+b+arm,3,3,'#882222');px(x-11+L,y+0+b+arm,3,3,'#2a4422');px(x-11+L,y+3+b+arm,3,4,'#882222');
    px(x+9+L,y-3+b-arm,3,3,'#2a4422');px(x+9+L,y+0+b-arm,3,3,'#882222');px(x+9+L,y+3+b-arm,3,4,'#2a4422');
    // Head - burnt scarred skin
    if(back){
        px(x-5+L,y-17+b,10,12,'#3a1a0a');// burnt skin from back
        px(x-5+L,y-19+b,10,4,'#2a1a08');// fedora back
    } else {
        px(x-5+L,y-17+b,10,12,'#6a3322');// burnt scarred face
        px(x-4+L,y-15+b,8,8,'#5a2a1a');// deeper scars
        // Burn texture
        px(x-3+L,y-14+b,2,3,'#4a1a0a');px(x+2+L,y-13+b,2,2,'#4a1a0a');
        // Eyes (menacing)
        px(x-3+L,y-13+b,2,2,'#aaccff');px(x+2+L,y-13+b,2,2,'#aaccff');
        // Teeth/grin
        px(x-2+L,y-9+b,4,2,'#882222');px(x-1+L,y-9+b,2,1,'#ddd');
        // FEDORA (brown hat)
        px(x-7+L,y-19+b,14,3,'#3a2a1a');// brim
        px(x-5+L,y-22+b,10,4,'#4a3a2a');// crown
        px(x-4+L,y-21+b,8,1,'#2a1a0a');// hat band
    }
    // RIGHT HAND: CLAW GLOVE (4 long metal blades)
    if(!p.attacking){
        px(x+9+L,y+5+b-arm,3,3,'#553322');// leather glove
        // 4 metal claws extending
        px(x+9+L,y+1+b-arm,1,5,'#ccaa44');
        px(x+10+L,y+0+b-arm,1,6,'#ccaa44');
        px(x+11+L,y+1+b-arm,1,5,'#ccaa44');
        px(x+12+L,y+0+b-arm,1,6,'#ccaa44');
        // Claw tips (shiny)
        px(x+9+L,y+0+b-arm,1,1,'#fff');px(x+10+L,y-1+b-arm,1,1,'#fff');
        px(x+11+L,y+0+b-arm,1,1,'#fff');px(x+12+L,y-1+b-arm,1,1,'#fff');
    }
}

// === JASON VOORHEES — Huge body, hockey mask, tattered jacket, machete ===
function dkSkinJason(x,y,b,L,leg,arm,br,fc,back,fl,p,f){
    // Heavy boots
    px(x-6+L,y+14+b+leg,5,4,'#222');px(x+1+L,y+14+b-leg,5,4,'#222');
    // Thick legs (large frame)
    px(x-6+L,y+5+b,5,10+leg,'#2a3a2a');px(x+2+L,y+5+b,5,10-leg,'#2a3a2a');
    // Massive torso (broad shouldered)
    px(x-10+L,y-8+b+br,20,16,'#2a3a2a');px(x-9+L,y-6+b+br,18,12,'#3a4a3a');
    // Tattered jacket tears
    px(x-8+L,y+2+b+br,3,4,'#1a2a1a');px(x+6+L,y+0+b+br,3,5,'#1a2a1a');
    // Exposed undershirt patches
    px(x-4+L,y-2+b+br,3,4,'#555');px(x+3+L,y-3+b+br,2,3,'#555');
    // Thick arms
    px(x-12+L,y-4+b+arm,4,13,'#3a4a3a');px(x+9+L,y-4+b-arm,4,13,'#3a4a3a');
    // Head - HOCKEY MASK
    if(back){
        px(x-6+L,y-19+b,12,13,'#3a3a2a');// back of head/mask strap
    } else {
        // Hockey mask - white with red chevrons
        px(x-6+L,y-19+b,12,13,'#ddddcc');px(x-5+L,y-17+b,10,10,'#e8e8dd');
        // Mask eye holes (triangular)
        px(x-4+L,y-14+b,3,3,'#000');px(x+2+L,y-14+b,3,3,'#000');
        // Red chevrons/marks on mask
        px(x-4+L,y-17+b,2,2,'#cc2222');px(x+3+L,y-17+b,2,2,'#cc2222');
        // Nose area/vent holes
        px(x-1+L,y-12+b,1,1,'#333');px(x+1+L,y-12+b,1,1,'#333');px(x+L,y-11+b,1,1,'#333');
        // Forehead mark
        px(x-1+L,y-18+b,2,1,'#cc2222');
        // Mask straps on sides
        px(x-6+L,y-14+b,1,4,'#444');px(x+6+L,y-14+b,1,4,'#444');
    }
    // MACHETE (large, thick blade)
    if(!p.attacking){
        px(x+10+L,y-6+b-arm,3,5,'#3a2a1a');// wrapped handle
        px(x+10+L,y-11+b-arm,3,8,'#777');// thick blade
        px(x+10+L,y-13+b-arm,2,3,'#999');// blade tip
        px(x+10+L,y-11+b-arm,1,8,'#aaa');// edge shine
    }
}

// === PYRAMID HEAD — Huge pyramid helmet, bare torso, giant sword ===
function dkSkinPyramid(x,y,b,L,leg,arm,br,fc,back,fl,p,f){
    // Boots (heavy)
    px(x-6+L,y+14+b+leg,5,3,'#2a2a2a');px(x+1+L,y+14+b-leg,5,3,'#2a2a2a');
    // Legs (leather/meat apron-skirt)
    px(x-7+L,y+4+b,6,11+leg,'#4a2a1a');px(x+2+L,y+4+b,6,11-leg,'#4a2a1a');
    // Skirt/apron bottom tears
    px(x-7+L,y+12+b,2,3,'#3a1a0a');px(x+6+L,y+13+b,2,2,'#3a1a0a');
    // Torso - BARE, muscular, bloody
    px(x-9+L,y-6+b+br,18,13,'#7a5544');px(x-8+L,y-4+b+br,16,9,'#8a6655');
    // Blood smears on torso
    px(x-5+L,y-3+b+br,3,5,'#661111');px(x+3+L,y-2+b+br,4,4,'#551111');
    // Rib shadows
    px(x-6+L,y-1+b+br,12,1,'#6a4433');px(x-6+L,y+2+b+br,12,1,'#6a4433');
    // Arms (bare, thick)
    px(x-12+L,y-4+b+arm,4,14,'#7a5544');px(x+9+L,y-4+b-arm,4,14,'#7a5544');
    // HEAD - PYRAMID HELMET (iconic angular metal shape)
    if(back){
        px(x-6+L,y-20+b,12,14,'#8a6644');// back of pyramid (rusted metal)
        px(x-5+L,y-19+b,10,12,'#7a5533');
    } else {
        // Pyramid shape - triangular/angular
        px(x-8+L,y-12+b,16,8,'#8a6644');// base of pyramid (wide)
        px(x-6+L,y-16+b,12,5,'#9a7755');// middle
        px(x-4+L,y-20+b,8,5,'#aa8866');// upper
        px(x-2+L,y-23+b,4,4,'#bb9977');// tip
        // Metal edges/seams
        px(x-8+L,y-12+b,1,8,'#5a4422');px(x+7+L,y-12+b,1,8,'#5a4422');
        // Front face dark slit
        px(x-3+L,y-10+b,6,3,'#220000');
        // Rust drips
        px(x-6+L,y-8+b,1,4,'#663311');px(x+5+L,y-9+b,1,3,'#663311');
    }
    // GREAT KNIFE (enormous sword dragging)
    if(!p.attacking){
        px(x+10+L,y-2+b-arm,3,4,'#3a3a3a');// handle
        px(x+10+L,y+2+b-arm,4,16,'#555');// HUGE blade
        px(x+10+L,y+2+b-arm,1,16,'#777');// edge shine
        px(x+13+L,y+2+b-arm,1,16,'#333');// dark edge
        // Blade so big it drags
        px(x+9+L,y+16+b-arm,5,2,'#444');
    }
}

// === PENNYWISE — Clown suit, ruffled collar, white face, red hair ===
function dkSkinPennywise(x,y,b,L,leg,arm,br,fc,back,fl,p,f){
    // Pointed shoes
    px(x-6+L,y+14+b+leg,5,3,'#444');px(x+1+L,y+14+b-leg,5,3,'#444');
    // Baggy pants (silver/grey victorian)
    px(x-5+L,y+5+b,5,10+leg,'#888');px(x+1+L,y+5+b,5,10-leg,'#888');
    // Pant ruffles
    px(x-6+L,y+5+b,7,2,'#999');px(x+1+L,y+5+b,7,2,'#999');
    // Torso - silver/grey victorian suit with ruffles
    px(x-9+L,y-7+b+br,18,14,'#999');px(x-8+L,y-5+b+br,16,10,'#aaa');
    // Suit buttons (3 pom-poms down center)
    px(x-1+L,y-4+b+br,2,2,'#cc3300');px(x-1+L,y-1+b+br,2,2,'#cc3300');px(x-1+L,y+2+b+br,2,2,'#cc3300');
    // RUFFLED COLLAR (large elizabethan collar)
    px(x-8+L,y-8+b+br,16,3,'#ddd');px(x-9+L,y-7+b+br,18,1,'#eee');
    px(x-7+L,y-9+b+br,14,2,'#ccc');
    // Arms (puffy sleeves)
    px(x-12+L,y-4+b+arm,4,12,'#aaa');px(x+9+L,y-4+b-arm,4,12,'#aaa');
    // Sleeve ruffles at wrists
    px(x-12+L,y+6+b+arm,4,2,'#ddd');px(x+9+L,y+6+b-arm,4,2,'#ddd');
    // Head
    if(back){
        px(x-6+L,y-18+b,12,12,'#cc3300');// orange/red hair from behind
    } else {
        // White face
        px(x-5+L,y-17+b,10,11,'#eee');px(x-4+L,y-15+b,8,8,'#fff');
        // WILD RED HAIR (poofing out on sides)
        px(x-8+L,y-20+b,16,5,'#cc3300');
        px(x-9+L,y-17+b,3,5,'#cc3300');px(x+7+L,y-17+b,3,5,'#cc3300');
        px(x-8+L,y-18+b,2,4,'#aa2200');px(x+7+L,y-18+b,2,4,'#aa2200');
        // Red nose
        px(x+L,y-12+b,2,2,'#ff0000');
        // Yellow eyes (deadlights)
        ctx.fillStyle='#ffcc00';ctx.shadowColor='#ffcc00';ctx.shadowBlur=3;
        px(x-3+L,y-14+b,2,2,'#ffcc00');px(x+2+L,y-14+b,2,2,'#ffcc00');
        ctx.shadowBlur=0;
        // Red smile lines going up cheeks
        px(x-4+L,y-10+b,2,1,'#cc0000');px(x+3+L,y-10+b,2,1,'#cc0000');
        // Wide red mouth/grin
        px(x-3+L,y-9+b,6,2,'#cc0000');
        // Teeth
        px(x-2+L,y-9+b,1,1,'#fff');px(x+L,y-9+b,1,1,'#fff');px(x+2+L,y-9+b,1,1,'#fff');
    }
    // Clawed hand / red balloon string
    if(!p.attacking){
        // Balloon string in right hand
        px(x+10+L,y-4+b-arm,1,12,'#999');
        // Red balloon floating above
        px(x+10+L,y-18+b-arm,4,5,'#ff0000');px(x+11+L,y-20+b-arm,2,3,'#ff2222');
        // Balloon shine
        px(x+11+L,y-19+b-arm,1,1,'#ff8888');
    }
}

// =================================================================
// SURVIVOR SKIN SPRITES
// =================================================================
function drawSurvivorSkin(p,x,y,b,L,leg,arm,br,fc,back,skinKey){
    let cd=p.charData;
    let shirt=cd.shirtColor||'#888',hair=cd.color||'#332211',sec=cd.secondaryColor||'#444';
    let skinTone='#ddb088';
    if(p.charKey==='claudette')skinTone='#8a6644';
    if(p.charKey==='feng')skinTone='#eeccaa';
    
    // Base survivor body (shared)
    // Shoes
    px(x-5+L,y+14+b+leg,4,3,'#1a1a1a');px(x+1+L,y+14+b-leg,4,3,'#1a1a1a');
    // Jeans/pants
    px(x-4+L,y+6+b,3,9+leg,sec);px(x+1+L,y+6+b,3,9-leg,sec);
    // Body
    px(x-7+L,y-5+b+br,14,12,sec);px(x-6+L,y-3+b+br,12,9,shirt);
    // Arms
    if(back){
        px(x-8+L,y-2+b+arm,2,5,shirt);px(x+7+L,y-2+b-arm,2,5,shirt);
        px(x-8+L,y+3+b+arm,2,5,skinTone);px(x+7+L,y+3+b-arm,2,5,skinTone);
    } else {
        px(x-8+L,y-2+b+arm,2,5,shirt);px(x+7+L,y-2+b-arm,2,5,shirt);
        px(x-8+L,y+3+b+arm,2,5,skinTone);px(x+7+L,y+3+b-arm,2,5,skinTone);
    }
    // Head base
    px(x-4+L,y-14+b,8,10,skinTone);
    
    // SKIN-SPECIFIC DETAILS
    if(skinKey==='leon'){
        // Leon — Bangs covering one eye, RPD badge
        px(x-5+L,y-17+b,10,5,hair);// blonde hair top
        px(x-5+L,y-14+b,4,4,hair);// bangs (long, covering left eye)
        px(x+4+L,y-14+b,2,3,hair);// right side
        if(!back){px(x+1+L,y-10+b,2,2,'#fff');px(x+2+L,y-10+b,1,2,'#36a');// one visible eye
        px(x-1+L,y-7+b,2,1,'#aa7766');}// mouth
        // RPD shoulder badge
        px(x-7+L,y-4+b+br,2,2,'#3355aa');
    } else if(skinKey==='ada'){
        // Ada — Bob cut, red dress slit, heels
        px(x-5+L,y+14+b+leg,4,3,'#880000');px(x+1+L,y+14+b-leg,4,3,'#880000');// red heels
        px(x-5+L,y-17+b,10,4,'#0a0a0a');// black bob-cut
        px(x-5+L,y-14+b,2,5,'#0a0a0a');px(x+4+L,y-14+b,2,5,'#0a0a0a');// straight sides
        if(!back){px(x-2+L,y-10+b,2,2,'#fff');px(x+1+L,y-10+b,2,2,'#fff');
        px(x-1+L,y-10+b,1,2,'#222');px(x+2+L,y-10+b,1,2,'#222');
        px(x-1+L,y-7+b,3,1,'#cc2222');}// red lips
        // Dress slit on leg
        px(x+2+L,y+8+b,1,5,skinTone);
    } else if(skinKey==='lara'){
        // Lara — Long braid, tank top, dual holsters
        px(x-5+L,y-17+b,10,5,hair);px(x-5+L,y-14+b,2,3,hair);px(x+4+L,y-14+b,2,3,hair);
        // Long braid (hanging down back)
        px(x+L,y-12+b,2,18,hair);px(x+L,y+4+b,2,2,'#443');// braid tie
        if(!back){px(x-2+L,y-10+b,2,2,'#fff');px(x+1+L,y-10+b,2,2,'#fff');
        px(x-1+L,y-10+b,1,2,'#542');px(x+2+L,y-10+b,1,2,'#542');}// brown eyes
        // Dual holsters on thighs
        px(x-5+L,y+6+b,2,3,'#333');px(x+4+L,y+6+b,2,3,'#333');
        // Holster straps
        px(x-5+L,y+5+b,1,1,'#555');px(x+5+L,y+5+b,1,1,'#555');
    } else if(skinKey==='bill'){
        // Bill — Beret, beard, cigarette
        px(x-5+L,y-17+b,10,5,'#3a5a3a');// green beret
        px(x-6+L,y-14+b,12,2,'#3a5a3a');// beret brim
        px(x-4+L,y-14+b,8,3,skinTone);// forehead
        if(!back){
            px(x-2+L,y-10+b,2,2,'#fff');px(x+1+L,y-10+b,2,2,'#fff');
            px(x-1+L,y-10+b,1,2,'#456');px(x+2+L,y-10+b,1,2,'#456');
            // Grey beard
            px(x-3+L,y-8+b,6,3,'#888');px(x-2+L,y-7+b,4,2,'#777');
            // Cigarette
            px(x+3+L,y-7+b,4,1,'#fff');px(x+6+L,y-7+b,1,1,'#ff4400');
        }
    } else if(skinKey==='cheryl'){
        // Cheryl — Short blonde hair, orange vest
        px(x-5+L,y-17+b,10,5,'#bbaa55');// blonde short
        px(x-5+L,y-14+b,2,3,'#bbaa55');px(x+4+L,y-14+b,2,3,'#bbaa55');
        if(!back){px(x-2+L,y-10+b,2,2,'#fff');px(x+1+L,y-10+b,2,2,'#fff');
        px(x-1+L,y-10+b,1,2,'#564');px(x+2+L,y-10+b,1,2,'#564');}
        // Vest detail (sleeveless)
        px(x-7+L,y-3+b+br,1,8,skinTone);px(x+7+L,y-3+b+br,1,8,skinTone);// exposed arms more
    } else {
        // Default skin rendering (just hair and face)
        px(x-5+L,y-17+b,10,5,hair);px(x-5+L,y-14+b,2,4,hair);px(x+4+L,y-14+b,2,4,hair);
        if(!back){
            px(x-2+L,y-10+b,2,2,'#fff');px(x+1+L,y-10+b,2,2,'#fff');
            px(x-1+L,y-10+b,1,2,'#222');px(x+2+L,y-10+b,1,2,'#222');
            px(x-1+L,y-7+b,2,1,'#aa7766');
        }
    }
}
