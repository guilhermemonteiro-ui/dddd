// ============================================================
// DEAD BY PIXEL - PROGRESSION SYSTEM
// Level, Prestige, Bloodpoints (currency), Shop
// Saves to localStorage
// ============================================================

const PROGRESSION = {
    // XP needed per level
    xpPerLevel: 500,
    maxLevel: 50,
    maxPrestige: 3,
    // Bloodpoints earned per match
    bpPerKill: 300,
    bpPerHook: 150,
    bpPerHit: 100,
    bpPerEscape: 500,
    bpPerUnhook: 200,
    bpPerHeal: 150,
    bpSurvival: 100, // per minute survived
    bpLoss: 50 // consolation for dying
};

// Player profile (saved to localStorage)
let playerProfile = {
    name: 'Player',
    level: 1,
    xp: 0,
    prestige: 0,
    bloodpoints: 1000, // start with some
    totalMatches: 0,
    totalKills: 0,
    totalEscapes: 0,
    // Unlocked characters (all base chars free)
    unlockedKillers: ['trapper', 'huntress', 'ghostface'],
    unlockedSurvivors: ['meg', 'dwight', 'claudette'],
    // Unlocked skins
    unlockedSkins: { killer: ['default'], survivor: ['default'] },
    // Stats per character
    charStats: {},
    // Per-character level & XP
    charLevels: {},
    // Unlocked cosmetics per character
    charCosmetics: {},
    // Equipped cosmetics per character  
    equippedCosmetics: {}
};

// =============================================================
// RARITY SYSTEM
// =============================================================
const RARITY = {
    common:    { name: 'Comum',     color: '#888888', border: '#555555', bg: '#1a1a1a' },
    uncommon:  { name: 'Incomum',   color: '#44cc44', border: '#228822', bg: '#0a1a0a' },
    rare:      { name: 'Raro',      color: '#4488ff', border: '#2244aa', bg: '#0a0a1a' },
    very_rare: { name: 'Muito Raro', color: '#cc44ff', border: '#8822aa', bg: '#1a0a2a' },
    ultra_rare:{ name: 'Ultra Raro', color: '#ff4488', border: '#aa2244', bg: '#2a0a1a' },
    legendary: { name: 'Lendário',  color: '#ffaa00', border: '#aa6600', bg: '#1a1400' }
};

// Add rarity to perks
const KILLER_PERKS = {
    bloodhound: { name: 'Cão de Caça', icon: '🐕', desc: 'Feridos ficam 20% mais lentos', effect: 'injuredSlow', rarity: 'uncommon' },
    ironfist: { name: 'Punho de Ferro', icon: '👊', desc: 'Ataque empurra o sobrevivente', effect: 'knockback', rarity: 'rare' },
    bamboozle: { name: 'Bamboozle', icon: '🚫', desc: 'Destrói paletes mais rápido', effect: 'fastBreak', rarity: 'uncommon' },
    noed: { name: 'NOED', icon: '💀', desc: 'Velocidade extra nos portões', effect: 'endgameSpeed', rarity: 'very_rare' },
    bbq: { name: 'BBQ & Chili', icon: '🔥', desc: 'Speed ao enganchá-los', effect: 'hookSpeed', rarity: 'rare' },
    agitation: { name: 'Agitação', icon: '🏋️', desc: 'Move mais rápido carregando', effect: 'carrySpeed', rarity: 'uncommon' },
    brutal: { name: 'Força Brutal', icon: '💪', desc: 'Recobra de ataques rápido', effect: 'fastRecovery', rarity: 'rare' },
    enduring: { name: 'Resistência', icon: '🛡️', desc: 'Stuns duram menos', effect: 'reduceStun', rarity: 'very_rare' }
};

const SURVIVOR_PERKS = {
    sprintburst: { name: 'Sprint Burst', icon: '⚡', desc: 'Burst de velocidade ao correr', effect: 'sprintOnRun', rarity: 'very_rare' },
    deadhard: { name: 'Dead Hard', icon: '💨', desc: 'Esquiva invencível rápida', effect: 'dashInvuln', rarity: 'ultra_rare' },
    ironwill: { name: 'Vontade de Ferro', icon: '🤫', desc: 'Sem rastros de sangue', effect: 'noScratchWhenInjured', rarity: 'rare' },
    adrenaline: { name: 'Adrenalina', icon: '💉', desc: 'Cura quando portões abrem', effect: 'endgameHeal', rarity: 'very_rare' },
    borrowed: { name: 'Tempo Emprestado', icon: '⏳', desc: 'Resgatados ganham proteção', effect: 'borrowedTime', rarity: 'rare' },
    resilience: { name: 'Resiliência', icon: '🔥', desc: '+10% speed enquanto ferido', effect: 'injuredSpeed', rarity: 'uncommon' },
    selfcare: { name: 'Autocuidado', icon: '🩹', desc: 'Cura passiva lenta', effect: 'passiveHeal', rarity: 'rare' },
    lightweight: { name: 'Peso Leve', icon: '🪶', desc: 'Scratch marks somem rápido', effect: 'fastScratchFade', rarity: 'common' }
};

// Items with rarity
const GAME_ITEMS = {
    medkit:     { name: 'Kit Médico', icon: '🩹', desc: 'Cura ferimentos', rarity: 'uncommon' },
    flashlight: { name: 'Lanterna', icon: '🔦', desc: 'Cega o Killer', rarity: 'rare' },
    toolbox:    { name: 'Caixa de Ferramentas', icon: '🧰', desc: 'Sabota ganchos rápido', rarity: 'uncommon' },
    map_item:   { name: 'Mapa', icon: '🗺️', desc: 'Revela geradores próximos', rarity: 'rare' },
    key_item:   { name: 'Chave', icon: '🔑', desc: 'Abre hatch antecipado', rarity: 'very_rare' }
};

// =============================================================
// BLOODWEB SYSTEM
// Spend BP to unlock nodes on a web per character
// Each level of the web gives perks, items, or cosmetics
// =============================================================

// Generate a bloodweb for a character at their current level
function generateBloodweb(charKey) {
    let charLv = getCharLevel(charKey);
    let level = charLv.level;
    let role = Object.keys(KILLERS).includes(charKey) ? 'killer' : 'survivor';
    let perks = role === 'killer' ? KILLER_PERKS : SURVIVOR_PERKS;
    
    // Number of nodes scales with level
    let nodeCount = Math.min(6 + Math.floor(level / 3), 15);
    let nodes = [];
    let availablePerks = Object.entries(perks);
    let availableItems = Object.entries(GAME_ITEMS);
    let cosmetics = CHAR_COSMETICS[charKey];
    
    // Seed-based random for consistent web per level
    let seed = (charKey.length * 1337 + level * 7919) & 0xFFFF;
    function seededRand() { seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF; return (seed % 1000) / 1000; }
    
    for (let i = 0; i < nodeCount; i++) {
        let r = seededRand();
        let node = null;
        
        if (r < 0.35 && availablePerks.length > 0) {
            // Perk node
            let idx = Math.floor(seededRand() * availablePerks.length);
            let [key, perk] = availablePerks[idx];
            node = { type: 'perk', key, name: perk.name, icon: perk.icon, rarity: perk.rarity, cost: getNodeCost(perk.rarity) };
        } else if (r < 0.6 && availableItems.length > 0) {
            // Item node
            let idx = Math.floor(seededRand() * availableItems.length);
            let [key, item] = availableItems[idx];
            node = { type: 'item', key, name: item.name, icon: item.icon, rarity: item.rarity, cost: getNodeCost(item.rarity) };
        } else if (r < 0.8) {
            // BP bonus node
            let bonus = [100, 150, 200, 300][Math.floor(seededRand() * 4)];
            node = { type: 'bp', key: 'bp_'+i, name: `+${bonus} BP`, icon: '🩸', rarity: bonus > 200 ? 'rare' : 'common', cost: Math.floor(bonus * 0.5) };
            node.bpBonus = bonus;
        } else if (cosmetics && seededRand() > 0.5) {
            // Cosmetic node (if character has cosmetics)
            let slots = ['head', 'body', 'weapon'].filter(s => cosmetics[s] && cosmetics[s].length > 1);
            if (slots.length > 0) {
                let slot = slots[Math.floor(seededRand() * slots.length)];
                let items = cosmetics[slot].filter(c => c.key !== 'default' && c.level <= level + 2);
                if (items.length > 0) {
                    let item = items[Math.floor(seededRand() * items.length)];
                    let rarity = item.price > 3000 ? 'ultra_rare' : item.price > 2000 ? 'very_rare' : item.price > 1000 ? 'rare' : 'uncommon';
                    node = { type: 'cosmetic', key: item.key, slot, name: item.name, icon: item.icon, rarity, cost: Math.floor(item.price * 0.6) };
                }
            }
        }
        
        if (!node) {
            // Fallback: XP node
            let xpAmount = [30, 50, 80, 100][Math.floor(seededRand() * 4)];
            node = { type: 'xp', key: 'xp_'+i, name: `+${xpAmount} XP`, icon: '⭐', rarity: xpAmount > 60 ? 'uncommon' : 'common', cost: Math.floor(xpAmount * 1.5) };
            node.xpBonus = xpAmount;
        }
        
        // Position on a circular web
        let angle = (i / nodeCount) * Math.PI * 2 - Math.PI / 2;
        let ring = i < nodeCount / 2 ? 0.5 : 1;
        node.x = 0.5 + Math.cos(angle) * 0.35 * ring;
        node.y = 0.5 + Math.sin(angle) * 0.35 * ring;
        node.id = i;
        node.claimed = false;
        
        nodes.push(node);
    }
    
    return nodes;
}

function getNodeCost(rarity) {
    switch(rarity) {
        case 'common': return 100;
        case 'uncommon': return 200;
        case 'rare': return 350;
        case 'very_rare': return 500;
        case 'ultra_rare': return 750;
        case 'legendary': return 1000;
        default: return 150;
    }
}

// Claim a bloodweb node
function claimBloodwebNode(charKey, nodeId, nodes) {
    let node = nodes.find(n => n.id === nodeId);
    if (!node || node.claimed) return false;
    if (playerProfile.bloodpoints < node.cost) return false;
    
    playerProfile.bloodpoints -= node.cost;
    node.claimed = true;
    
    // Apply reward
    switch(node.type) {
        case 'perk':
            // Perks are always available in the picker, bloodweb just gives BP discount + XP
            addCharXP(charKey, 40);
            break;
        case 'item':
            // Items are consumables — add to a stash (future: use in-game)
            addCharXP(charKey, 25);
            break;
        case 'bp':
            playerProfile.bloodpoints += node.bpBonus;
            break;
        case 'xp':
            addCharXP(charKey, node.xpBonus);
            break;
        case 'cosmetic':
            // Unlock the cosmetic!
            if (!playerProfile.charCosmetics[charKey]) playerProfile.charCosmetics[charKey] = ['default'];
            if (!playerProfile.charCosmetics[charKey].includes(node.key)) {
                playerProfile.charCosmetics[charKey].push(node.key);
            }
            addCharXP(charKey, 50);
            break;
    }
    
    // Check if all nodes claimed = level up character
    let allClaimed = nodes.filter(n => !n.claimed).length === 0;
    if (allClaimed) {
        addCharXP(charKey, 100); // bonus for completing the web
    }
    
    saveProfile();
    return true;
}

// Render the bloodweb UI (called from customize panel)
function renderBloodweb(charKey) {
    let nodes = generateBloodweb(charKey);
    // Check which ones were already claimed (stored in profile)
    let claimedNodes = playerProfile.charStats[charKey + '_web'] || [];
    for (let node of nodes) {
        if (claimedNodes.includes(node.id)) node.claimed = true;
    }
    
    let html = `<div style="position:relative;width:280px;height:280px;margin:0 auto;background:#050505;border:2px solid #222;">`;
    // Center entity icon
    html += `<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:1.5em;opacity:0.3;">🕸️</div>`;
    // Connecting lines (decorative)
    html += `<svg style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;opacity:0.2;">`;
    for (let node of nodes) {
        html += `<line x1="50%" y1="50%" x2="${node.x*100}%" y2="${node.y*100}%" stroke="#444" stroke-width="1"/>`;
    }
    html += `</svg>`;
    
    // Nodes
    for (let node of nodes) {
        let r = RARITY[node.rarity] || RARITY.common;
        let opacity = node.claimed ? '0.3' : '1';
        let cursor = node.claimed ? 'default' : (playerProfile.bloodpoints >= node.cost ? 'pointer' : 'not-allowed');
        let canAfford = !node.claimed && playerProfile.bloodpoints >= node.cost;
        
        html += `<div onclick="${canAfford ? `claimWebNode('${charKey}',${node.id})` : ''}" 
            style="position:absolute;left:${node.x*100}%;top:${node.y*100}%;transform:translate(-50%,-50%);
            width:38px;height:38px;background:${r.bg};border:2px solid ${node.claimed?'#333':r.border};
            display:flex;flex-direction:column;align-items:center;justify-content:center;
            cursor:${cursor};opacity:${opacity};transition:all 0.15s;font-size:0.8em;"
            title="${node.name} (${node.cost} BP) — ${r.name}">
            <span style="font-size:1.4em;${node.claimed?'filter:grayscale(1);':''}">${node.icon}</span>
            ${!node.claimed ? `<span style="font-size:0.5em;color:${r.color};">${node.cost}</span>` : '<span style="font-size:0.6em;color:#444;">✓</span>'}
        </div>`;
    }
    
    html += `</div>`;
    html += `<div style="text-align:center;margin-top:8px;font-size:0.65em;color:#666;">Clique em um nó para gastar BP e desbloquear</div>`;
    
    return html;
}

// Global function called from bloodweb UI
function claimWebNode(charKey, nodeId) {
    let nodes = generateBloodweb(charKey);
    let claimedNodes = playerProfile.charStats[charKey + '_web'] || [];
    for (let node of nodes) { if (claimedNodes.includes(node.id)) node.claimed = true; }
    
    if (claimBloodwebNode(charKey, nodeId, nodes)) {
        // Save claimed node
        if (!playerProfile.charStats[charKey + '_web']) playerProfile.charStats[charKey + '_web'] = [];
        playerProfile.charStats[charKey + '_web'].push(nodeId);
        saveProfile();
        // Re-render
        if (typeof renderLobbyUI === 'function') renderLobbyUI();
        if (typeof csToggle === 'function') { csActivePanel = 'customize'; setTimeout(() => { renderLobbyUI(); if(typeof drawCustomizePreview==='function')setTimeout(drawCustomizePreview,30); }, 10); }
    }
}
const CHAR_COSMETICS = {
    // KILLERS
    trapper: {
        head: [
            { key: 'default', name: 'Máscara Padrão', icon: '🎭', color: '#aa9966', price: 0, level: 0 },
            { key: 'bloody_mask', name: 'Máscara Sangrenta', icon: '🩸', color: '#882222', price: 1500, level: 5 },
            { key: 'bone_mask', name: 'Máscara de Osso', icon: '💀', color: '#ccccaa', price: 2500, level: 10 },
            { key: 'gold_mask', name: 'Máscara Dourada', icon: '👑', color: '#ccaa00', price: 4000, level: 15 }
        ],
        body: [
            { key: 'default', name: 'Macacão Padrão', icon: '👔', color: '#6a5a38', price: 0, level: 0 },
            { key: 'dark_overalls', name: 'Macacão Escuro', icon: '🖤', color: '#2a2a18', price: 1200, level: 3 },
            { key: 'bloody_apron', name: 'Avental Sangrento', icon: '🩸', color: '#4a1a1a', price: 2000, level: 8 }
        ],
        weapon: [
            { key: 'default', name: 'Cutelo Padrão', icon: '🔪', color: '#999999', price: 0, level: 0 },
            { key: 'rusty_blade', name: 'Lâmina Enferrujada', icon: '⚔️', color: '#884422', price: 1800, level: 6 },
            { key: 'bone_cleaver', name: 'Cutelo de Osso', icon: '🦴', color: '#ddccaa', price: 3000, level: 12 },
            { key: 'obsidian', name: 'Lâmina Obsidiana', icon: '🗡️', color: '#222244', price: 5000, level: 20 }
        ]
    },
    huntress: {
        head: [
            { key: 'default', name: 'Máscara de Coelho', icon: '🐰', color: '#eeeedd', price: 0, level: 0 },
            { key: 'wolf_mask', name: 'Máscara de Lobo', icon: '🐺', color: '#887766', price: 2000, level: 5 },
            { key: 'deer_mask', name: 'Máscara de Cervo', icon: '🦌', color: '#aa8855', price: 2500, level: 10 },
            { key: 'crow_mask', name: 'Máscara de Corvo', icon: '🐦‍⬛', color: '#222233', price: 3500, level: 15 },
            { key: 'blood_bunny', name: 'Coelho Sangrento', icon: '🩸', color: '#cc4444', price: 4000, level: 20 }
        ],
        body: [
            { key: 'default', name: 'Roupas de Caça', icon: '🌲', color: '#3a5a3a', price: 0, level: 0 },
            { key: 'winter_fur', name: 'Pele de Inverno', icon: '❄️', color: '#8a8a7a', price: 1500, level: 4 },
            { key: 'dark_hunter', name: 'Caçadora Noturna', icon: '🌙', color: '#1a2a1a', price: 2500, level: 12 }
        ],
        weapon: [
            { key: 'default', name: 'Machado de Caça', icon: '🪓', color: '#888888', price: 0, level: 0 },
            { key: 'golden_axe', name: 'Machado Dourado', icon: '✨', color: '#ccaa00', price: 3000, level: 8 },
            { key: 'ice_axe', name: 'Machado de Gelo', icon: '🧊', color: '#88ccff', price: 3500, level: 14 },
            { key: 'infernal_axe', name: 'Machado Infernal', icon: '🔥', color: '#ff4400', price: 5000, level: 20 }
        ]
    },
    wraith: {
        head: [
            { key: 'default', name: 'Crânio Padrão', icon: '💀', color: '#3a5566', price: 0, level: 0 },
            { key: 'shadow_skull', name: 'Crânio das Sombras', icon: '🌑', color: '#111122', price: 2000, level: 7 },
            { key: 'spectral', name: 'Espectral', icon: '👻', color: '#88aacc', price: 3500, level: 15 }
        ],
        body: [
            { key: 'default', name: 'Vestes do Wraith', icon: '👔', color: '#224455', price: 0, level: 0 },
            { key: 'phantom', name: 'Manto Fantasma', icon: '👻', color: '#1a3344', price: 2000, level: 8 }
        ],
        weapon: [
            { key: 'default', name: 'Sino da Destruição', icon: '🔔', color: '#556677', price: 0, level: 0 },
            { key: 'skull_bell', name: 'Sino Craniano', icon: '💀', color: '#aabbcc', price: 2500, level: 10 }
        ]
    },
    hillbilly: {
        head: [
            { key: 'default', name: 'Face Deformada', icon: '😡', color: '#775544', price: 0, level: 0 },
            { key: 'iron_mask', name: 'Máscara de Ferro', icon: '🛡️', color: '#555555', price: 2500, level: 10 }
        ],
        body: [
            { key: 'default', name: 'Macacão de Fazenda', icon: '👔', color: '#886644', price: 0, level: 0 },
            { key: 'blood_stained', name: 'Manchado de Sangue', icon: '🩸', color: '#663322', price: 1800, level: 6 }
        ],
        weapon: [
            { key: 'default', name: 'Motosserra', icon: '⛓️', color: '#aaaaaa', price: 0, level: 0 },
            { key: 'golden_chain', name: 'Motosserra Dourada', icon: '✨', color: '#ccaa00', price: 4000, level: 15 }
        ]
    },
    // SURVIVORS
    meg: {
        head: [
            { key: 'default', name: 'Rabo de Cavalo', icon: '💇‍♀️', color: '#553322', price: 0, level: 0 },
            { key: 'short_hair', name: 'Cabelo Curto', icon: '✂️', color: '#442211', price: 1000, level: 3 },
            { key: 'red_dye', name: 'Tintura Vermelha', icon: '🔴', color: '#883322', price: 2000, level: 8 },
            { key: 'blonde', name: 'Loira', icon: '⭐', color: '#ccaa55', price: 1500, level: 5 }
        ],
        body: [
            { key: 'default', name: 'Camiseta Atletica', icon: '👕', color: '#cc4455', price: 0, level: 0 },
            { key: 'track_suit', name: 'Agasalho', icon: '🏃', color: '#335599', price: 1200, level: 4 },
            { key: 'neon_top', name: 'Top Neon', icon: '💚', color: '#44ff44', price: 2000, level: 10 }
        ],
        weapon: []
    },
    claudette: {
        head: [
            { key: 'default', name: 'Cabelo Natural', icon: '💇‍♀️', color: '#221111', price: 0, level: 0 },
            { key: 'braids', name: 'Tranças', icon: '🎀', color: '#111100', price: 1200, level: 5 },
            { key: 'flowers', name: 'Com Flores', icon: '🌸', color: '#221111', price: 2000, level: 10 }
        ],
        body: [
            { key: 'default', name: 'Camisa Botânica', icon: '👕', color: '#4a7a4a', price: 0, level: 0 },
            { key: 'lab_coat', name: 'Jaleco', icon: '🥼', color: '#cccccc', price: 1500, level: 6 },
            { key: 'dark_green', name: 'Verde Escuro', icon: '🌲', color: '#1a3a1a', price: 1000, level: 3 }
        ],
        weapon: []
    },
    dwight: {
        head: [
            { key: 'default', name: 'Óculos e Cabelo', icon: '🤓', color: '#1a1a1a', price: 0, level: 0 },
            { key: 'no_glasses', name: 'Sem Óculos', icon: '👤', color: '#222211', price: 800, level: 3 },
            { key: 'beanie', name: 'Gorro', icon: '🧢', color: '#334455', price: 1500, level: 8 }
        ],
        body: [
            { key: 'default', name: 'Camisa Social', icon: '👔', color: '#eeeeee', price: 0, level: 0 },
            { key: 'pizza_uniform', name: 'Uniforme Pizza', icon: '🍕', color: '#cc4444', price: 1200, level: 5 },
            { key: 'manager', name: 'Gerente', icon: '💼', color: '#2a2a3a', price: 2000, level: 12 }
        ],
        weapon: []
    }
};

// Character level thresholds
const CHAR_LEVEL_XP = 200; // XP per character level
const CHAR_MAX_LEVEL = 25;

// Get character level info
function getCharLevel(charKey) {
    if (!playerProfile.charLevels[charKey]) {
        playerProfile.charLevels[charKey] = { level: 1, xp: 0 };
    }
    return playerProfile.charLevels[charKey];
}

// Add XP to specific character
function addCharXP(charKey, amount) {
    let cl = getCharLevel(charKey);
    cl.xp += amount;
    while (cl.xp >= CHAR_LEVEL_XP && cl.level < CHAR_MAX_LEVEL) {
        cl.xp -= CHAR_LEVEL_XP;
        cl.level++;
    }
    saveProfile();
    return cl;
}

// Get unlocked cosmetics for character
function getUnlockedCosmetics(charKey) {
    if (!playerProfile.charCosmetics[charKey]) {
        playerProfile.charCosmetics[charKey] = ['default'];
    }
    return playerProfile.charCosmetics[charKey];
}

// Buy a cosmetic
function buyCosmetic(charKey, cosmeticKey) {
    let cosmetics = CHAR_COSMETICS[charKey];
    if (!cosmetics) return false;
    // Find the cosmetic in any slot
    let item = null;
    for (let slot of ['head', 'body', 'weapon']) {
        if (!cosmetics[slot]) continue;
        item = cosmetics[slot].find(c => c.key === cosmeticKey);
        if (item) break;
    }
    if (!item) return false;
    if (item.price === 0) return false; // free items are always unlocked
    let charLv = getCharLevel(charKey);
    if (charLv.level < item.level) return false; // level requirement not met
    if (playerProfile.bloodpoints < item.price) return false;
    
    playerProfile.bloodpoints -= item.price;
    if (!playerProfile.charCosmetics[charKey]) playerProfile.charCosmetics[charKey] = ['default'];
    if (!playerProfile.charCosmetics[charKey].includes(cosmeticKey)) {
        playerProfile.charCosmetics[charKey].push(cosmeticKey);
    }
    saveProfile();
    return true;
}

// Equip a cosmetic
function equipCosmetic(charKey, slot, cosmeticKey) {
    if (!playerProfile.equippedCosmetics[charKey]) {
        playerProfile.equippedCosmetics[charKey] = { head: 'default', body: 'default', weapon: 'default' };
    }
    playerProfile.equippedCosmetics[charKey][slot] = cosmeticKey;
    saveProfile();
}

// Get equipped cosmetics for a character
function getEquippedCosmetics(charKey) {
    if (!playerProfile.equippedCosmetics[charKey]) {
        playerProfile.equippedCosmetics[charKey] = { head: 'default', body: 'default', weapon: 'default' };
    }
    return playerProfile.equippedCosmetics[charKey];
}

// Shop items
const SHOP_KILLERS = {};

const SHOP_SURVIVORS = {};

const SHOP_SKINS_KILLER = {
    prestige: { name: 'Prestige III', price: 5000, icon: '🩸', requires: 'prestige1' }
};

const SHOP_SKINS_SURVIVOR = {
    prestige: { name: 'Prestige III', price: 5000, icon: '🩸', requires: 'prestige1' }
};

// Load/Save
function loadProfile() {
    try {
        let saved = localStorage.getItem('dbp_profile');
        if (saved) {
            let parsed = JSON.parse(saved);
            playerProfile = { ...playerProfile, ...parsed };
            // Ensure nested objects exist (for saves from before these fields existed)
            if (!playerProfile.charLevels) playerProfile.charLevels = {};
            if (!playerProfile.charCosmetics) playerProfile.charCosmetics = {};
            if (!playerProfile.equippedCosmetics) playerProfile.equippedCosmetics = {};
            if (!playerProfile.unlockedSkins) playerProfile.unlockedSkins = { killer: ['default'], survivor: ['default'] };
            if (!playerProfile.charStats) playerProfile.charStats = {};
            // Compact-roster migration: remove characters and skins from older saves.
            playerProfile.unlockedKillers = ['trapper', 'huntress', 'ghostface'];
            playerProfile.unlockedSurvivors = ['meg', 'claudette', 'dwight'];
            playerProfile.unlockedSkins.killer = playerProfile.unlockedSkins.killer.filter(key => key === 'default' || key === 'prestige');
            playerProfile.unlockedSkins.survivor = playerProfile.unlockedSkins.survivor.filter(key => key === 'default' || key === 'prestige');
        }
    } catch(e) {}
}

function saveProfile() {
    try { localStorage.setItem('dbp_profile', JSON.stringify(playerProfile)); } catch(e) {}
}

// XP & Level
function addXP(amount) {
    playerProfile.xp += amount;
    while (playerProfile.xp >= PROGRESSION.xpPerLevel && playerProfile.level < PROGRESSION.maxLevel) {
        playerProfile.xp -= PROGRESSION.xpPerLevel;
        playerProfile.level++;
        showGameMessage(`LEVEL UP! Nível ${playerProfile.level}`, 120);
    }
    saveProfile();
}

function addBloodpoints(amount) {
    playerProfile.bloodpoints += amount;
    saveProfile();
}

function canPrestige() {
    return playerProfile.level >= PROGRESSION.maxLevel && playerProfile.prestige < PROGRESSION.maxPrestige;
}

function doPrestige() {
    if (!canPrestige()) return false;
    playerProfile.prestige++;
    playerProfile.level = 1;
    playerProfile.xp = 0;
    playerProfile.bloodpoints += 2000; // prestige bonus
    // Unlock prestige skin
    if (!playerProfile.unlockedSkins.killer.includes('prestige')) playerProfile.unlockedSkins.killer.push('prestige');
    if (!playerProfile.unlockedSkins.survivor.includes('prestige')) playerProfile.unlockedSkins.survivor.push('prestige');
    saveProfile();
    return true;
}

// Shop
function buyKiller(key) {
    let item = SHOP_KILLERS[key];
    if (!item) return false;
    if (playerProfile.unlockedKillers.includes(key)) return false;
    if (playerProfile.bloodpoints < item.price) return false;
    playerProfile.bloodpoints -= item.price;
    playerProfile.unlockedKillers.push(key);
    saveProfile();
    return true;
}

function buySurvivor(key) {
    let item = SHOP_SURVIVORS[key];
    if (!item) return false;
    if (playerProfile.unlockedSurvivors.includes(key)) return false;
    if (playerProfile.bloodpoints < item.price) return false;
    playerProfile.bloodpoints -= item.price;
    playerProfile.unlockedSurvivors.push(key);
    saveProfile();
    return true;
}

function buySkinKiller(key) {
    let item = SHOP_SKINS_KILLER[key];
    if (!item) return false;
    if (playerProfile.unlockedSkins.killer.includes(key)) return false;
    if (playerProfile.bloodpoints < item.price) return false;
    if (item.requires === 'prestige1' && playerProfile.prestige < 1) return false;
    playerProfile.bloodpoints -= item.price;
    playerProfile.unlockedSkins.killer.push(key);
    saveProfile();
    return true;
}

function buySkinSurvivor(key) {
    let item = SHOP_SKINS_SURVIVOR[key];
    if (!item) return false;
    if (playerProfile.unlockedSkins.survivor.includes(key)) return false;
    if (playerProfile.bloodpoints < item.price) return false;
    if (item.requires === 'prestige1' && playerProfile.prestige < 1) return false;
    playerProfile.bloodpoints -= item.price;
    playerProfile.unlockedSkins.survivor.push(key);
    saveProfile();
    return true;
}

// Match end rewards
function calculateMatchRewards(role, stats) {
    let bp = 0;
    let xp = 0;
    
    if (role === 'killer') {
        bp += (stats.kills || 0) * PROGRESSION.bpPerKill;
        bp += (stats.hooks || 0) * PROGRESSION.bpPerHook;
        bp += (stats.hits || 0) * PROGRESSION.bpPerHit;
        playerProfile.totalKills += (stats.kills || 0);
    } else {
        if (stats.escaped) { bp += PROGRESSION.bpPerEscape; playerProfile.totalEscapes++; }
        else bp += PROGRESSION.bpLoss;
        bp += (stats.unhooks || 0) * PROGRESSION.bpPerUnhook;
        bp += (stats.heals || 0) * PROGRESSION.bpPerHeal;
    }
    
    // Time survived bonus
    bp += Math.floor((stats.timeAlive || 0) / 60) * PROGRESSION.bpSurvival;
    
    xp = Math.floor(bp * 0.5); // XP = half of BP earned
    playerProfile.totalMatches++;
    
    addBloodpoints(bp);
    addXP(xp);
    
    // Add character-specific XP
    if (stats.charKey) {
        let charXpGain = Math.floor(bp * 0.3);
        addCharXP(stats.charKey, charXpGain);
    }
    
    return { bp, xp };
}

// Render shop UI
function renderShopPanel() {
    let html = `
        <div style="padding:20px;color:#ccc;max-height:80vh;overflow-y:auto;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:15px;">
                <h2 style="color:#ffaa00;font-family:Creepster,cursive;">🩸 LOJA DE SANGUE</h2>
                <div style="font-size:1.2em;color:#ffcc00;">💰 ${playerProfile.bloodpoints} BP</div>
            </div>
            
            <div style="margin-bottom:10px;padding:8px;background:#0a0a14;border:1px solid #222;border-radius:4px;">
                <span style="color:#888;">Nível ${playerProfile.level}/${PROGRESSION.maxLevel}</span> | 
                <span style="color:#ff6666;">Prestígio ${playerProfile.prestige}</span> | 
                <span style="color:#888;">XP: ${playerProfile.xp}/${PROGRESSION.xpPerLevel}</span>
                ${canPrestige() ? `<button onclick="doPrestige();renderShopPanel();" style="margin-left:10px;padding:4px 12px;background:#880000;border:1px solid #cc0000;color:#fff;cursor:pointer;border-radius:3px;">⭐ PRESTIGIAR</button>` : ''}
            </div>
            
            <h3 style="color:#ff6666;margin:12px 0 8px;">🔪 Killers</h3>
            <div style="display:flex;flex-wrap:wrap;gap:8px;">
    `;
    
    for (let [key, item] of Object.entries(SHOP_KILLERS)) {
        let owned = playerProfile.unlockedKillers.includes(key);
        let canBuy = !owned && playerProfile.bloodpoints >= item.price;
        html += `<div style="padding:8px 12px;background:${owned ? '#001a00' : '#0a0a14'};border:1px solid ${owned ? '#004400' : canBuy ? '#664400' : '#222'};border-radius:4px;min-width:100px;text-align:center;">
            <div style="font-size:1.4em;">${item.icon}</div>
            <div style="font-size:0.8em;color:#ccc;">${item.name}</div>
            ${owned ? '<div style="font-size:0.7em;color:#44ff44;">✓ OBTIDO</div>' : `<div style="font-size:0.7em;color:#ffaa00;">${item.price} BP</div><button onclick="if(buyKiller('${key}'))renderShopPanel();" style="margin-top:4px;padding:2px 8px;font-size:0.7em;background:${canBuy ? '#443300' : '#222'};border:1px solid ${canBuy ? '#886600' : '#333'};color:${canBuy ? '#ffcc00' : '#555'};cursor:${canBuy ? 'pointer' : 'default'};border-radius:2px;" ${canBuy ? '' : 'disabled'}>COMPRAR</button>`}
        </div>`;
    }
    
    html += `</div><h3 style="color:#66ff88;margin:12px 0 8px;">🏃 Survivors</h3><div style="display:flex;flex-wrap:wrap;gap:8px;">`;
    
    for (let [key, item] of Object.entries(SHOP_SURVIVORS)) {
        let owned = playerProfile.unlockedSurvivors.includes(key);
        let canBuy = !owned && playerProfile.bloodpoints >= item.price;
        html += `<div style="padding:8px 12px;background:${owned ? '#001a00' : '#0a0a14'};border:1px solid ${owned ? '#004400' : canBuy ? '#664400' : '#222'};border-radius:4px;min-width:100px;text-align:center;">
            <div style="font-size:1.4em;">${item.icon}</div>
            <div style="font-size:0.8em;color:#ccc;">${item.name}</div>
            ${owned ? '<div style="font-size:0.7em;color:#44ff44;">✓ OBTIDO</div>' : `<div style="font-size:0.7em;color:#ffaa00;">${item.price} BP</div><button onclick="if(buySurvivor('${key}'))renderShopPanel();" style="margin-top:4px;padding:2px 8px;font-size:0.7em;background:${canBuy ? '#443300' : '#222'};border:1px solid ${canBuy ? '#886600' : '#333'};color:${canBuy ? '#ffcc00' : '#555'};cursor:${canBuy ? 'pointer' : 'default'};border-radius:2px;" ${canBuy ? '' : 'disabled'}>COMPRAR</button>`}
        </div>`;
    }
    
    html += `</div><h3 style="color:#cc88ff;margin:12px 0 8px;">🎭 Skins Killer</h3><div style="display:flex;flex-wrap:wrap;gap:8px;">`;
    
    for (let [key, item] of Object.entries(SHOP_SKINS_KILLER)) {
        let owned = playerProfile.unlockedSkins.killer.includes(key);
        let canBuy = !owned && playerProfile.bloodpoints >= item.price && (!item.requires || (item.requires === 'prestige1' && playerProfile.prestige >= 1));
        html += `<div style="padding:6px 10px;background:${owned ? '#0a001a' : '#0a0a14'};border:1px solid ${owned ? '#330066' : canBuy ? '#664400' : '#222'};border-radius:4px;min-width:80px;text-align:center;">
            <div style="font-size:1.2em;">${item.icon}</div>
            <div style="font-size:0.7em;color:#ccc;">${item.name}</div>
            ${owned ? '<div style="font-size:0.65em;color:#aa66ff;">✓</div>' : `<div style="font-size:0.65em;color:#ffaa00;">${item.price}</div><button onclick="if(buySkinKiller('${key}'))renderShopPanel();" style="padding:1px 6px;font-size:0.6em;background:${canBuy ? '#443300' : '#222'};border:1px solid ${canBuy ? '#886600' : '#333'};color:${canBuy ? '#ffcc00' : '#555'};cursor:${canBuy ? 'pointer' : 'default'};border-radius:2px;" ${canBuy ? '' : 'disabled'}>BUY</button>`}
        </div>`;
    }
    
    html += `</div><h3 style="color:#88ffcc;margin:12px 0 8px;">🎭 Skins Survivor</h3><div style="display:flex;flex-wrap:wrap;gap:8px;">`;
    
    for (let [key, item] of Object.entries(SHOP_SKINS_SURVIVOR)) {
        let owned = playerProfile.unlockedSkins.survivor.includes(key);
        let canBuy = !owned && playerProfile.bloodpoints >= item.price && (!item.requires || (item.requires === 'prestige1' && playerProfile.prestige >= 1));
        html += `<div style="padding:6px 10px;background:${owned ? '#001a0a' : '#0a0a14'};border:1px solid ${owned ? '#006633' : canBuy ? '#664400' : '#222'};border-radius:4px;min-width:80px;text-align:center;">
            <div style="font-size:1.2em;">${item.icon}</div>
            <div style="font-size:0.7em;color:#ccc;">${item.name}</div>
            ${owned ? '<div style="font-size:0.65em;color:#44ffaa;">✓</div>' : `<div style="font-size:0.65em;color:#ffaa00;">${item.price}</div><button onclick="if(buySkinSurvivor('${key}'))renderShopPanel();" style="padding:1px 6px;font-size:0.6em;background:${canBuy ? '#443300' : '#222'};border:1px solid ${canBuy ? '#886600' : '#333'};color:${canBuy ? '#ffcc00' : '#555'};cursor:${canBuy ? 'pointer' : 'default'};border-radius:2px;" ${canBuy ? '' : 'disabled'}>BUY</button>`}
        </div>`;
    }
    
    html += `</div></div>`;
    
    document.getElementById('settings-content').innerHTML = html;
}

// Admin mode - unlocks everything
let adminMode = false;

function toggleAdminMode() {
    adminMode = !adminMode;
    if (adminMode) {
        // Unlock ALL killers (including new ones like pinhead, legion, sirenhead, springtrap)
        playerProfile.unlockedKillers = Object.keys(KILLERS);
        // Unlock all survivors
        playerProfile.unlockedSurvivors = Object.keys(SURVIVORS);
        // Unlock all skins
        playerProfile.unlockedSkins.killer = Object.keys(SKINS.killer);
        playerProfile.unlockedSkins.survivor = Object.keys(SKINS.survivor);
        // Unlock ALL cosmetics for all characters
        for (let charKey of Object.keys(CHAR_COSMETICS)) {
            if (!playerProfile.charCosmetics[charKey]) playerProfile.charCosmetics[charKey] = ['default'];
            let cosmData = CHAR_COSMETICS[charKey];
            for (let slot of ['head', 'body', 'weapon']) {
                if (!cosmData[slot]) continue;
                for (let item of cosmData[slot]) {
                    if (!playerProfile.charCosmetics[charKey].includes(item.key)) {
                        playerProfile.charCosmetics[charKey].push(item.key);
                    }
                }
            }
        }
        // Max all character levels (all killers + survivors)
        for (let charKey of [...Object.keys(KILLERS), ...Object.keys(SURVIVORS)]) {
            playerProfile.charLevels[charKey] = { level: CHAR_MAX_LEVEL, xp: 0 };
        }
        // Give max BP
        playerProfile.bloodpoints = 999999;
        playerProfile.level = 50;
        saveProfile();
        alert('🔓 ADMIN MODE ATIVADO - Tudo desbloqueado!\nTodos personagens Lv.MAX, todos cosméticos, 999999 BP');
    } else {
        alert('Admin mode desativado. Recarregue para restaurar.');
    }
    if (typeof updateProfileUI === 'function') updateProfileUI();
    if (typeof renderLobbyUI === 'function') renderLobbyUI();
}

// Initialize on load
loadProfile();
