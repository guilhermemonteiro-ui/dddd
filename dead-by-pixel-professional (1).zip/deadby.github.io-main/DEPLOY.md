# 🎮 Como Hospedar Dead by Pixel Online (GRÁTIS)

O jogo usa **PeerJS** para multiplayer P2P — conexão direta entre navegadores.
Basta hospedar os arquivos HTML+JS em qualquer host de sites estáticos.

---

## Opção 1: GitHub Pages (Recomendado - 100% Grátis)

### Passo a Passo:

1. **Crie uma conta no GitHub** (se não tem): https://github.com/signup

2. **Crie um repositório novo**:
   - Vá em https://github.com/new
   - Nome: `dead-by-pixel` (ou qualquer nome)
   - Marque: **Public**
   - Clique: **Create repository**

3. **Faça upload dos arquivos**:
   - Na página do repositório, clique **"uploading an existing file"**
   - Arraste estes arquivos: `index.html` e `game.js`
   - Clique **Commit changes**

4. **Ative o GitHub Pages**:
   - Vá em **Settings** → **Pages** (menu lateral)
   - Em "Source", selecione: **Deploy from a branch**
   - Branch: **main** / Folder: **/ (root)**
   - Clique **Save**

5. **Pronto!** Em ~1 minuto seu jogo estará em:
   ```
   https://SEU-USUARIO.github.io/dead-by-pixel/
   ```

6. **Mande esse link pros seus amigos!** Todos abrem no navegador e jogam.

---

## Opção 2: Netlify (Ainda mais fácil)

1. Vá em https://app.netlify.com/drop
2. Arraste a pasta com `index.html` e `game.js` direto na página
3. Pronto! Vai gerar um link tipo `https://random-name.netlify.app`
4. Mande esse link pros amigos

---

## Opção 3: Vercel

1. Vá em https://vercel.com
2. Faça login com GitHub
3. Importe o repositório
4. Deploy automático! Link gerado na hora.

---

## Opção 4: itch.io (Plataforma de jogos)

1. Crie conta em https://itch.io
2. Vá em Dashboard → Create new project
3. Kind of project: **HTML**
4. Faça upload de um ZIP com `index.html` + `game.js`
5. Marque "This file will be played in the browser"
6. Publique!

---

## Como Jogar com Amigos:

1. Todos abrem o mesmo link no navegador (PC ou celular)
2. Um jogador clica **JOGAR ONLINE** → **CRIAR** sala
3. O código aparece (ex: `ABC123`)
4. Os amigos clicam **JOGAR ONLINE** → digitam o código → **ENTRAR**
5. Cada um escolhe personagem e clica **PRONTO**
6. O host clica **INICIAR PARTIDA**

**Funciona com até 5 jogadores!**

---

## Requisitos:
- Navegador moderno (Chrome, Firefox, Edge, Safari)
- Internet (para a conexão P2P entre jogadores)
- Funciona em PC e celular (controles touch automáticos)

## Não precisa:
- ❌ Instalar nada
- ❌ Baixar arquivos
- ❌ Servidor pago
- ❌ Node.js

---

## Troubleshooting:

**"Não conecta com meu amigo"**
- Ambos precisam de internet
- Em redes muito restritas (escola/trabalho) o P2P pode ser bloqueado
- Tente em redes diferentes (4G funciona bem)

**"Lag/delay"**  
- Normal em P2P, depende da distância entre jogadores
- Quanto mais perto geograficamente, melhor
