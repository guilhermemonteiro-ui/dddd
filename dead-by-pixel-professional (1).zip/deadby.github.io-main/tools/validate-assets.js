const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const expected = [
  'killer-ghostface.png',
  'killer-trapper.png',
  'killer-huntress.png',
  'survivor-meg.png',
  'survivor-claudette.png',
  'survivor-dwight.png'
];

function pngSize(file) {
  const data = fs.readFileSync(file);
  if (data.length < 24 || data.toString('hex', 0, 8) !== '89504e470d0a1a0a') {
    throw new Error(`${file} não é um PNG válido`);
  }
  return [data.readUInt32BE(16), data.readUInt32BE(20)];
}

for (const name of expected) {
  const file = path.join(root, 'assets', 'characters', name);
  if (!fs.existsSync(file)) throw new Error(`Asset ausente: ${name}`);
  const [width, height] = pngSize(file);
  if (width !== 1024 || height !== 640) {
    throw new Error(`${name}: esperado 1024x640, recebido ${width}x${height}`);
  }
}

const manifest = JSON.parse(fs.readFileSync(path.join(root, 'assets', 'manifest.json'), 'utf8'));
if (manifest.characters.killers.length !== 3 || manifest.characters.survivors.length !== 3) {
  throw new Error('O manifesto deve conter exatamente três killers e três sobreviventes');
}

console.log('Assets validados: 3 killers + 3 sobreviventes, 4 direções, 8 estados.');
