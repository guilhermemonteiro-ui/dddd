// ============================================================
// DEAD BY PIXEL - High-Performance Multiplayer Server
// Optimized for low latency game state relay
//
// Para rodar:
//   npm install ws
//   node server.js
// ============================================================

const WebSocket = require('ws');
const { createServer } = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;

const MIME = {
    '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
    '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon'
};

// Static game host + multiplayer health endpoint
const httpServer = createServer((req, res) => {
    if (req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'ok', rooms: rooms.size, clients: wss.clients.size }));
        return;
    }
    const pathname = decodeURIComponent((req.url || '/').split('?')[0]);
    const relative = pathname === '/' ? '/index.html' : pathname;
    const requested = path.resolve(__dirname, `.${relative}`);
    if (!requested.startsWith(__dirname + path.sep)) {
        res.writeHead(403); res.end('Forbidden'); return;
    }
    fs.stat(requested, (error, stat) => {
        if (error || !stat.isFile()) { res.writeHead(404); res.end('Not found'); return; }
        const type = MIME[path.extname(requested).toLowerCase()] || 'application/octet-stream';
        res.writeHead(200, {
            'Content-Type': type,
            'Cache-Control': /\/assets\//.test(pathname) ? 'public, max-age=31536000, immutable' : 'no-cache'
        });
        fs.createReadStream(requested).pipe(res);
    });
});

// WebSocket with performance options
const wss = new WebSocket.Server({ 
    server: httpServer,
    perMessageDeflate: false,       // Disable compression for speed (game packets are small)
    maxPayload: 4096,               // Limit payload size (game state is small)
    backlog: 50,
    clientTracking: true
});

// Room storage
const rooms = new Map();

// Pre-allocate reusable buffers for common messages
const MSG_CACHE = new Map();

function getCachedMsg(obj) {
    return JSON.stringify(obj);
}

// Fast send - skip if socket is not open
function fastSend(ws, msg) {
    if (ws.readyState === 1) { // WebSocket.OPEN = 1
        ws.send(msg);
    }
}

// Fast broadcast - pre-stringify once, send to all
function broadcast(roomCode, message, excludeWs = null) {
    const room = rooms.get(roomCode);
    if (!room) return;
    
    const msgStr = typeof message === 'string' ? message : JSON.stringify(message);
    const players = room.players;
    
    for (let i = 0, len = players.length; i < len; i++) {
        const pw = players[i].ws;
        if (pw !== excludeWs && pw.readyState === 1) {
            pw.send(msgStr);
        }
    }
}

// Fast broadcast raw (already stringified)
function broadcastRaw(roomCode, msgStr, excludeWs) {
    const room = rooms.get(roomCode);
    if (!room) return;
    
    const players = room.players;
    for (let i = 0, len = players.length; i < len; i++) {
        const pw = players[i].ws;
        if (pw !== excludeWs && pw.readyState === 1) {
            pw.send(msgStr);
        }
    }
}

console.log(`☠ Dead by Pixel Server [HIGH PERF] porta ${PORT}`);

wss.on('connection', (ws, req) => {
    ws.isAlive = true;
    ws.room = null;
    ws.playerId = null;
    ws.binaryType = 'arraybuffer';
    
    // Disable Nagle's algorithm for lower latency
    const socket = ws._socket;
    if (socket) {
        socket.setNoDelay(true);
        socket.setKeepAlive(true, 10000);
    }
    
    ws.on('pong', () => { ws.isAlive = true; });
    
    ws.on('message', (raw) => {
        // Fast path: try to handle as string directly
        let data;
        try {
            // Buffer or string - handle both
            const str = typeof raw === 'string' ? raw : raw.toString();
            
            // Ultra-fast path for gameState relay (most frequent message)
            // Check first chars to identify type without full parse
            if (str.charCodeAt(0) === 123) { // starts with '{'
                const typeIdx = str.indexOf('"type"');
                if (typeIdx !== -1) {
                    // Fast check for 's' (compact game state) or 'gameState'
                    const valStart = str.indexOf(':', typeIdx) + 1;
                    const firstQuote = str.indexOf('"', valStart);
                    const typeChar = str.charCodeAt(firstQuote + 1);
                    
                    // 's' = 115, 'g' = 103 (gameState), 'i' = 105 (input)
                    if (typeChar === 115 || (typeChar === 103 && str.charCodeAt(firstQuote + 2) === 97)) {
                        // Game state relay - broadcast raw without re-parsing
                        if (ws.room) {
                            broadcastRaw(ws.room, str, ws);
                        }
                        return;
                    }
                    
                    if (typeChar === 105 && str.charCodeAt(firstQuote + 2) === 110) {
                        // 'input' - relay to host only
                        if (ws.room) {
                            const room = rooms.get(ws.room);
                            if (room && room.host !== ws && room.host.readyState === 1) {
                                room.host.send(str);
                            }
                        }
                        return;
                    }
                }
            }
            
            // Normal path: full JSON parse for other messages
            data = JSON.parse(str);
        } catch(e) {
            return; // Drop malformed messages silently
        }
        
        handleMessage(ws, data);
    });
    
    ws.on('close', () => {
        handleDisconnect(ws);
    });
    
    ws.on('error', () => {
        // Silently handle errors
    });
});

function handleMessage(ws, data) {
    switch(data.type) {
        case 'join':
            joinRoom(ws, data.room, data.isHost);
            break;
        
        case 'startGame':
            startGame(ws, data);
            break;
        
        case 'input':
            // Fast relay to host
            if (ws.room) {
                const room = rooms.get(ws.room);
                if (room && room.host && room.host !== ws && room.host.readyState === 1) {
                    room.host.send(JSON.stringify({
                        type: 'playerInput',
                        id: data.id,
                        keys: data.keys
                    }));
                }
            }
            break;
        
        case 'gameState': case 's':
            // Relay game state to all except sender
            if (ws.room) {
                broadcast(ws.room, data, ws);
            }
            break;
        
        case 'chat':
            if (ws.room) {
                broadcast(ws.room, { type: 'chat', from: ws.playerId, message: (data.message || '').slice(0, 200) });
            }
            break;
        
        case 'roleSelect':
            if (ws.room) {
                broadcast(ws.room, {
                    type: 'roleSelect',
                    id: data.id !== undefined ? data.id : ws.playerId,
                    role: data.role,
                    char: data.char,
                    skin: data.skin || 'default',
                    confirmed: !!data.confirmed
                }, ws);
            }
            break;
        
        case 'returnToLobby':
            if (ws.room) {
                const room = rooms.get(ws.room);
                if (room && room.host === ws) {
                    room.gameStarted = false;
                    broadcast(ws.room, { type: 'returnToLobby', message: data.message || '' }, ws);
                }
            }
            break;
            
        case 'ping':
            // Client ping for latency measurement
            fastSend(ws, '{"type":"pong","t":' + Date.now() + '}');
            break;
    }
}

function joinRoom(ws, roomCode, isHost) {
    if (!roomCode || roomCode.length > 8) {
        fastSend(ws, '{"type":"error","message":"Código inválido"}');
        return;
    }
    
    roomCode = roomCode.toUpperCase().replace(/[^A-Z0-9]/g, '');
    
    if (isHost) {
        if (rooms.has(roomCode)) {
            fastSend(ws, '{"type":"error","message":"Sala já existe!"}');
            return;
        }
        
        rooms.set(roomCode, {
            players: [{ ws, id: 0 }],
            host: ws,
            gameStarted: false,
            maxPlayers: 5,
            created: Date.now()
        });
        
        ws.room = roomCode;
        ws.playerId = 0;
        
        fastSend(ws, JSON.stringify({
            type: 'assignId', id: 0, isHost: true, playerCount: 1, room: roomCode
        }));
        
        console.log(`[+] Sala ${roomCode} criada`);
    } else {
        const room = rooms.get(roomCode);
        if (!room) { fastSend(ws, '{"type":"error","message":"Sala não encontrada!"}'); return; }
        if (room.players.length >= room.maxPlayers) { fastSend(ws, '{"type":"error","message":"Sala cheia!"}'); return; }
        if (room.gameStarted) { fastSend(ws, '{"type":"error","message":"Jogo em andamento!"}'); return; }
        
        const id = room.players.length;
        room.players.push({ ws, id });
        ws.room = roomCode;
        ws.playerId = id;
        
        fastSend(ws, JSON.stringify({
            type: 'assignId', id, isHost: false, playerCount: room.players.length, room: roomCode
        }));
        
        broadcast(roomCode, { type: 'playerJoined', id, playerCount: room.players.length });
        
        console.log(`[+] J${id+1} → sala ${roomCode} (${room.players.length} total)`);
    }
}

function startGame(ws, data) {
    if (!ws.room) return;
    const room = rooms.get(ws.room);
    if (!room || room.host !== ws) return;
    
    room.gameStarted = true;
    
    broadcast(ws.room, {
        type: 'gameStart',
        mapKey: data.mapKey || 'asylum',
        seed: data.seed,
        playerCount: data.playerCount || room.players.length,
        lobby: data.lobby || [],
        killerPerks: data.killerPerks || [],
        survivorPerks: data.survivorPerks || []
    });
    
    console.log(`[▶] Jogo iniciado: sala ${ws.room} (${room.players.length} jogadores)`);
}

function handleDisconnect(ws) {
    if (!ws.room) return;
    
    const room = rooms.get(ws.room);
    if (!room) return;
    
    room.players = room.players.filter(p => p.ws !== ws);
    
    broadcast(ws.room, {
        type: 'playerLeft',
        id: ws.playerId,
        playerCount: room.players.length
    });
    
    if (room.players.length === 0) {
        rooms.delete(ws.room);
        console.log(`[-] Sala ${ws.room} removida`);
    } else if (room.host === ws) {
        room.host = room.players[0].ws;
        fastSend(room.host, '{"type":"promoted","message":"Você é o novo host!"}');
        console.log(`[~] Novo host na sala ${ws.room}`);
    }
    
    console.log(`[-] J${(ws.playerId||0)+1} saiu da sala ${ws.room}`);
}

// Heartbeat - faster interval for game sessions
const heartbeat = setInterval(() => {
    wss.clients.forEach((ws) => {
        if (!ws.isAlive) {
            ws.terminate();
            return;
        }
        ws.isAlive = false;
        ws.ping();
    });
}, 15000); // 15s instead of 30s - detect dead connections faster

// Cleanup stale rooms (rooms open > 2 hours with no game)
const cleanup = setInterval(() => {
    const now = Date.now();
    const TWO_HOURS = 2 * 60 * 60 * 1000;
    
    for (const [code, room] of rooms) {
        if (!room.gameStarted && (now - room.created) > TWO_HOURS && room.players.length === 0) {
            rooms.delete(code);
            console.log(`[🧹] Sala ${code} expirada`);
        }
    }
}, 300000); // Every 5 minutes

httpServer.listen(PORT, () => {
    console.log('');
    console.log('╔═══════════════════════════════════════════╗');
    console.log('║  ☠ DEAD BY PIXEL - SERVER v2.1           ║');
    console.log('║  Otimizado para baixa latência           ║');
    console.log(`║  Porta: ${PORT}                              ║`);
    console.log(`║  WebSocket: ws://localhost:${PORT}           ║`);
    console.log('║  Health: http://localhost:' + PORT + '/health    ║');
    console.log('╚═══════════════════════════════════════════╝');
    console.log('');
    console.log('Compartilhe seu IP público para jogar em rede!');
});

process.on('SIGINT', () => {
    console.log('\nEncerrando servidor...');
    clearInterval(heartbeat);
    clearInterval(cleanup);
    wss.close();
    httpServer.close();
    process.exit(0);
});
