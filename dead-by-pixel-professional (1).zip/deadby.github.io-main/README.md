# Dead by Pixel — Compact Horror Edition

Jogo de terror assimétrico em pixel art para navegador, com elenco compacto e assets PNG ilustrados.

## Elenco inicial

- Killers: Pânico (Ghostface), Trapper e Huntress.
- Sobreviventes: Meg, Claudette e Dwight.

Os killers possuem animações de idle, caminhada e ataque. Os sobreviventes possuem idle, caminhada, coleta de itens e estado ferido. Todos têm quatro direções.

## Rodar

```bash
npm start
```

Abra `http://localhost:3000`.

## Assets

- Tiles do mundo: grade de 28×28 px.
- Atlases de personagem: 1024×640 px, com células de 128×160 px.
- Artes-fonte em alta resolução: `assets/characters/source-hires/`.
- PNG com transparência real e renderização nearest-neighbor.
- Props: pallet, armário, gerador, gancho, baú, portão e armadilha.

Para validar os seis atlases:

```bash
npm run assets
```

O arquivo `assets/manifest.json` documenta a ordem das direções e animações.
